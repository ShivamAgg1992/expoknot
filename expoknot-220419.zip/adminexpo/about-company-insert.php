<?php
require_once("connect-db.php");




echo $exhibitors_Name = $_POST['exhibitors_Name'];
echo $industry = $_POST['industry'];
echo $stall_No = $_POST['stall_No'];
echo $email_Id = $_POST['email_Id'];
echo $tag_Line = $_POST['tag_Line'];
echo $description = $_POST['description'];
echo $address = $_POST['address'];
echo $product_Name = $_POST['product_Name'];

//$name = $_FILES['file']['name'];
//echo $logoToUpload = $_FILES['file']['logoToUpload'];
echo $logoToUpload = $_FILES['logoToUpload']['name'];
echo $comToimages = $_FILES['comToimages']['name'];
echo $broTopdf = $_FILES['broTopdf']['name'];

echo $poc_Name = $_POST['poc_Name'];
echo $poc_Description = $_POST['poc_Description'];
echo $poc_Phone = $_POST['poc_Phone'];
echo $facebook = $_POST['facebook'];
echo $twitter = $_POST['twitter'];
echo $linkdin = $_POST['linkdin'];
echo $instagram = $_POST['instagram'];
echo $youtube = $_POST['youtube'];
echo $website = $_POST['website'];


echo $target_dir = "upload/";
echo $target_file = $target_dir . basename($_FILES["logoToUpload"]["name"]);   
echo $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
echo $extensions_arr = array("jpg","jpeg","png","gif");
if( in_array($imageFileType,$extensions_arr) )
{
 move_uploaded_file($_FILES['logoToUpload']['tmp_name'],$target_dir.$logoToUpload);
}


echo $target_dir_comToimages = "upload/";
echo $target_file = $target_dir_comToimages . basename($_FILES["comToimages"]["name"]);   
echo $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
echo $extensions_arr = array("jpg","jpeg","png","gif");
if( in_array($imageFileType,$extensions_arr) )
{
 move_uploaded_file($_FILES['comToimages']['tmp_name'],$target_dir_comToimages.$comToimages);
}

echo $target_dir_broTopdf = "upload/";
echo $target_file = $target_dir_broTopdf . basename($_FILES["broTopdf"]["name"]);   
echo $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
echo $extensions_arr = array("jpg","jpeg","png","gif");
if( in_array($imageFileType,$extensions_arr) )
{
 move_uploaded_file($_FILES['broTopdf']['tmp_name'],$target_dir_broTopdf.$broTopdf);
}


$sql = "INSERT INTO `Exhibitor_details`(`Exhibitor_Unique_ID`, `Industry`, `Stall_no`, `Exhibitor_Name`, `Logo`, `Tag_line`, `Company_Description`, `Address`, `Email_ID`, `POC_Name`, `POC_Designation`, `Contact_number_Poc`, `Website`, `Brochure`, `Company_Images`, `Product_Name`, `Product_Unique_ID`, `FB_link`, `Twitter_Link`, `Linkedin_link`, `Insta_link`, `Youtube_link`) VALUES ('6','$industry','$stall_No','$exhibitors_Name','$logoToUpload','$tag_Line','$description','$address','$email_Id','$poc_Name','$poc_Description','$poc_Phone','$website','$broTopdf','$comToimages','$product_Name','56','$facebook','$twitter','$linkdin','$instagram','$youtube')" ;

//$sql = "INSERT INTO `Exhibition_details`(`Exhibition_name`, `Exhibition_Industry`, `Description`,  `Organizer_Name`, `Visitor_Profile`, `Exhibitor_Profile`, `Exhibition_Pics`, `Location`, `Venue`, `Date`, `Time`) VALUES ('$exhibitors_Name','$industry','$description','$stall_No','$email_Id','$tag_Line','$address','$product_Name','$logoToUpload','$comToimages','$broTopdf','$poc_Name','$poc_Description','$poc_Phone','$facebook','$twitter','$linkdin','$instagram','$youtube','$website')" ;


mysql_query($sql)
 or die(mysql_error()); 
 
 
  echo '<script>window.location.href = "index.html";</script>';
 
 


/* $result = mysql_query("SELECT * FROM Exhibition_details")
		or die(mysql_error());  

	while($row = mysql_fetch_array( $result )) 
	{
		 echo $oprId=$row['Exhibition_name'];
		 
	} */
	
	

?>
