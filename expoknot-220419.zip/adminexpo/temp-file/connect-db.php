<?php
$server = 'localhost';
 $user = 'sademo';
 $pass = 'Rajeev895@';
 $db = 'sademo';
 
 //$server = 'localhost';
 //$user = 'cmpmaster';
 //$pass = 'cmpmaster';
 //$db = 'cmpmaster';
 
  // Connect to Database
 $connection = mysql_connect($server, $user, $pass) 
 or die ("Could not connect to server ... \n" . mysql_error ());
 mysql_select_db($db) 
 or die ("Could not connect to database ... \n" . mysql_error ());
 ?>

