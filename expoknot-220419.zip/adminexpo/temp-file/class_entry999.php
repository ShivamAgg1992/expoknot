<?php

require_once("config.php");
  
$class_Name = $_POST['class_Name'];

$stmt = $DBcon->prepare("INSERT INTO classmaster(class_Name) VALUES(:class_Name)");

$stmt->bindparam(':class_Name', $class_Name);

$sth = $DBcon->prepare("SELECT class_Name FROM classmaster WHERE class_Name = '$class_Name'");
	$sth->execute(mysql_real_escape_string($_POST['$class_Name']));
	if ($sth->rowCount() > 0)
	{
		if($stmt->execute())
		{
	
			$res="Data Inserted Successfully:";
			echo json_encode($res);
		}
		else {
				$error="Not Inserted,Some Probelm occur.";
				echo json_encode($error);
		}
		
	}
		//return true;
	else{
		return false;
	}
	
 ?>
