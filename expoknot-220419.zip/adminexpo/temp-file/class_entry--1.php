<?php
require_once("config.php");

echo $class_Name = $_POST['class_Name']; 

//echo $class_Name = '10';

//$connection = mysql_connect("localhost", "sademo", "Rajeev895@"); // Establishing Connection with Server
//$db = mysql_select_db("sademo", $connection); // Selecting Database from Server

//echo $conn = mysql_connect(localhost, sademo, Rajeev895@, $sademo);

$servername = "localhost";
$username = "sademo";
$password = "Rajeev895@";
$dbname = "sademo";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

/*$sql = "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('John', 'Doe', 'john@example.com')";
*/
$sql = "INSERT INTO `classmaster`(`class_Name`) VALUES ($class_Name)";


if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
	$res="Data Inserted Successfully:";
  echo json_encode($res);
	
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
	$error="Not Inserted,Some Probelm occur.";
  echo json_encode($error);
}


$conn->close();

//header("Location: classmaster.php");

/*

$sql = "SELECT * FROM `role` WHERE 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["role_rolename"]."<br>";
    }
} else {
    echo "0 results";
}
$conn->close();

*/
?>
