<?php
/*
 * @author Shahrukh Khan
 * @website http://www.thesoftwareguy.in
 * @facebbok https://www.facebook.com/Thesoftwareguy7
 * @twitter https://twitter.com/thesoftwareguy7
 * @googleplus https://plus.google.com/+thesoftwareguyIn
 */
require_once("config.php");
if (!isset($_SESSION["user_id"]) || $_SESSION["user_id"] == "") {
    // not logged in send to login page
    redirect("index.php");
}

include 'header.php';
?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Teacher Assign Master</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Teacher Assign Master
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form">
                                       
										<div class="form-group">
                                            <label>Teacher</label>
                                            <select type="text" class="form-control" id="teacher_Name" name="teacher_Name" value="" required="" >
												<?php 
													$sql = $DBcon->prepare("SELECT * FROM teachermaster");
													$sql->execute();
													while($result = $sql->fetch(PDO::FETCH_ASSOC)){
																									
												?>
                                                
												<option value="<?php echo $result['teacher_Name']; ?>"><?php echo $result['teacher_Name']; ?></option>
												<?php 
													}   
												?>             
											</select>
                                        </div>
										
										
										
																				
										<div class="form-group">
                                            <label>Class </label>
                                            <select type="text" class="form-control" id="class_Name" name="class_Name" value="" required="" >
                                            <?php
												$sql = $DBcon->prepare("SELECT * FROM classmaster");
												$sql->execute();
												while($result = $sql->fetch(PDO::FETCH_ASSOC)){
											?>
											
											<option value="<?php echo $result['class_Name']; ?>"><?php echo $result['class_Name']; ?></option>
                                            <?php 
													}   
												?>  
											
                                            </select>
                                        </div>
										
										
										
										<div class="form-group">
                                            <label>Section</label>
                                            <!--<select class="form-control">-->
											<select type="text" class="form-control" id="section_Name" name="section_Name" value="" required="" >
												<?php
												
													$sql = $DBcon->prepare("SELECT * FROM sectionmaster");
													$sql->execute();
													while($result = $sql->fetch(PDO::FETCH_ASSOC)){
												?>
										
                                                <option value="<?php echo $result['section_Name']; ?>"><?php echo $result['section_Name']; ?></option>
                                                 <?php 
													}   
												?> 
                                            </select>
                                        </div>
										
											
                                        <!--<button type="button" class="btn btn-primary">Submit Button</button>-->
										<button type="button" class="btn btn-success btn-block" name="insert-data" id="insert-data" onclick="insertData()">Insert Data</button>
                                        <p id="message"></p>
                                        
                                    </form>
                                </div>
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>

<script type="text/javascript">
 
  function insertData() {
    var teacher_Name=$("#teacher_Name").val();
    var class_Name=$("#class_Name").val();
    var section_Name=$("#section_Name").val();
	
    alert(teacher_Name);
    alert(class_Name);
    alert(section_Name);
	
	if (teacher_Name =='')
	{
		alert("please Enter the class_Name");
	}
	else{
	
 
// AJAX code to send data to php file.
        $.ajax({
            type: "POST",
            url: "insert_teacherasingmaster.php",
            data: {teacher_Name:teacher_Name,class_Name:class_Name,section_Name:section_Name},
            dataType: "JSON",
            success: function(data) {
             $("#message").html(data);
            $("p").addClass("alert alert-success");
            },
            error: function(err) {
            alert(err);
            }
        });
		
		
	}
}
 
</script>