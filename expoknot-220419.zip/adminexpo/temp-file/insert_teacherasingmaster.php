<?php

require_once("config.php");
  
$teacher_Name = $_POST['teacher_Name'];
$class_Name = $_POST['class_Name'];
$section_Name = $_POST['section_Name'];

$stmt = $DBcon->prepare("INSERT INTO teacherasingmaster(teacher_Name, class_Name, section_Name) VALUES(:teacher_Name, :class_Name, :section_Name)");

$stmt->bindparam(':teacher_Name', $teacher_Name);
$stmt->bindparam(':class_Name', $class_Name);
$stmt->bindparam(':section_Name', $section_Name);

if($stmt->execute())
{
  $res="Data Inserted Successfully:";
  echo json_encode($res);
}
else {
  $error="Not Inserted,Some Probelm occur.";
  echo json_encode($error);
}

?>
