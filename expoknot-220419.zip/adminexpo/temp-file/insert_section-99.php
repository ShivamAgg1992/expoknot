<?php
//include('connect-db.php');
require_once("config.php");

echo $section_Name = $_GET['section_Name'];
//echo $section_Name = 'C';

$sql = $DBcon->prepare("SELECT * FROM sectionmaster where section_Name = '$section_Name'");
$sql->execute();
while($result = $sql->fetch(PDO::FETCH_ASSOC)){

echo $section_val=$result['section_Name'];
}

echo "Hello=".$section_val;
echo $section_Name;

if($section_val == $section_Name)
{
	echo "Data exit is ".$section_Name;
	//$res="Data exit";
	//echo json_encode($res);
	$error="Not Inserted,Some Probelm occur.";
	echo json_encode($error);
}
else 
{
		$stmt = $DBcon->prepare("INSERT INTO sectionmaster(section_Name) VALUES(:section_Name)");

		$stmt->bindparam(':section_Name', $section_Name);

	if($stmt->execute())
	{
		$res="Data Inserted Successfully:";
		echo json_encode($res);
	
	}
	else 
	{
		$error="Not Inserted,Some Probelm occur.";
		echo json_encode($error);
	}
}
?>

