<?php

require_once("config.php");
  
$class_Name = $_POST['class_Name'];

$stmt = $DBcon->prepare("INSERT INTO classmaster(class_Name) VALUES(:class_Name)");

$stmt->bindparam(':class_Name', $class_Name);

if($stmt->execute())
{
  $res="Data Inserted Successfully:";
  echo json_encode($res);
}
else {
  $error="Not Inserted,Some Probelm occur.";
  echo json_encode($error);
}

 ?>
