<?php
/*
 * @author Shahrukh Khan
 * @website http://www.thesoftwareguy.in
 * @facebbok https://www.facebook.com/Thesoftwareguy7
 * @twitter https://twitter.com/thesoftwareguy7
 * @googleplus https://plus.google.com/+thesoftwareguyIn
 */
require_once("config.php");
if (isset($_SESSION["user_id"]) && $_SESSION["user_id"] != "") {
    // if logged in send to dashboard page
	if ( $_SESSION["rolecode"] == 'SUPERADMIN')
	{
		redirect("dashboard.php");
	}
	else if ( $_SESSION["rolecode"] == 'ADMIN')
	{
		redirect("user.php");
	}
}

include 'header.php';

if(isset($_REQUEST['class_Name']) && $_REQUEST['class_Name'] == '0') { 
  echo 'Please select a class_Name.'; 
}
?>

        <div id="page-wrapper">
            <div class="row">
               <div class="col-lg-12">
                    <h1 class="page-header">Forms</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Class Master
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form"  id="loginForm" action="" method="">
									
										<!--<div class="form-group">
                                            <label>Choose Class </label>
                                           
                                            <select type="text" class="form-control" id="class_Name" name="class_Name" value="" required="" >
                                                <option value="">Select the Class</option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                            </select>
                                        </div>-->
										
									<div class="form-group">
										<label for="class_Name" class="control-label">Enter Class Name</label>
										<input type="text" class="form-control" id="class_Name" name="class_Name" value=""  title="Please enter you Name" placeholder="" required >
										<span class="help-block"></span>
									</div>
										
                                        <!--<div class="form-group">
                                            <label>Class</label>
                                            <input class="form-control" placeholder="Please Enter the Class">
                                        </div>-->
                                        
                                       
                                       <!-- <input type="submit" class="btn btn-primary"/>-->
										<button type="button" class="btn btn-success btn-block" name="insert-data" id="insert-data" onclick="insertData()">Insert Data</button>
                                        <p id="message"></p>
                                    </form>
                                </div>
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>


<script type="text/javascript">
 
  function insertData() {
    //var class_Name=$("#class_Name").val();
    var class_Name=$("#class_Name").val();
    //alert(class_Name);
	if (class_Name =='')
	{
		alert("please Enter the class_Name");
	}
	else{
	
 
// AJAX code to send data to php file.
        $.ajax({
            type: "POST",
            url: "class_entry.php",
            data: {class_Name:class_Name},
            dataType: "JSON",
            success: function(data) {
             $("#message").html(data);
            $("p").addClass("alert alert-success");
            },
            error: function(err) {
            alert(err);
            }
        });
		
		
	}
}
 
</script>

<script type="text/javascript">

$(document).ready(function(){
    $('[id^=class_Name]').keypress(validateNumber);
});

function validateNumber(event) 
{
    var key = window.event ? event.keyCode : event.which;
    if (event.keyCode === 8 || event.keyCode === 46) {
        return true;
    } else if ( key < 48 || key > 57 ) {
        alert("Please enter only no.");
        return false;
    } else {
    	return true;
    }
};


</script>