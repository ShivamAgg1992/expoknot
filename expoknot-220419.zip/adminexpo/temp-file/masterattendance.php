<?php
/*
 * @author Shahrukh Khan
 * @website http://www.thesoftwareguy.in
 * @facebbok https://www.facebook.com/Thesoftwareguy7
 * @twitter https://twitter.com/thesoftwareguy7
 * @googleplus https://plus.google.com/+thesoftwareguyIn
 */
require_once("config.php");
if (!isset($_SESSION["user_id"]) || $_SESSION["user_id"] == "") {
    // not logged in send to login page
    redirect("index.php");
}

include 'header.php';
?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Forms</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Class Master
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<form role="form">
                                <div class="col-lg-12">
                                    
									
										<div class="col-lg-4">
                                            <label>Date</label>
                                            <select class="form-control">
                                                <option>Chose Class </option>
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>
										<div class="col-lg-4">
                                            <label>Class</label>
                                            <select class="form-control">
                                                <option>Chose Class </option>
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>
										<div class="col-lg-4">
                                            <label>Section</label>
                                            <select class="form-control">
                                                <option>Chose Section </option>
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>
										
                                        <!--<div class="form-group">
                                            <label>Class</label>
                                            <input class="form-control" placeholder="Please Enter the Class">
                                        </div>-->
										
										
                                        
                                       
                                        
                                </div>
								 
								 <li class="divider" style=""></li>
								 
						<div class="col-lg-12">
								<div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            
                                            <th style="width: 6%; text-align: center;">
                                                S.No.                                                
                                            </th>
                                            <th>
                                                Name                                                
                                            </th>
                                            <th>
                                                Father Name                                                
                                            </th>
                                            <th style="width: 10%; text-align: center;">
												Attendance
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                        <tr>
                                            
                                            <td>1</td>
                                            <td>Monty</td>
                                            <td>Jayprakash</td>
                                            <td>
												<select class="form-control">
													<option>P</option>
													<option>A</option>
													
												</select>
											</td>
                                        </tr>
                                        <tr>
                                            
                                           <td>1</td>
                                            <td>Sanddep</td>
                                            <td>Ram Veer</td>
                                            <td>
												<select class="form-control">
													<option>P</option>
													<option>A</option>
													
												</select>
											</td>
                                        </tr>
                                        
                                       
                                    </tbody>
                                </table>
                            </div>
						</div>
						
						<button type="button" class="btn btn-primary">Submit Button</button>
                                        
                    </form>
                                
                            </div>
                            <!-- /.row (nested) -->
							
							
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>