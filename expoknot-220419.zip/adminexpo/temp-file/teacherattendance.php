<?php
/*
 * @author Shahrukh Khan
 * @website http://www.thesoftwareguy.in
 * @facebbok https://www.facebook.com/Thesoftwareguy7
 * @twitter https://twitter.com/thesoftwareguy7
 * @googleplus https://plus.google.com/+thesoftwareguyIn
 */
require_once("config.php");
/* if (!isset($_SESSION["user_id"]) || $_SESSION["user_id"] == "") {
    // not logged in send to login page
    redirect("index.php");
} */

include 'header.php';
?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Attendance</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
			
			
	<?php
 
		/* $cudate = date('Y-m-d');
		echo "<br>";
		$sql = "select attendDate from attendance_master where type='Marketing' and transId='$login_session' and convert(varchar(10),attendDate,120)=convert(varchar(10),'$cudate',120) and cmpCode='1'";
	 	$stmt = sqlsrv_query( $conn, $sql );
		$tid = 0;
		while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
	
		 $tid = $tid+1;
		}

		if($tid >0)

		{
			echo "<p style='color: Red;text-align: center;min-height: 200px;padding-top: 12%;'>Attendance Already Exist.</p>";
		}
	
		else { */

		?>
            <!-- /.row -->
			
		
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            
                            <div class="table-responsive">
							<form action="#" method="post"> 
							<!--<form action="attendancesubmit.php" method="post"> -->
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            
                                            <th style="width: 6%;">
                                                S.No.                                                
                                            </th>
                                            <th>
                                                Roll No                                                
                                            </th>
											<th>
                                                Name                                                
                                            </th>
                                            <th>
                                                Father Name                                                
                                            </th>
                                            <th style="width: 18%;">
												Attendance
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>

<!--
                                        <tr>
                                            
                                            <td>1</td>
                                            <td>750px</td>
                                            <td>970px</td>
                                            <td>1170px</td>
                                        </tr>
                                        <tr>
                                            
                                            <td>
                                                <code>2</code>
                                            </td>
                                            <td>
                                                <code>.col-sm-</code>
                                            </td>
                                            <td>
                                                <code>.col-md-</code>
                                            </td>
                                            <td>
                                                <code>.col-lg-</code>
                                            </td>
                                        </tr>-->
<?php                                        
                                     
/* $sql_sup = "SELECT * FROM dbo.supervisor_master WHERE asmCode='$login_session' and startStatus='1' and convert(varchar(10),getDate(),120)>=convert(varchar(10),$doj,120) and endStatus='0'";
	$stmt = sqlsrv_query( $conn, $sql_sup ); */
	
	
	/* $i=1; while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
		$i=$i+1; */
	?>
	<tr>
	<td style="width: 10%;"><input type="text" name="part_id[]" Value="<?php echo $i; ?>" placeholder="S.No." readonly></td>
	<td style="width: 17%;"><input type="text" name="reg_No[]" Value="<?php echo $row['id']; ?>" placeholder="Roll No" readonly></td>
	<td><input type="text" name="quantity[]" Value="<?php echo $row['student_Name']; ?>" placeholder="Student Name" readonly></td>
	<td><input type="text" name="designationName[]" Value="father_Name" placeholder="Father's Name" readonly></td>
	<td><select name="price[]" style="margin-bottom: 20px; margin-top: 10px; width: 100%; padding: 7px; border-radius: 5px; border: 1px solid #7ac9b7;" >
				<option value="P">P</option>
				<option value="A">A</option>
				</select></td>
				<td><input type="hidden" name="teacher_Name[]" Value="<?php echo $teacher_Name; ?>" placeholder="Teacher Name" readonly></td>
				<td><input type="hidden" name="teacher_id[]" Value="<?php echo $row['teacher_id']; ?>" placeholder="Teacher ID" readonly></td>
				
				</tr>
				<?php
				
				
	//}
	
				?>
				</tbody>
	<input type="submit" value="Submit" id="submit">		
</form>									 
                                    
                                </table>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            

          


        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>