<?php
//include('connect-db.php');
require_once("config.php");

$section_Name = $_POST['section_Name'];
//$section_Name = $_POST['section_Name'];

$stmt = $DBcon->prepare("INSERT INTO sectionmaster(section_Name) VALUES(:section_Name)");

$stmt->bindparam(':section_Name', $section_Name);

if($stmt->execute())
{
  $res="Data Inserted Successfully:";
  echo json_encode($res);
}
else {
  $error="Not Inserted,Some Probelm occur.";
  echo json_encode($error);
}

?>
