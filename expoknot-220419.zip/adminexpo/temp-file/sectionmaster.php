<?php
/*
 * @author Shahrukh Khan
 * @website http://www.thesoftwareguy.in
 * @facebbok https://www.facebook.com/Thesoftwareguy7
 * @twitter https://twitter.com/thesoftwareguy7
 * @googleplus https://plus.google.com/+thesoftwareguyIn
 */
require_once("config.php");
if (!isset($_SESSION["user_id"]) || $_SESSION["user_id"] == "") {
    // not logged in send to login page
    redirect("index.php");
}

include 'header.php';
?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Forms</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Section Master
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form"  id="loginForm" action="" method="">
                                        
										<!--<div class="form-group">
                                            <label>Choose Class </label>
                                            <select class="form-control">
                                                <option>Chose </option>
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>-->
										
										<!--<div class="form-group">
                                            <label>Section</label>
                                            <select type="text" class="form-control" id="section_Name" name="section_Name" value="" required="" >
                                                <option value="">Select the Class</option>
                                                <option value="1">A</option>
                                                <option value="2">B</option>
                                                <option value="3">C</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                            </select>
                                        </div>-->
										
										<div class="form-group">
										<label for="section_Name" class="control-label">Enter Section Name</label>
										<input type="text" class="form-control" id="section_Name" name="section_Name" maxlength="2" style="text-transform: uppercase;" value=""  title="Please enter you Name" placeholder="" required >
										<span class="help-block"></span>
										</div>
                                        
                                       
                                        <!--<button type="button" class="btn btn-primary">Submit Button</button>-->
										<button type="button" class="btn btn-success btn-block" name="insert-data" id="insert-data" onclick="insertData()">Insert Data</button>
                                        <p id="message"></p>
										
                                        
                                    </form>
                                </div>
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>

<script type="text/javascript">
 
  function insertData() {
    var section_Name=$("#section_Name").val();
    //alert(class_Name);
	if (section_Name =='')
	{
		alert("please choose the section_Name");
	}
	else{
	 
// AJAX code to send data to php file.
        $.ajax({
            type: "POST",
            url: "insert_section.php",
            data: {section_Name:section_Name},
            dataType: "JSON",
            success: function(data) {
             $("#message").html(data);		 
            $("p").addClass("alert alert-success");
            },
            error: function(err) {
            alert(err);
            }
        });
		
		
	}
}
 
</script>


<script type="text/javascript">

$(document).ready(function(){
    $('[id^=section_Name]').keypress(validateNumber);
});

function validateNumber()
{

if ((event.keyCode > 64 && event.keyCode < 91) || (event.keyCode > 96 && event.keyCode < 123) || event.keyCode == 8)
   return true;
else
   {
       alert("Please enter only char");
       return false;
   }

}
</script>