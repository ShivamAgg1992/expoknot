<?php

require_once("config.php");
  
$teacher_Name = $_POST['teacher_Name'];
$phone_No = $_POST['phone_No'];
$email_Id = $_POST['email_Id'];
$address_Name = $_POST['address_Name'];
$photo_Id = $_POST['photo_Id'];

$stmt = $DBcon->prepare("INSERT INTO teachermaster(teacher_Name, phone_No, email_Id, address_Name, photo_Id) VALUES(:teacher_Name, :phone_No, :email_Id), :address_Name, :photo_Id");

$stmt->bindparam(':teacher_Name', $teacher_Name);
$stmt->bindparam(':phone_No', $phone_No);
$stmt->bindparam(':email_Id', $email_Id);
$stmt->bindparam(':address_Name', $address_Name);
$stmt->bindparam(':photo_Id', $photo_Id);


if($stmt->execute())
{
  $res="Data Inserted Successfully:";
  echo json_encode($res);
}
else {
  $error="Not Inserted,Some Probelm occur.";
  echo json_encode($error);
}

 ?>
