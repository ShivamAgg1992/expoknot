 <?php
//include 'config.php';
include('connect-db.php');

//echo "<br>";

 
//$part_id = $_POST['part_id'];
$student_id = $_POST['student_id'];
$sr_No =$_POST['sr_No'];
$roll_No =$_POST['roll_No'];
$student_Name = $_POST['student_Name'];
$father_Name = $_POST['father_Name']; 
$price = $_POST['price']; 
//$teacher_Name = $_POST['teacher_Name'];
$class_id =$_POST['class_id'];
$section_id =$_POST['section_id'];


/*print_r($part_id);echo "<br>";
print_r($student_id);echo "<br>";
print_r($student_Name);echo "<br>";
print_r($father_Name);echo "<br>";
print_r($price);echo "<br>";
print_r($teacher_Name);echo "<br>";
print_r($teacher_id);echo "<br>";
print_r($class_id);echo "<br>";
print_r($section_id);*/

 echo $totalpart_id = sizeof($roll_No);

 for($i=0;$i<$totalpart_id;$i++) {

    
	 $Insertpart_id = $roll_No[$i];
	 $Insertsr_No = $sr_No[$i];
     $Insertreg_No = $student_id[$i];
     $Insertstudent_Name = $student_Name[$i];
     $Insertfather_Name = $father_Name[$i];
     $Insertprice = $price[$i];
	// $Insertteacher_Name = $teacher_Name[$i];
     //$Insertteacher_id = $teacher_id[$i];
     $Insertclass_id = $class_id[$i];
     $Insertsection_id = $section_id[$i]; 
    
	

	if (empty($student_id[$i]) || empty($roll_No[$i]) || empty($sr_No[$i]) || empty($student_Name[$i]) || empty($father_Name[$i])|| empty($price[$i]) || empty($class_id[$i])|| empty($section_id[$i])) {
	
    continue;
	}	
		
	$items[]=array(
    "student_id"      => $student_id[$i],
	"roll_No"     => $roll_No[$i], 
    "sr_No"     => $sr_No[$i], 
    "student_Name"    => $student_Name[$i],
    "father_Name" => $father_Name[$i],
	"class_id"   => $class_id[$i],      
	"section_id"   => $section_id[$i], 
	"price"   => $price[$i],
	     
	 );
} 


print_r($items);
//$date = date('Y-m-d',time()-(86400*1));

$date = date("Y-m-d");
$transDate = date("Y-m-d h:i:s A");
$transTime = date("Y-m-d h:i:s A");
$type = "Marketing";
$timeIn = date("Y-m-d h:i:s A");
$timeOut =  date("Y-m-d h:i:s A");
$attendDate = date("Y-m-d h:i:s A");
$mode = "S";
$cmpCode ="1";
$status ="1";
//$teacher_id ="2";


 
if (!empty($items)) {

$values = array();

foreach($items as $item){
//    $values[] = "('{$item['reg_No']}', '$transDate', '$transTime', '$type', '{$item['teacher_Name']}', '{$item['teacher_id']}', '{$item['student_Name']}', '{$item['father_Name']}','$timeIn', '$timeOut', '$attendDate', '{$item['price']}', '$mode', '$cmpCode', '$status')";
   
   // $values[] = "('{$item['part_id']}', '{$item['student_id']}', '{$item['student_Name']}', '{$item['father_Name']}', '{$item['class_Name']}', '{$item['section_Name']}', '{$item['teacher_id']}', '{$item['price']}', '$date')";
	
	$values[] = "('{$item['student_id']}','{$item['roll_No']}','{$item['sr_No']}','{$item['student_Name']}','{$item['father_Name']}','{$item['class_id']}','{$item['section_id']}','{$item['price']}','$date')";
   
   //$values[] = "('{$item['reg_No']}', '$transDate', '$transTime', '$type', '{$item['teacher_Name']}', '{$item['teacher_id']}', '{$item['student_Name']}', '{$item['father_Name']}','$timeIn', '$timeOut', '$attendDate', '{$item['price']}', '$mode', '$cmpCode', '$status')";
}
} 



print_r($values);

$values = implode(",", $values);


//echo $sql = "INSERT INTO dbo.attendance_master (id, sNo, asmName, execName, designationName, date, attendance) VALUES {$values};" ;
//echo $sql = "INSERT INTO `attendancemaster`(`part_id`, `student_id`, `student_Name`, `father_Name`, `class_Name`, `section_Name`, `teacher_id`, `attendance`, `date`) VALUES  {$values};" ;

//$sql = "INSERT INTO `attendancemaster`(`part_id`, `student_id`, `student_Name`, `father_Name`, `class_id`, `section_id`, `teacher_id`, `attendance`, `date`) VALUES  {$values};" ;

$sql = "INSERT INTO `attendancemaster`( `student_id`, `roll_No`, `sr_No`, `student_Name`, `father_Name`, `class_id`, `section_id`,  `attendance`, `date`) VALUES  {$values};" ;

///////////////////////////////////////////////////////////////////
echo "<br>";

 mysql_query($sql)
 or die(mysql_error()); 
 
 echo "<br>";
 
 echo '<script>window.location.href = "teacherdashboard.php";</script>';
 //header("Location: teacherdashboard.php");
 //header("Location: http://www.yourwebsite.com/user.php");
 //echo "Hello";
  
 
/*  if( $stmt === false) {
    die( print_r( sqlsrv_errors(), true) );
}

else {
	
header("Location: dashboard.php"); 	
}  */
?> 

<?php
/* Redirect browser */
//header("Location: http://www.yourwebsite.com");
//echo '<script>window.location.href = "teacherdashboard.php";</script>';
/* Make sure that code below does not get executed when we redirect. */
//exit;
?>