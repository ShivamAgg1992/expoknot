<?php
require_once("connect-db.php");




echo $exhibition_Name = $_POST['exhibition_Name'];
echo $exhibition_Industry = $_POST['exhibition_Industry'];
//echo $date = $_POST['date'];
echo $date = date();
//echo $time = $_POST['time'];
echo $time = time();
echo $locaton = $_POST['locaton'];


//echo $logoToUpload = $_FILES['logoToUpload']['name'];


echo $organizer_Name = $_POST['organizer_Name'];
echo $visitor_Profile = $_POST['visitor_Profile'];
echo $exhibitor_Profile = $_POST['exhibitor_Profile'];
echo $venue = $_POST['venue'];
echo $description = $_POST['description'];



echo $currentDir = "/home/rsiinfo/public_html/expoknot/";
    $uploadDirectory = "/images/gallery/";
    

    $errors = []; // Store all foreseen and unforseen errors here

    $fileExtensions = ['jpeg','jpg','png']; // Get all the file extensions

    $fileName = $_FILES['logoToUpload']['name'];
    $fileSize = $_FILES['logoToUpload']['size'];
    $fileTmpName  = $_FILES['logoToUpload']['tmp_name'];
    $fileType = $_FILES['logoToUpload']['type'];
    $fileExtension = strtolower(end(explode('.',$fileName)));

    echo $uploadPath = $currentDir . $uploadDirectory . basename($fileName); 
    

    if (isset($_POST['submit'])) {

        if (! in_array($fileExtension,$fileExtensions)) {
            $errors[] = "This file extension is not allowed. Please upload a JPEG or PNG file";
        }

        if ($fileSize > 2000000) {
            $errors[] = "This file is more than 2MB. Sorry, it has to be less than or equal to 2MB";
        }

        if (empty($errors)) {
            $didUpload = move_uploaded_file($fileTmpName, $uploadPath);
            

            if ($didUpload) {
                echo "The file " . basename($fileName) . " has been uploaded";
				echo '<script>window.location.href = "gallery_upload.html";</script>';
            } else {
                echo "An error occurred somewhere. Try again or contact the admin";
            }
        } else {
            foreach ($errors as $error) {
                echo $error . "These are the errors" . "\n";
            }
        }
    }




//$sql = "INSERT INTO `Exhibition_details`(`Exhibition_Unique_ID`, `Exhibition_name`, `Exhibition_Industry`, `Description`, `organizer_unique_id`, `Organizer_Name`, `Visitor_Profile`, `Exhibitor_Profile`, `Exhibition_Pics`, `Location`, `Venue`, `Date`, `Time`) VALUES ('6','$exhibition_Name','$exhibition_Industry','$description','55','$organizer_Name','$visitor_Profile','$exhibitor_Profile','$logoToUpload','$locaton','$venue','$date','$time',)" ;
$sql = "INSERT INTO `Exhibition_details`(`Exhibition_Unique_ID`,`Exhibition_name`, `Exhibition_Industry`, `Description`, `organizer_unique_id`, `Organizer_Name`, `Visitor_Profile`, `Exhibitor_Profile`, `Exhibition_Pics`, `Location`, `Venue`, `Date`, `Time`) VALUES ('5','$exhibition_Name','$exhibition_Industry','$description','55','$organizer_Name','$visitor_Profile','$exhibitor_Profile','$uploadPath','$locaton','$venue','$date','$time')" ;

//$sql = "INSERT INTO `Exhibition_details`(`Exhibition_name`, `Exhibition_Industry`, `Description`,  `Organizer_Name`, `Visitor_Profile`, `Exhibitor_Profile`, `Exhibition_Pics`, `Location`, `Venue`, `Date`, `Time`) VALUES ('$exhibitors_Name','$industry','$description','$stall_No','$email_Id','$tag_Line','$address','$product_Name','$logoToUpload','$comToimages','$broTopdf','$poc_Name','$poc_Description','$poc_Phone','$facebook','$twitter','$linkdin','$instagram','$youtube','$website')" ;


mysql_query($sql)
 or die(mysql_error()); 
 
 
 // echo '<script>window.location.href = "index.html";</script>';
 
 


/* $result = mysql_query("SELECT * FROM Exhibition_details")
		or die(mysql_error());  

	while($row = mysql_fetch_array( $result )) 
	{
		 echo $oprId=$row['Exhibition_name'];
		 
	} */
	
	

?>
