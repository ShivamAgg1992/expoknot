<?php
require_once("connect-db.php");




echo $exhibition_Name = $_POST['exhibition_Name'];
echo $exhibition_Industry = $_POST['exhibition_Industry'];
//echo $date = $_POST['date'];
echo $date = date();
//echo $time = $_POST['time'];
echo $time = time();
echo $locaton = $_POST['locaton'];


echo $logoToUpload = $_FILES['logoToUpload']['name'];


echo $organizer_Name = $_POST['organizer_Name'];
echo $visitor_Profile = $_POST['visitor_Profile'];
echo $exhibitor_Profile = $_POST['exhibitor_Profile'];
echo $venue = $_POST['venue'];
echo $description = $_POST['description'];


echo $target_dir = "/home/rsiinfo/public_html/expoknot/images/gallery/";
echo $target_file = $target_dir . basename($_FILES["logoToUpload"]["name"]);   
echo $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
echo $extensions_arr = array("jpg","jpeg","png","gif");
if( in_array($imageFileType,$extensions_arr) )
{
 move_uploaded_file($_FILES['logoToUpload']['tmp_name'],$target_dir.$logoToUpload);
}



//$sql = "INSERT INTO `Exhibition_details`(`Exhibition_Unique_ID`, `Exhibition_name`, `Exhibition_Industry`, `Description`, `organizer_unique_id`, `Organizer_Name`, `Visitor_Profile`, `Exhibitor_Profile`, `Exhibition_Pics`, `Location`, `Venue`, `Date`, `Time`) VALUES ('6','$exhibition_Name','$exhibition_Industry','$description','55','$organizer_Name','$visitor_Profile','$exhibitor_Profile','$logoToUpload','$locaton','$venue','$date','$time',)" ;
$sql = "INSERT INTO `Exhibition_details`(`Exhibition_Unique_ID`,`Exhibition_name`, `Exhibition_Industry`, `Description`, `organizer_unique_id`, `Organizer_Name`, `Visitor_Profile`, `Exhibitor_Profile`, `Exhibition_Pics`, `Location`, `Venue`, `Date`, `Time`) VALUES ('5','$exhibition_Name','$exhibition_Industry','$description','55','$organizer_Name','$visitor_Profile','$exhibitor_Profile','$logoToUpload','$locaton','$venue','$date','$time')" ;

//$sql = "INSERT INTO `Exhibition_details`(`Exhibition_name`, `Exhibition_Industry`, `Description`,  `Organizer_Name`, `Visitor_Profile`, `Exhibitor_Profile`, `Exhibition_Pics`, `Location`, `Venue`, `Date`, `Time`) VALUES ('$exhibitors_Name','$industry','$description','$stall_No','$email_Id','$tag_Line','$address','$product_Name','$logoToUpload','$comToimages','$broTopdf','$poc_Name','$poc_Description','$poc_Phone','$facebook','$twitter','$linkdin','$instagram','$youtube','$website')" ;


mysql_query($sql)
 or die(mysql_error()); 
 
 
 // echo '<script>window.location.href = "index.html";</script>';
 
 


/* $result = mysql_query("SELECT * FROM Exhibition_details")
		or die(mysql_error());  

	while($row = mysql_fetch_array( $result )) 
	{
		 echo $oprId=$row['Exhibition_name'];
		 
	} */
	
	

?>
