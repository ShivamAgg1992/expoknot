<?php

include('session.php');

include 'header.php';

?>

        <div id="page-wrapper">
            <div class="row">
               <div class="col-lg-12">
                    <h1 class="page-header">Section Master</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
			
			 <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Section Master
                        </div>
                        <div class="panel-body">
				<div class="col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            View Section Name
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>S.No.</th>
											<th>Class Name</th>
                                            <th>Section Name</th>
                                            
                                          
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
									
										//$result = mysql_query("SELECT * FROM `sectionmaster` ") 
										$result = mysql_query("SELECT sm.id,sm.class_id,cm.class_Name,sm.section_Name FROM sectionmaster sm left join classmaster cm on sm.class_id=cm.id") 
										or die(mysql_error());  
										$i=1;
										while($row = mysql_fetch_array( $result )) 
										{
											
											//$getClass = $row['class_Name'];
									
                                        echo '<tr><td>'.$i.'</td><td>'.$row['class_Name'].'</td><td>'.$row['section_Name'].'</td></tr>';
										$i=$i+1;
										}
										?>
                                        <!--<tr>
                                            <td>1</td>
                                            <td>Mark</td>
                                            
                                        </tr>-->
                                        
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
				
				<div class="col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Add Section Name
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <form role="form"  id="loginForm" action="section_entry.php" method="post">
									
									<div class="form-group">
                                        <label>Choose Class </label>
                                           
                                        <select type="text" class="form-control" id="class_Name" name="class_Name" onchange="showClass(this.value)" value="" required="" >
                                                <option value="">Select the Class</option>
                                                
												<?php
									
										$result = mysql_query("SELECT * FROM `classmaster` ") 
										or die(mysql_error());  
										$i=1;
										while($row = mysql_fetch_array( $result )) 
										{
											
											//$getClass = $row['class_Name'];
									
                                        
										?>
												
												<option value="<?php echo $row['class_Name'];?>"><?php echo $row['class_Name'];?></option>
                                                
												<?php
										}
												?>
                                        </select>
                                    </div>
										
									<!--<div class="form-group">
										<label for="section_Name" class="control-label">Enter Section Name</label>
										<span style="color: red;font-size: 10px;">* Must Be Entered Block Letter.</span>
										<input type="text" class="form-control" id="section_Name" name="section_Name" value="" onkeyup="showCustomer(this.value)" title="Please enter you Name" placeholder="" required >
										<span class="help-block"></span>
									</div>-->
										
                                        <!--<div class="form-group">
                                            <label>Class</label>
                                            <input class="form-control" placeholder="Please Enter the Class">
                                        </div>-->
                                        
                                       
                                      <!-- <input type="submit" class="btn btn-primary"/>-->
									   			
										
                                    <p id="txtHint"></p>
										
										
                                </form>
								<p id="message"></p>
								
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
						
                            
							
							
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
			
            
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>


<script type="text/javascript">
 
  function insertData() {
    //var class_Name=$("#class_Name").val();
    var section_Name=$("#section_Name").val();
    var class_id=$("#class_id").val();
    alert("hell0");
	
	if (section_Name=='')
	{
		alert("please choose the section_Name");
	}
	else{
	
	
 
// AJAX code to send data to php file.
        $.ajax({
            type: "POST",
            url: "section_entry.php",
            data: {section_Name:section_Name,class_id:class_id},
            dataType: "JSON",
            success: function(data) {
             $("#message").html(data);
            $("p").addClass("alert alert-success");
            },
            error: function(err) {
            alert(err);
            }
        });
		
	}	
	
}
 
</script>

<script>
function showClass(str) {
  var xhttp;    
  if (str == "") {
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("txtHint").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "getclasssection.php?q="+str, true);
  xhttp.send();
}
</script>

<script>
function showCustomer(str, str2) {
  var xhttp;    
  
  //alert(str);
  var str2 = document.getElementById("class_Name").value;
  
  //alert(str2);
  
  if (str == "") {
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("txtHint").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "getsection.php?q="+str+"&&t="+str2, true);
  xhttp.send();
}


//http://ridhisidhiinfotech.com/smsa/getsection.php?q=A&&t=1
</script>

<script type="text/javascript">
/*
$(document).ready(function(){
    $('[id^=class_Name]').keypress(validateNumber);
});

function validateNumber(event) 
{
    var key = window.event ? event.keyCode : event.which;
    if (event.keyCode === 8 || event.keyCode === 46) {
        return true;
    } else if ( key < 48 || key > 57 ) {
        alert("Please enter only no.");
        return false;
    } else {
    	return true;
    }
};
*/

</script>