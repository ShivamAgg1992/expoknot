<?php

include('session.php');

echo $login_session; 

$result = mysql_query("SELECT * FROM loginmaster where oprName = '$login_session'")
		or die(mysql_error());  

	while($row = mysql_fetch_array( $result )) 
	{
		 $oprId=$row['oprId'];
		 $oprName=$row['oprName'];
		 $templateName=$row['templateName'];
	}

include 'header.php';
?>
		
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Welcome <?php echo $login_session;?></h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            User Details
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form">
                                        <!--<div class="form-group">
                                            <label>Name</label>
                                            <input class="form-control">
                                            
                                        </div>-->
										<?php
										//echo "hello".$oprId;
										$result = mysql_query("SELECT * FROM teachermaster where id = '$oprId'")
										or die(mysql_error());  

										while($row = mysql_fetch_array( $result )) 
										{
																															
										?>
										<div class="form-group">
                                                <label for="disabledSelect">Name</label>
                                                <input class="form-control" id="disabledInput" value ="<?php echo $row['teacher_Name']; ?>" type="text" placeholder="Disabled input" disabled>
                                        </div>
                                        <div class="form-group">
                                                <label for="disabledSelect">Phone No.</label>
                                                <input class="form-control" id="disabledInput" value ="<?php echo $row['phone_No']; ?>" type="text" placeholder="Disabled input" disabled>
                                        </div>
                                        <div class="form-group">
                                                <label for="disabledSelect">Email Id</label>
                                                <input class="form-control" id="disabledInput" value ="<?php echo $row['email_Id']; ?>" type="text" placeholder="Disabled input" disabled>
                                        </div>
                                        <div class="form-group">
                                                <label for="disabledSelect">Address</label>
                                                <input class="form-control" id="disabledInput" value ="<?php echo $row['address_Name']; ?>" type="text" placeholder="Disabled input" disabled>
                                        </div>
										<?php
										}
										?>
                                        
                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                <div class="col-lg-6">
                                    
									<picture src="#" > <i class="fa fa-table fa-fw"></i></picture>
									
									
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>