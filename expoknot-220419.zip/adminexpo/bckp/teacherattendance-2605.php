<?php

include('session.php');

$login_session; 

$result = mysql_query("SELECT * FROM loginmaster where oprName = '$login_session'")
		or die(mysql_error());  

	while($row = mysql_fetch_array( $result )) 
	{
		 $oprId=$row['oprId'];
		 $templateName=$row['templateName'];
	}


//include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Saint Momina School</title>

    <link href="./vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <link href="./vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <link href="./dist/css/sb-admin-2.css" rel="stylesheet">

    <link href="./vendor/morrisjs/morris.css" rel="stylesheet">

    <link href="./vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Saint Momina School</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                
				<!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                   <ul class="dropdown-menu dropdown-user">
                        <li><a href="teacherprofile.php"><i class="fa fa-user fa-fw"></i> Teacher Profile</a>
                        </li>
                        <!--<li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a></li>-->
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        <li> 
                            <a href="teacherdashboard.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                                            				
						<li>
                            <a href="teacherattendance.php"><i class="fa fa-edit fa-fw"></i> Attendance</a>
                        </li>
						
						<li>
                            <a href="teacherprofile.php"><i class="fa fa-edit fa-fw"></i> Teacher Profile</a>
                        </li>
						
						<li>
                            <a href="changepassword.php"><i class="fa fa-edit fa-fw"></i> Change Password</a>
                        </li>
						
						<li>
                            <a href="logout.php"><i class="fa fa-edit fa-fw"></i> Logout</a>
                        </li>
                      
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Attendance</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
			
			
	<?php
 
		$cudate = date('Y-m-d');
		//$cudate = date('2018-05-21');
		echo "<br>";
		//$sql = "select date from attendancemaster where `teacher_id`='1'";
	 	$result = mysql_query("select date from attendancemaster where `teacher_id`='$oprId' and date = '$cudate'");
		//$stmt = sqlsrv_query( $conn, $sql );
		$tid = 0;
		while($row = mysql_fetch_array( $result )) {
	
		 $tid = $tid+1;
		
		}

		if($tid >0)

		{
			echo "<p style='color: Red;text-align: center;min-height: 200px;padding-top: 12%;'>Today Attendance Already Submitted.</p>";
		}
	
		else { 

		?>
            <!-- /.row -->
			
		
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            
                            <div class="table-responsive">
							<!--<form action="#" method="post"> -->
							<form action="attendancesubmit.php" method="post">  
							<!--<form action="attendancesubmit.php" method="post"> -->
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            
                                            <th>
                                                S.No.                                                
                                            </th>
                                            <th>
                                                Roll No                                                
                                            </th>
											<th>
                                                Name                                                
                                            </th>
                                            <th>
                                                Father Name                                                
                                            </th>
                                            <th>
												Attendance
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>

<!--
                                        <tr>
                                            
                                            <td>1</td>
                                            <td>750px</td>
                                            <td>970px</td>
                                            <td>1170px</td>
                                        </tr>
                                        <tr>
                                            
                                            <td>
                                                <code>2</code>
                                            </td>
                                            <td>
                                                <code>.col-sm-</code>
                                            </td>
                                            <td>
                                                <code>.col-md-</code>
                                            </td>
                                            <td>
                                                <code>.col-lg-</code>
                                            </td>
                                        </tr>-->
<?php                                        
                                     
	$teacher_id=2;
	
	$result = mysql_query("SELECT * FROM `student` WHERE `teacher_id`='$oprId'")
		or die(mysql_error());  

	$i=1; 
	
	//while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) 
	while($row = mysql_fetch_array( $result )) 
	{
		$i=$i+1;
		//echo $row['student_id'];
		
?>
	<tr>
	<td><code><input type="text" name="part_id[]" Value="<?php echo $i; ?>" placeholder="S.No." readonly></code></td>
	<td><code><input type="text" name="student_id[]" Value="<?php echo $row['student_id']; ?>" placeholder="Roll No" readonly></code></td>
	<td><code><input type="text" name="student_Name[]" Value="<?php echo $row['student_Name']; ?>" placeholder="Student Name" readonly></code></td>
	<td><code><input type="text" name="father_Name[]" Value="<?php echo $row['father_Name'];?>" placeholder="Father's Name" readonly></code></td>
	<td><code><select name="price[]" style="margin-bottom: 20px; margin-top: 10px; width: 100%; padding: 7px; border-radius: 5px; border: 1px solid #7ac9b7;" >
				<option value="P">P</option>
				<option value="A">A</option>
				</select></code>
				<input type="hidden" name="teacher_Name[]" Value="<?php echo $row['teacher_Name']; ?>" placeholder="Teacher Name" readonly>
				<input type="hidden" name="teacher_id[]" Value="<?php echo $row['teacher_id']; ?>" placeholder="Teacher ID" readonly>
				<input type="hidden" name="class_Name[]" Value="<?php echo $row['class_Name']; ?>" placeholder="Teacher ID" readonly>
				<input type="hidden" name="section_Name[]" Value="<?php echo $row['section_Name']; ?>" placeholder="Teacher ID" readonly>
				</td>
				</tr>
				<?php
				
				
	}
	
				?>
				
				
				</tbody>
		
									 
                                    
                                </table>
								
								<input type="submit" value="Submit" id="submit">	
								</form>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
			
			<?php
		}
			?>
            <!-- /.row -->

            

          


        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>