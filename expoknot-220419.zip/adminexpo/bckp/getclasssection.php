<?php

include('connect-db.php');

    $get_class = mysql_real_escape_string(htmlspecialchars($_GET['q']));
   //$get_class = 2;
   
/*
	$result = mysql_query("SELECT * FROM `sectionmaster` where `class_id` = '$get_class' ") 
	or die(mysql_error());  
	while($row = mysql_fetch_array( $result )) 
	{
		 $getClass = $row['class_id'];
	}
		
	if ( $get_class == $getClass)
	{
		echo '<p style="color:red;">Section Already Exits';
		
	}
	else {
		
		echo '<input type="submit" value="Submit" id="submit">'; 
		//echo '<input type="submit" value="Submit" id="submit" onclick="insertData()">'; 
			
		
	} */

		
?>

<div class="form-group">
										<label for="section_Name" class="control-label">Enter Section Name</label>
										<span style="color: red;font-size: 10px;">* Must Be Entered Block Letter.</span>
										<input type="text" class="form-control" id="section_Name" name="section_Name" value="" onkeyup="showCustomer(this.value, <?php echo $get_class;?> )" title="Please enter you Name" placeholder="" required >
										<input type="hidden" id="class_id" name="class_id" value="<?php echo $get_class;?>">
										<span class="help-block"></span>
									</div>