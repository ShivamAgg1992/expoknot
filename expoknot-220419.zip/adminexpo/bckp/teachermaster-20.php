<?php

include('session.php');

include 'header.php';

?>

        <div id="page-wrapper">
            <div class="row">
               <div class="col-lg-12">
                    <h1 class="page-header">Forms</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Class Master
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form"  id="loginForm" action="" method="">
									
										<!--<div class="form-group">
                                            <label>Choose Class </label>
                                           
                                            <select type="text" class="form-control" id="section_Name" onchange="showCustomer(this.value)" name="section_Name" value="" required="" >
                                                <option value="">Select the Class</option>
                                                <option value="A">A</option>
                                                <option value="B">B</option>
                                                <option value="C">C</option>
                                                <option value="D">D</option>
                                                <option value="E">E</option>
                                                <option value="F">F</option>
                                                <option value="G">G</option>
                                                <option value="H">H</option>
                                                <option value="I">I</option>
                                                <option value="J">J</option>
                                            </select>
                                        </div>-->
										
									<div class="form-group">
										<label for="teacher_Name" class="control-label">Enter Class Name</label>
										<input type="text" class="form-control" id="teacher_Name" name="teacher_Name" value=""  title="Please enter you Name" placeholder="" required >
										<span class="help-block"></span>
									</div>
										
                                        <!--<div class="form-group">
                                            <label>Class</label>
                                            <input class="form-control" placeholder="Please Enter the Class">
                                        </div>-->
                                        
                                       
                                       <!-- <input type="submit" class="btn btn-primary"/>-->
										
										<button type="button" class="btn btn-success btn-block" name="insert-data" id="insert-data" onclick="insertData()">Insert Data</button>
                                        <p id="message"></p>
										
                                        <!--<p id="txtHint"></p>
										
										<input type="submit" value="Submit" id="submit" onclick="insertData()">
										<p id="message"></p>-->
                                    </form>
									
                                </div>
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>


<script type="text/javascript">
 
  function insertData() {
    //var class_Name=$("#class_Name").val();
    var teacher_Name=$("#teacher_Name").val();
    //alert(teacher_Name);
	
	if (teacher_Name=='')
	{
		alert("please choose the teacher_Name");
	}
	else{
	
	
 
// AJAX code to send data to php file.
        $.ajax({
            type: "POST",
            url: "teacher_entry.php",
            data: {teacher_Name:teacher_Name},
            dataType: "JSON",
            success: function(data) {
             $("#message").html(data);
            $("p").addClass("alert alert-success");
            },
            error: function(err) {
            alert(err);
            }
        });
		
	}	
	
}
 
</script>

<script>
/*function showCustomer(str) {
  var xhttp;    
  if (str == "") {
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("txtHint").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "getTeacher.php?q="+str, true);
  xhttp.send();
}*/
</script>

<script type="text/javascript">
/*
$(document).ready(function(){
    $('[id^=class_Name]').keypress(validateNumber);
});

function validateNumber(event) 
{
    var key = window.event ? event.keyCode : event.which;
    if (event.keyCode === 8 || event.keyCode === 46) {
        return true;
    } else if ( key < 48 || key > 57 ) {
        alert("Please enter only no.");
        return false;
    } else {
    	return true;
    }
};

*/
</script>