<?php

include('connect-db.php');

   $get_class = mysql_real_escape_string(htmlspecialchars($_GET['q']));
   $get_class_id = mysql_real_escape_string(htmlspecialchars($_GET['t']));
   //$get_class = 'J';
   //$get_class_id = 1; 
   

	$result = mysql_query("SELECT * FROM `sectionmaster` where `section_Name` = '$get_class' and class_id ='$get_class_id'") 
	or die(mysql_error());  
	while($row = mysql_fetch_array( $result )) 
	{
		 $getClass = $row['section_Name'];
		 $getClass_id = $row['class_id'];
	}
		
	if ( $get_class == $getClass && $get_class_id ==  $getClass_id)
	{
		echo '<p style="color:red;">Already Exist';
		
	}
	else {
		
		?>
		
		<div class="form-group">
										<label for="section_Name" class="control-label">Enter Section Name</label>
										<span style="color: red;font-size: 10px;">* Must Be Entered Block Letter.</span>
										<input type="text" class="form-control" id="section_Name" name="section_Name" value="<?php echo $get_class;?>" onkeyup="showCustomer(this.value, <?php echo $get_class;?> )" title="Please enter you Name" placeholder="" required >
										<input type="hidden" id="class_id" name="class_id" value="<?php echo $get_class_id;?>">
										<span class="help-block"></span>
									</div>
		
		<?php
		echo '<input type="submit" value="Submit" id="submit">'; 
		//echo '<input type="submit" value="Submit" id="submit" onclick="insertData()">'; 
			
		
	}
		
		
?>