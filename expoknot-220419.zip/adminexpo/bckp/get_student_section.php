<?php

include('connect-db.php');

   $get_class = mysql_real_escape_string(htmlspecialchars($_GET['q']));
   //$get_class = 'J';
   //$get_class_id = 1; 
   

	/*$result = mysql_query("SELECT * FROM `sectionmaster` where `class_id` = '$get_class'") 
	or die(mysql_error());  
	while($row = mysql_fetch_array( $result )) 
	{
		 //$getClass = $row['section_Name'];
		 //$getsection_id = $row['id'];
		 
		 echo '<option value="'.$row['id'].'">' . $row['section_Name'] . '</option>';
	}*/
	echo '<label>Section</label>';
	echo '<select type="text" class="form-control" id="section_id" name="section_id" value="" required="" >';
	echo '<option value="">Chose Section Name </option>';
	
	$result = mysql_query("SELECT * FROM `sectionmaster` where `class_id` = '$get_class'") 
	or die(mysql_error()); 
	while($row = mysql_fetch_array( $result )) 
	{
		echo '<option value="'.$row['id'].'">' . $row['section_Name'] . '</option>';
	} 
	
	echo '</select>';

?>