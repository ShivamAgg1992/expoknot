<?php

include('connect-db.php');
  
/*$teacher_Name = $_POST['teacher_Name'];
$class_Name = $_POST['class_Name'];
$section_Name = $_POST['section_Name'];*/

$teacher_id = $_POST['teacher_id'];
$class_id = $_POST['class_id'];
$section_id = $_POST['section_id'];

//$get_class = 7;

	
$result = mysql_query("SELECT * FROM `teacherasingmaster` where `teacher_id` = '$teacher_id' || `section_id` = '$section_id' ") 
	or die(mysql_error());  
	while($row = mysql_fetch_array( $result )) 
	{
		 $getClass = $row['teacher_id'];
		 $getSection = $row['section_id'];
	}
		
	if ( $teacher_id == $getClass || $section_id == $getSection)
	{
		//echo '<p style="color:red;">Teacher Name Already Exits';
		
	//$result=mysql_query("INSERT INTO `teachermaster`(`teacher_Name`) VALUES ('$teacher_Name')") 
	
  $res="Teacher Already Assign";
  echo json_encode($res);
  //header("Location: viewTeacher.php");
}
else {
	
	$result=mysql_query("INSERT INTO `teacherasingmaster`(`teacher_id`, `class_id`, `section_id`) VALUES ('$teacher_id','$class_id','$section_id')") 
	or die(mysql_error());
	
  $error="Teacher Assign:";
  echo json_encode($error);
}


?>
