<?php

include('connect-db.php');
  
$get_class = $_POST['teacher_Name'];
//$get_class = 7;


//echo "Class Submitted";

//header(location: viewClass.php');
//header("Location: viewTeacher.php");
// echo '<script>window.location.href = "dashboard.php";</script>';
$result=mysql_query("INSERT INTO `teachermaster`(`teacher_Name`, `phone_No`, `email_Id`, `address_Name`, `photo_Id`, `templateName`) VALUES ('$get_class','$get_class','$get_class','$get_class','$get_class','$get_class')") 
	or die(mysql_error()); 
	
if($result > 0)
{
	//$result=mysql_query("INSERT INTO `teachermaster`(`teacher_Name`) VALUES ('$get_class')") 
	
  $res="Teacher Submitted:";
  echo json_encode($res);
  header("Location: viewTeacher.php");
}
else {
  $error="Not Teacher Submitted,Some Probelm occur.";
  echo json_encode($error);
}


?>
