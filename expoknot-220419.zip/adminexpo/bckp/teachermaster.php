<?php

include('session.php');

include 'header.php';

?>

        <div id="page-wrapper">
            <div class="row">
               <div class="col-lg-12">
                    <h1 class="page-header">Forms</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Class Master
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form"  id="loginForm" action="" method="">
									
										<!--<div class="form-group">
                                            <label>Choose Class </label>
                                           
                                            <select type="text" class="form-control" id="section_Name" onchange="showCustomer(this.value)" name="section_Name" value="" required="" >
                                                <option value="">Select the Class</option>
                                                <option value="A">A</option>
                                                <option value="B">B</option>
                                                <option value="C">C</option>
                                                <option value="D">D</option>
                                                <option value="E">E</option>
                                                <option value="F">F</option>
                                                <option value="G">G</option>
                                                <option value="H">H</option>
                                                <option value="I">I</option>
                                                <option value="J">J</option>
                                            </select>
                                        </div>-->
										
										<div class="form-group">
											<label for="teacher_Name" class="control-label">Teacher Name</label>
											<input type="text" class="form-control" id="teacher_Name" name="teacher_Name" value=""  title="Please enter you Name" placeholder="" required >
										</div>
		
										<div class="form-group">
                                            <label>Phone No.</label>
                                            <input type="text" class="form-control" id="phone_No" name="phone_No" maxlength="10" value=""  title="Please enter you Phone No" placeholder="" required >
                                        </div>	
										
										<div class="form-group">
                                            <label>Email Id</label>
                                            <input type="text" class="form-control" id="email_Id" name="email_Id" value="" onblur="validateEmail(this); title="Please enter you Email Id" placeholder="" required >
                                            <div class="email-error error" style="color: red;"></div>
                                        </div>
										
										<div class="form-group">
                                            <label>Address</label>
                                            <input type="text" class="form-control" id="address_Name" name="address_Name" value=""  title="Please enter you Address" placeholder="" required >
                                        </div>
										
										<!--<div class="form-group">
                                            <label>File input</label>
                                            <input type="file" class="form-control" id="photo_Id" name="photo_Id">
                                        </div>-->
										
        
		<button type="button" class="btn btn-success btn-block" name="insert-data" id="insert-data" onclick="insertData()">Insert Data</button>
                                        <p id="message"></p>
										
                                        <!--<p id="txtHint"></p>
										
										<input type="submit" value="Submit" id="submit" onclick="insertData()">
										<p id="message"></p>-->
                                    </form>
									
                                </div>
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>


<script type="text/javascript">
 
  function insertData() {
    //var class_Name=$("#class_Name").val();
    var teacher_Name=$("#teacher_Name").val();
    var phone_No=$("#phone_No").val();
    var email_Id=$("#email_Id").val();
    var address_Name=$("#address_Name").val();
    //var address_Name=$("#photo_Id").val();
	
		if (teacher_Name=='' || phone_No == '' || email_Id == '')
	{
		alert("please Enter the All Entry");
	}
	
	else{
	
	/*alert(teacher_Name);
	alert(phone_No);
	alert(email_Id);
	alert(teacher_Name);
	*/
 
// AJAX code to send data to php file.
        $.ajax({
            type: "POST",
            url: "teacher_entry.php",
            data: {teacher_Name:teacher_Name,phone_No:phone_No,email_Id:email_Id,address_Name:address_Name},
            dataType: "JSON",
            success: function(data) {
             $("#message").html(data);
            $("p").addClass("alert alert-success");
            },
            error: function(err) {
            alert(err);
			
			}
		});
		
	}	
	
}
 
</script>

<script>
/*function showCustomer(str) {
  var xhttp;    
  if (str == "") {
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("txtHint").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "getTeacher.php?q="+str, true);
  xhttp.send();
}*/
</script>

<script type="text/javascript">

$(document).ready(function(){
    $('[id^=phone_No]').keypress(validateNumber);
});

function validateNumber(event) 
{
    var key = window.event ? event.keyCode : event.which;
    if (event.keyCode === 8 || event.keyCode === 46) {
        return true;
    } else if ( key < 48 || key > 57 ) {
        alert("Please enter only no.");
        return false;
    } else {
    	return true;
    }
};


</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/css">
.error {color: red;}
.submit {margin-top: 10px;}
</script>

<script type="text/javascript">

$('#loginForm').on('keyup change paste cut click', '#insert-data, #email_Id', function(e) {
    var pattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i,
        emailVal = $('#email_Id').val(),
        emailErrorMsg = (!emailVal || !pattern.test(emailVal)) 
        ? 'Error validation message'
        : '';

    $('.email-error').text(emailErrorMsg);

    if (emailErrorMsg) {
        e.preventDefault();
    }
});

</script>