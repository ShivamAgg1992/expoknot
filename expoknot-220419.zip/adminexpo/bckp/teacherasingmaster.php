<?php

include('session.php');

include 'header.php';

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Teacher Assign Master</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Teacher Assign Master
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
				<div class="col-lg-5">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            View Assign Teacher
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>Teacher Name</th>
                                            <th>Class</th>
                                            <th>Section</th>
                                         </tr>
                                    </thead>
                                    <tbody>
									<?php
									
										//$result = mysql_query("SELECT * FROM `teacherasingmaster`") 
										$result = mysql_query("select tm.teacher_id,tm.teacher_id,tmm.teacher_Name,tm.class_id,cm.class_Name,tm.section_id,sm.section_Name from teacherasingmaster tm 
left join classmaster cm on tm.class_id=cm.id
left join teachermaster tmm on tm.teacher_id=tmm.id
left join sectionmaster sm on tm.section_id=sm.id") 
										or die(mysql_error());  
										$i=1;
										while($row = mysql_fetch_array( $result )) 
										{
											
											//$getClass = $row['class_Name'];
									
                                        echo '<tr><td>'.$i.'</td><td>'.$row['teacher_Name'].'</td><td>'.$row['class_Name'].'</td><td>'.$row['section_Name'].'</td></tr>';
										
										$i=$i+1;
										}
										?>
										
									
                                        
                                    </tbody>
                                </table>
								
								
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                                
					<div class="col-lg-7">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Teacher Assign Master
                        </div>
								<div class="panel-default">
                                    <form role="form">
                                       
										<div class="col-lg-4">
										 <label>Teacher </label>
                                            <select class="form-control" id="teacher_id" name="teacher_id" required >
											    <option value="">Chose Class Teacher </option>
											<?php
													$result = mysql_query("SELECT * FROM teachermaster") 
													or die(mysql_error()); 
													while($row = mysql_fetch_array( $result )) 
													{
														echo '<option value="'.$row['id'].'">' . $row['teacher_Name'] . '</option>';
													} 
											?>
                                            
                                                
                                            </select>
                                        </div>
																				
										<div class="col-lg-4">
                                            <label>Class </label>
                                            <select type="text" class="form-control" id="class_id" name="class_id" onchange="showClass(this.value)" value="" required="" >
											 <option value="">Chose Class Name </option>
                                            <?php
													$result = mysql_query("SELECT * FROM classmaster") 
													or die(mysql_error()); 
													while($row = mysql_fetch_array( $result )) 
													{
														echo '<option value="'.$row['id'].'">' . $row['class_Name'] . '</option>';
													} 
											?>
											
                                            </select>
                                        </div>
										
										
										
										<div class="col-lg-4">
                                            <label>Section</label>
                                            <!--<select class="form-control">-->
											<!--<select type="text" class="form-control" id="section_id" name="section_id" value="" required="" >
											 <option value="">Chose Section Name </option>
												<?php
													/* $result = mysql_query("SELECT * FROM sectionmaster") 
													or die(mysql_error()); 
													while($row = mysql_fetch_array( $result )) 
													{
														echo '<option value="'.$row['id'].'">' . $row['section_Name'] . '</option>';
													}  */
												?>
												<option id="txtHint"></option>
                                            </select>-->
											
											<div id="txtHint"></div>											
                                            
											
                                        </div>
										
											
                                        <!--<button type="button" class="btn btn-primary">Submit Button</button>-->
										<button type="button" class="btn btn-success btn-block" name="insert-data" id="insert-data" onclick="insertData()">Insert Data</button>
                                        <p id="message"></p>
                                        
                                    </form>
                                </div>
					</div>
					</div>
					
								
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
					
					
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>

<script type="text/javascript">
 
  function insertData() {
    var teacher_id=$("#teacher_id").val();
    var class_id=$("#class_id").val();
    var section_id=$("#section_id").val();
	
    //alert(teacher_id);
    //alert(class_id);
    //alert(section_id);
	
	if (teacher_id =='' || class_id == '' || section_id == '')
	{
		alert("please choose the values.");
	}
	else{
	
 
// AJAX code to send data to php file.
        $.ajax({
            type: "POST",
            url: "teacherasingmaster_entry.php",
            data: {teacher_id:teacher_id,class_id:class_id,section_id:section_id},
            dataType: "JSON",
            success: function(data) {
             $("#message").html(data);
            $("p").addClass("alert alert-success");
            },
            error: function(err) {
            alert(err);
            }
        });
		
		
	}
}
 
</script>

<script>
function showClass(str) {
  var xhttp;    
  
  //alert(str);
  if (str == "") {
    document.getElementById("txtHint").innerHTML = "";
	
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("txtHint").innerHTML = xhttp.responseText;
	  //alert(str);
    }
  };
  xhttp.open("GET", "getteacherassignsection.php?q="+str, true);
  xhttp.send();
}
</script>