<?php

include('session.php');

include 'header.php';

?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <!-- /.row -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Section
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>Teacher Name</th>
                                            <th>Class</th>
                                            <th>Section</th>
                                         </tr>
                                    </thead>
                                    <tbody>
									<?php
									
										$result = mysql_query("SELECT * FROM `teacherasingmaster` ") 
										or die(mysql_error());  
										$i=1;
										while($row = mysql_fetch_array( $result )) 
										{
											
											//$getClass = $row['class_Name'];
									
                                        echo '<tr><td>'.$i.'</td><td>'.$row['teacher_Name'].'</td><td>'.$row['class_Name'].'</td><td>'.$row['section_Name'].'</td></tr>';
										$i=$i+1;
										}
										?>
                                        
                                    </tbody>
                                </table>
								
								<button type="button" class="btn btn-success btn-block" name="insert-data" id="insert-data"><a href="teacherasingmaster.php" style="color: lemonchiffon;">Teacher Assign Class and Section </a></button>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>
