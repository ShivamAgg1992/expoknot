<?php

include('connect-db.php');
  
$get_class = $_POST['class_Name'];
//$get_class = 7;

$result=mysql_query("INSERT INTO `classmaster`(`class_Name`) VALUES ('$get_class')") 
	or die(mysql_error()); 
//echo "Class Submitted";

//header(location: viewClass.php');
header("Location: classmaster.php");
// echo '<script>window.location.href = "dashboard.php";</script>';
	
/*if($result > 0)
{
  $res="Class Submitted:";
  echo json_encode($res);
}
else {
  $error="Not Class Submitted,Some Probelm occur.";
  echo json_encode($error);
}*/


?>
