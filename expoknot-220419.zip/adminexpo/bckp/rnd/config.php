<?php

$servername = "localhost";
$username = "sademo";
echo $password = "Rajeev895@";
$db = "sademo";

   $conn = mysqli_connect($servername, $username, $password, $db);
     echo "Connected successfully"; 
   
    
?>