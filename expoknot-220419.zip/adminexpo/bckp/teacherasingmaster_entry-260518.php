<?php

include('connect-db.php');
  
$teacher_Name = $_POST['teacher_Name'];
$class_Name = $_POST['class_Name'];
$section_Name = $_POST['section_Name'];

//$get_class = 7;

	
$result = mysql_query("SELECT * FROM `teacherasingmaster` where `teacher_Name` = '$teacher_Name' || `section_Name` = '$section_Name' ") 
	or die(mysql_error());  
	while($row = mysql_fetch_array( $result )) 
	{
		 $getClass = $row['teacher_Name'];
		 $getSection = $row['section_Name'];
	}
		
	if ( $teacher_Name == $getClass || $section_Name == $getSection)
	{
		//echo '<p style="color:red;">Teacher Name Already Exits';
		
	//$result=mysql_query("INSERT INTO `teachermaster`(`teacher_Name`) VALUES ('$teacher_Name')") 
	
  $res="Teacher Already Assign";
  echo json_encode($res);
  //header("Location: viewTeacher.php");
}
else {
	
	$result=mysql_query("INSERT INTO `teacherasingmaster`(`teacher_Name`, `class_Name`, `section_Name`) VALUES ('$teacher_Name','$class_Name','$section_Name')") 
	or die(mysql_error());
	
  $error="Teacher Assign:";
  echo json_encode($error);
}


?>
