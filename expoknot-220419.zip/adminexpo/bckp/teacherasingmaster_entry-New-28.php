<?php

include('connect-db.php');
  
/*$teacher_Name = $_POST['teacher_Name'];
$class_Name = $_POST['class_Name'];
$section_Name = $_POST['section_Name'];*/

//$teacher_id_Name = $_POST['teacher_id'];
$teacher_id_Name = '1_Rajeev';
$arr = explode("_",$teacher_id_Name);
echo $teacher_id = $arr[0];
echo $teacher_Name = $arr[1];

//$class_id_Name = $_POST['class_id'];
$class_id_Name = '1_';
$arrc = explode("_",$class_id_Name);
echo $class_id = $arrc[0];
echo $class_Name = $arrc[1];

$section_id_Name = $_POST['section_id'];
$arrs = explode("_",$section_id_Name);
echo $section_id = $arrs[0];
echo $section_Name = $arrs[1];

//$get_class = 7;

/*	
$result = mysql_query("SELECT * FROM `teacherasingmaster` where `teacher_id` = '$teacher_id' || `section_id` = '$section_id' ") 
	or die(mysql_error());  
	while($row = mysql_fetch_array( $result )) 
	{
		 $getClass = $row['teacher_id'];
		 $getSection = $row['section_id'];
	}
		
	if ( $teacher_id == $getClass || $section_id == $getSection)
	{
		//echo '<p style="color:red;">Teacher Name Already Exits';
		
	//$result=mysql_query("INSERT INTO `teachermaster`(`teacher_Name`) VALUES ('$teacher_Name')") 
	
	$res="Teacher Already Assign";
	echo json_encode($res);
	//header("Location: viewTeacher.php");
	}
else 
{
	
	//$result=mysql_query("INSERT INTO `teacherasingmaster`(`teacher_id`, `class_id`, `section_id`) VALUES ('$teacher_id','$class_id','$section_id')") 
	//echo "Hello";
	//echo "<script>alert("Hello")</script>";
	
	$result=mysql_query("INSERT INTO `teacherasingmaster`(`teacher_id`, `class_id`, `section_id`, `teacher_Name`, `class_Name`, `section_Name`) VALUES ('$teacher_id','$class_id','$section_id','$teacher_Name','$class_Name','$section_Name')") or die(mysql_error());
	
	$error="Teacher Assign:";
	echo json_encode($error);
}
*/

?>
