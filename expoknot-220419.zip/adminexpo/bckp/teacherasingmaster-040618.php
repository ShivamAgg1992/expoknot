<?php

include('session.php');

include 'header.php';

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Teacher Assign Master</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Teacher Assign Master
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <form role="form">
                                       
										<div class="col-lg-4">
										 <label>Teacher </label>
                                            <select class="form-control" id="teacher_id" name="teacher_id" required >
											    <option value="">Chose Class Teacher </option>
											<?php
													$result = mysql_query("SELECT * FROM teachermaster") 
													or die(mysql_error()); 
													while($row = mysql_fetch_array( $result )) 
													{
														echo '<option value="'.$row['id'].'">' . $row['teacher_Name'] . '</option>';
													} 
											?>
                                            
                                                
                                            </select>
                                        </div>
																				
										<div class="col-lg-4">
                                            <label>Class </label>
                                            <select type="text" class="form-control" id="class_id" name="class_id" value="" required="" >
											 <option value="">Chose Class Name </option>
                                            <?php
													$result = mysql_query("SELECT * FROM classmaster") 
													or die(mysql_error()); 
													while($row = mysql_fetch_array( $result )) 
													{
														echo '<option value="'.$row['id'].'">' . $row['class_Name'] . '</option>';
													} 
											?>
											
                                            </select>
                                        </div>
										
										
										
										<div class="col-lg-4">
                                            <label>Section</label>
                                            <!--<select class="form-control">-->
											<select type="text" class="form-control" id="section_id" name="section_id" value="" required="" >
											 <option value="">Chose Section Name </option>
												<?php
													$result = mysql_query("SELECT * FROM sectionmaster") 
													or die(mysql_error()); 
													while($row = mysql_fetch_array( $result )) 
													{
														echo '<option value="'.$row['id'].'">' . $row['section_Name'] . '</option>';
													} 
												?>
                                            </select>
                                        </div>
										
											
                                        <!--<button type="button" class="btn btn-primary">Submit Button</button>-->
										<button type="button" class="btn btn-success btn-block" name="insert-data" id="insert-data" onclick="insertData()">Insert Data</button>
                                        <p id="message"></p>
                                        
                                    </form>
                                </div>
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>

<script type="text/javascript">
 
  function insertData() {
    var teacher_id=$("#teacher_id").val();
    var class_id=$("#class_id").val();
    var section_id=$("#section_id").val();
	
    //alert(teacher_id);
    //alert(class_id);
    //alert(section_id);
	
	if (teacher_id =='' || class_id == '' || section_id == '')
	{
		alert("please choose the values.");
	}
	else{
	
 
// AJAX code to send data to php file.
        $.ajax({
            type: "POST",
            url: "teacherasingmaster_entry.php",
            data: {teacher_id:teacher_id,class_id:class_id,section_id:section_id},
            dataType: "JSON",
            success: function(data) {
             $("#message").html(data);
            $("p").addClass("alert alert-success");
            },
            error: function(err) {
            alert(err);
            }
        });
		
		
	}
}
 
</script>