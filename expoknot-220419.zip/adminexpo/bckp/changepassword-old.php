<?php
include('session.php');

$login_session; 

$result = mysql_query("SELECT templateName FROM loginmaster where oprName = '$login_session'")
		or die(mysql_error());  

	while($row = mysql_fetch_array( $result )) 
	{
		//echo $val=$row['templateName'];
		$val=$row['templateName'];
	}
?>
<!DOCTYPE html>
<html>
<head>
<title>Change Password</title>
<!-- for-mobile-apps -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta name="keywords" content="Job Application Form Widget Responsive, Login form web template, Sign up Web Templates, Flat Web Templates, Login signup Responsive web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<!-- //for-mobile-apps -->
<link href='//fonts.googleapis.com/css?family=Questrial' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="css/j-forms.css">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<?php 
 // if there are any errors, display them
 if ($error != '')
 {
 echo '<div style="padding:4px; border:1px solid red; color:red;">'.$error.'</div>';
 }
 ?> 
<div class="content">
		<h1>Change Password</h1>
		<div class="main">
			<form class="contact-forms" action="" method="post">
			
				<!-- end /.header-->

					<!-- start name -->
					
												
						<div class="first-line">
											
						<div class="span8 main-row">
							<div class="input">
								<strong>User Name: </strong> <?php echo $login_session; ?><br/>
								
							</div>
						</div>
						
						<div class="span8 main-row">
							<div class="input">
								
								<input type="text" placeholder="Current Password" name="prePassword">
							</div>
						</div>
						
						<div class="span8 main-row">
							<div class="input">
								
								<input type="text" placeholder="New Password" name="newPassword">
							</div>
						</div>
									
	
						</div>
						<input type="submit" name="submit" value="Submit">						<div class="span6 main-row">							<div class="input">								<a href="profile.php"><img src="/images/back.png" style="width: 78px;"/></a>							</div>						</div>
					
					
					
					
			
				<!-- end /.content -->

				<div class="footer">
				    
					<!-- <button type="submit" class="primary-btn">Send</button>
					<button type="reset" class="secondary-btn">Reset</button> -->
				</div>
				<!-- end /.footer -->

			</form>
		</div>
		<!-- <p class="copy_rights">Department Master</a></p> -->
</div>
		<!-- Scripts -->
		<script src="js/jquery.1.11.1.min.js"></script>

		<!--[if lt IE 10]>
				<script src="j-folder/js/jquery.placeholder.min.js"></script>
			<![endif]-->

		<script>
			$(document).ready(function(){

				// Phone masking
				$('#phone').mask('(999) 999-9999', {placeholder:'x'});

				// Post code masking
				$('#post').mask('999-9999', {placeholder:'x'});

			});
		</script>
</body>
</html>
<?php
include('connect-db.php');
 
 
 if (isset($_POST['submit']))
 { 
 
  $prePassword = mysql_real_escape_string(htmlspecialchars($_POST['prePassword']));
  $newPassword = mysql_real_escape_string(htmlspecialchars($_POST['newPassword']));
 $login_session;
 /* if ($prePassword == '' || $newPassword == '')
 {
 
 $error = 'ERROR: Please fill in all required fields!';
 renderForm($prePassword, $newPassword, $error);
 }
 else
 {  */
 $idr = mysql_query("SELECT oprId FROM loginmaster where oprName = '$login_session' ") 
		or die(mysql_error()); 
		while($row = mysql_fetch_array( $idr )) 
		{
			 $oprId=$row['oprId'];
		}
 
 
 $result = mysql_query("SELECT oprName, password FROM loginmaster where oprId = '$oprId'") 
		or die(mysql_error()); 
		while($row = mysql_fetch_array( $result )) 
		{
			$oprName=$row['oprName'];
			$password=$row['password'];	
		}
 if ( $login_session == $oprName || $prePassword == $password)
 {
 mysql_query("UPDATE loginmaster SET password='$newPassword' where oprId = '$oprId'")
 or die(mysql_error()); 
 
 // once saved, redirect back to the view page
 if ($val == 'ADMIN')
	{
	 header("Location: dashboard.php");
	}
	elseif ($val == 'CMD')
	{
		 header("Location: teacherdashboard.php");
		
	}
	
 }
 }
 
 ?>