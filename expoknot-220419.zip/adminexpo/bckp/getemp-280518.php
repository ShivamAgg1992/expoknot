<?php
include('connect-db.php');

   $oprId = mysql_real_escape_string(htmlspecialchars($_GET['q']));

   //$oprId =4;
   
   $cudate = date('Y-m-d');
		//$cudate = date('2018-05-21');
		echo "<br>";
		//$sql = "select date from attendancemaster where `teacher_id`='1'";
	 	//$result = mysql_query("select date from attendancemaster where `teacher_id`='$oprId' and date = '$cudate'");
	 	$result = mysql_query("SELECT date FROM `attendancemaster` where section_id = ( SELECT section_id FROM `teacherasingmaster` where `teacher_id`= '$oprId') and class_id = ( SELECT class_id FROM `teacherasingmaster` where `teacher_id`= '$oprId') and date = '$cudate'");
		
		//$stmt = sqlsrv_query( $conn, $sql );
		$tid = 0;
		while($row = mysql_fetch_array( $result )) {
	
		 $tid = $tid+1;
		
		}

		if($tid >0)

		{
			echo "<p style='color: Red;text-align: center;min-height: 200px;padding-top: 12%;'>Today Attendance Already Submitted.</p>";
		}
	
		else { 
		
		//$result = mysql_query("SELECT * FROM `student` WHERE `teacher_id`='$oprId'") 
		/*$result = mysql_query("SELECT * FROM `student` where class_id = (SELECT class_id FROM `teacherasingmaster` where teacher_id='$oprId') and section_id= (SELECT section_id FROM `teacherasingmaster` where teacher_id='$oprId')") 
		or die(mysql_error()); 
		
		while($row = mysql_fetch_array( $result )) 
		{	
		
		echo $row['student_Name'];
		}*/
   
   echo'<tbody>';
   $i=1;
	//$result = mysql_query("SELECT * FROM `student` WHERE `teacher_id`='$oprId'") 
	$result = mysql_query("SELECT * FROM `student` where class_id = (SELECT class_id FROM `teacherasingmaster` where teacher_id='$oprId') and section_id= (SELECT section_id FROM `teacherasingmaster` where teacher_id='$oprId')") 
	or die(mysql_error());  
	
									echo '<table class="table table-bordered table-striped"><thead>
                                        <tr>
                                            
                                            <th text-align: center;">
                                                S.No.                                                
                                            </th>
                                            <th>
                                                Roll No.                                               
                                            </th> 
											<th>
                                                Name                                                
                                            </th>
                                            <th>
                                                Father Name                                                
                                            </th>
                                            <th style="width: 10%; text-align: center;">
												Attendance
                                            </th>
                                        </tr></thead>';
echo '<thead>';	
	
	while($row = mysql_fetch_array( $result )) 
	{	
		$i=$i+1;
		//echo $row['emp_Name'];
		//echo $row['father_Name'];
		
				   echo '<tr>
                                            
                                            <td><input type="text" name="part_id[]" value="'.$i.'" readonly ></td>
                                            <td><input type="text" name="student_id[]" value="'.$row['student_id'].'" readonly ></td>
                                            <td><input type="text" name="student_Name[]" value="'.$row['student_Name'].'" readonly ></td>
                                            <td><input type="text" name="father_Name[]" value="'.$row['father_Name'].'" readonly ></td>
                                            <td>
												<select name="price[]" class="form-control">
													<option value="P">P</option>
													<option value="A">A</option>
													
												</select>
											
											<input type="hidden" name="teacher_Name[]" value="'.$row['teacher_Name'].'" readonly >
											<input type="hidden" name="teacher_id[]" value="'.$row['teacher_id'].'" readonly >
											<input type="hidden" name="class_Name[]" value="'.$row['class_Name'].'" readonly >
											<input type="hidden" name="section_Name[]" value="'.$row['section_Name'].'" readonly ></td>
											
                                        </tr>';
				  	
	}
	echo'</tbody> </table>';
	echo '<input type="submit" value="Submit" id="submit">';
	
}

?>