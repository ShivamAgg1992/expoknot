<?php

include('session.php');

include 'header.php';

?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Teacher Assign Master</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Teacher Assign Master
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <form role="form">
                                       
										<div class="col-lg-4">
										 <label>Teacher </label>
                                            <select class="form-control" id="teacher_Name" name="teacher_Name" required >
											    <option value="">Chose Class Teacher </option>
											<?php
													$result = mysql_query("SELECT * FROM teachermaster") 
													or die(mysql_error()); 
													while($row = mysql_fetch_array( $result )) 
													{
														echo '<option value="'.$row['teacher_Name'].'">' . $row['teacher_Name'] . '</option>';
													} 
											?>
                                            
                                                
                                            </select>
                                        </div>
																				
										<div class="col-lg-4">
                                            <label>Class </label>
                                            <select type="text" class="form-control" id="class_Name" name="class_Name" value="" required="" >
											 <option value="">Chose Class Name </option>
                                            <?php
													$result = mysql_query("SELECT * FROM classmaster") 
													or die(mysql_error()); 
													while($row = mysql_fetch_array( $result )) 
													{
														echo '<option value="'.$row['class_Name'].'">' . $row['class_Name'] . '</option>';
													} 
											?>
											
                                            </select>
                                        </div>
										
										
										
										<div class="col-lg-4">
                                            <label>Section</label>
                                            <!--<select class="form-control">-->
											<select type="text" class="form-control" id="section_Name" name="section_Name" value="" required="" >
											 <option value="">Chose Section Name </option>
												<?php
													$result = mysql_query("SELECT * FROM sectionmaster") 
													or die(mysql_error()); 
													while($row = mysql_fetch_array( $result )) 
													{
														echo '<option value="'.$row['section_Name'].'">' . $row['section_Name'] . '</option>';
													} 
												?>
                                            </select>
                                        </div>
										
											
                                        <!--<button type="button" class="btn btn-primary">Submit Button</button>-->
										<button type="button" class="btn btn-success btn-block" name="insert-data" id="insert-data" onclick="insertData()">Insert Data</button>
                                        <p id="message"></p>
                                        
                                    </form>
                                </div>
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>

<script type="text/javascript">
 
  function insertData() {
    var teacher_Name=$("#teacher_Name").val();
    var class_Name=$("#class_Name").val();
    var section_Name=$("#section_Name").val();
	
    //alert(teacher_Name);
    //alert(class_Name);
    //alert(section_Name);
	
	if (teacher_Name =='' || class_Name == '' || section_Name == '')
	{
		alert("please Enter the class_Name");
	}
	else{
	
 
// AJAX code to send data to php file.
        $.ajax({
            type: "POST",
            url: "teacherasingmaster_entry.php",
            data: {teacher_Name:teacher_Name,class_Name:class_Name,section_Name:section_Name},
            dataType: "JSON",
            success: function(data) {
             $("#message").html(data);
            $("p").addClass("alert alert-success");
            },
            error: function(err) {
            alert(err);
            }
        });
		
		
	}
}
 
</script>