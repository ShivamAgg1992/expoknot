<?php

include('connect-db.php');
  
$get_class = $_POST['teacher_Name'];
//$get_class = 7;


//echo "Class Submitted";

//header(location: viewClass.php');
//header("Location: viewTeacher.php");
// echo '<script>window.location.href = "dashboard.php";</script>';
//$result=mysql_query("INSERT INTO `teachermaster`(`teacher_Name`, `phone_No`, `email_Id`, `address_Name`, `photo_Id`, `templateName`) VALUES ('$get_class','$get_class','$get_class','$get_class','$get_class','$get_class')") 
	//or die(mysql_error()); 
	
$result = mysql_query("SELECT * FROM `teachermaster` where `teacher_Name` = '$get_class' ") 
	or die(mysql_error());  
	while($row = mysql_fetch_array( $result )) 
	{
		 $getClass = $row['teacher_Name'];
	}
		
	if ( $get_class == $getClass)
	{
		//echo '<p style="color:red;">Teacher Name Already Exits';
		
	//$result=mysql_query("INSERT INTO `teachermaster`(`teacher_Name`) VALUES ('$get_class')") 
	
  $res="Teacher Name Already Exits";
  echo json_encode($res);
  //header("Location: viewTeacher.php");
}
else {
	
	$result=mysql_query("INSERT INTO `teachermaster`(`teacher_Name`, `phone_No`, `email_Id`, `address_Name`, `photo_Id`, `templateName`) VALUES ('$get_class','$get_class','$get_class','$get_class','$get_class','$get_class')") 
	or die(mysql_error());
	
  $error="Teacher Submitted:";
  echo json_encode($error);
}


?>
