<?php

include('connect-db.php');

   $get_class = mysql_real_escape_string(htmlspecialchars($_GET['q']));
   //$get_class = 2;
   

	$result = mysql_query("SELECT * FROM `sectionmaster` where `section_Name` = '$get_class' ") 
	or die(mysql_error());  
	while($row = mysql_fetch_array( $result )) 
	{
		 $getClass = $row['section_Name'];
	}
		
	if ( $get_class == $getClass)
	{
		echo '<p style="color:red;">Section Already Exits';
		
	}
	else {
		
		echo '<input type="submit" value="Submit" id="submit">'; 
		//echo '<input type="submit" value="Submit" id="submit" onclick="insertData()">'; 
			
		
	}
		
		
?>