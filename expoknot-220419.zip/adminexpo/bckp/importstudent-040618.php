<?php

include('session.php');

include 'header.php';

?>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" crossorigin="anonymous"></script>
	
	
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <!-- /.row -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Import Student
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <!--<form role="form"  id="loginForm" action="section_entry.php" method="post">-->
									<form class="form-horizontal" action="functions.php" method="post" name="upload_excel" enctype="multipart/form-data">
										<fieldset>
										 
																					
											<div class="form-group">
												<label class="col-md-4 control-label" for="filebutton">Select File</label>
												<div class="col-md-4">
												<input type="file" name="file" id="file" class="input-large">
												</div>
											</div>
											
											<div class="form-group">
												<label class="col-md-4 control-label" for="singlebutton">Import data</label>
												<div class="col-md-4">
												<button type="submit" id="submit" name="Import" class="btn btn-primary button-loading" data-loading-text="Loading...">Import</button>
												</div>
											</div>
											
										</fieldset>
										<!-- <p id="txtHint"></p>-->
										
                                    </form>
									<!--<p id="message"></p>-->
                                </div>
								
				<div class="col-lg-12">
                
				</div>
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>
