<?php

include('connect-db.php');
  
$teacher_Name = $_POST['teacher_Name'];
$phone_No = $_POST['phone_No'];
$email_Id = $_POST['email_Id'];
$address_Name = $_POST['address_Name'];
$photo_Id = 9;

//$get_class = 7;

	
$result = mysql_query("SELECT * FROM `teachermaster` where `phone_No` = '$phone_No' ") 
	or die(mysql_error());  
	while($row = mysql_fetch_array( $result )) 
	{
		 $getClass = $row['phone_No'];
		 $getteacher_Name = $row['teacher_Name'];
	}
		
	if ( $phone_No == $getClass )//|| $teacher_Name == $getteacher_Name)
	{
		//echo '<p style="color:red;">Teacher Name Already Exits';
		
	//$result=mysql_query("INSERT INTO `teachermaster`(`teacher_Name`) VALUES ('$teacher_Name')") 
	
  $res="Teacher Name Already Exists";
  echo json_encode($res);
  //header("Location: viewTeacher.php");
}
else {
	
	$result=mysql_query("INSERT INTO `teachermaster`(`teacher_Name`, `phone_No`, `email_Id`, `address_Name`, `photo_Id`, `templateName`) VALUES ('$teacher_Name','$phone_No','$email_Id','$address_Name','$photo_Id','CMD')") 
	or die(mysql_error());
	

	$result=mysql_query("INSERT INTO `loginmaster`(`oprName`, `password`, `templateName`, `status`) VALUES ('$teacher_Name','cmd@1234','CMD','1')") 
	or die(mysql_error());	
	
	echo '<script>window.location.href = "viewTeacher.php";</script>';
	
  $error="Teacher Submitted:";
  echo json_encode($error);
  
 }


?>
