<?php

include('session.php');

 $login_session; 

	$result = mysql_query("SELECT * FROM loginmaster where oprName = '$login_session'")
		or die(mysql_error());  

	while($row = mysql_fetch_array( $result )) 
	{
		 $oprId=$row['oprId'];
		 $templateName=$row['templateName'];
	}

	
													 

include 'header.php';
?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Attendance Master</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Class Master
                        </div>
                        <div class="panel-body">
                            <div class="row">
							
							<form action="admin_attendancesubmit.php" method="post">  
                                <div class="col-lg-12">
                                    
									
										<div class="col-lg-4">
                                            <label>Teacher Name</label>
											
											<select class="form-control" name="teacher_Name" onchange="showCustomer(this.value)">
											<!--<select name="teacher_Name" onchange="showCustomer(this.value)">-->
                                                <option>Chose Class Teacher </option>
											<?php
													$result = mysql_query("SELECT * FROM teachermaster") 
													or die(mysql_error()); 
													while($row = mysql_fetch_array( $result )) {
													echo '<option value="'.$row['id'].'">' . $row['teacher_Name'] . '</option>';
													//echo "hello".$row['teacher_Name'];
													} 
											?>
                                            
                                                
                                            </select>
                                        </div>
										<!--<div class="col-lg-4">
                                            <label>Class</label>
                                            <select class="form-control">
                                                <option>Chose Class </option>
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>
										<div class="col-lg-4">
                                            <label>Section</label>
                                            <select class="form-control">
                                                <option>Chose Section </option>
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>-->
										
                                        <!--<div class="form-group">
                                            <label>Class</label>
                                            <input class="form-control" placeholder="Please Enter the Class">
                                        </div>-->
										
										
                                        
                                       
                                        
                                </div>
								 
								 <li class="divider" style=""></li>
								 
						<div class="col-lg-12">
								<div class="table-responsive">
									
									<div id="txtHint"></div>
								</div>
						</div>
						
						
							
                                        
                    </form>
                                
                            </div>
                            <!-- /.row (nested) -->
							
							
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<script>
function showCustomer(str) {
  var xhttp;    
  if (str == "") {
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("txtHint").innerHTML = xhttp.responseText;
    }
  };
  xhttp.open("GET", "getemp.php?q="+str, true);
  xhttp.send();
}
</script>

<?php include 'footer.php'; ?>