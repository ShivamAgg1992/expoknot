<?php

include('session.php');

include 'header.php';

?>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" crossorigin="anonymous"></script>

        <div id="page-wrapper">
            <div class="row">
               <div class="col-lg-12">
                    <h1 class="page-header">Import Exhibitions</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Exhibitions Details
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form class="form-horizontal" action="functions.php" method="post" name="upload_excel" enctype="multipart/form-data">
										
										<!--<div class="col-lg-6">
                                            <label>Class </label>
                                            <select type="text" class="form-control" id="class_id" name="class_id" onchange="showClass(this.value)" value="" required="" >
											 <option value="">Chose Class Name </option>
                                            <?php
													/* $result = mysql_query("SELECT * FROM classmaster") 
													or die(mysql_error()); 
													while($row = mysql_fetch_array( $result )) 
													{
														echo '<option value="'.$row['id'].'">' . $row['class_Name'] . '</option>';
													}  */
											?>
											
                                            </select>
                                        </div>
										
										<div class="col-lg-6">
                                              											
											<div id="txtHint"></div>											
                                            											
                                        </div>-->
										
										
										<div class="col-lg-12">
										 
																					
											<div class="form-group">
												<label class="col-md-4 control-label" for="filebutton">Select File</label>
												<div class="col-md-4">
												<input type="file" name="file" id="file" class="input-large">
												</div>
											</div>
											
											<div class="form-group">
												<label class="col-md-4 control-label" for="singlebutton">Import data</label>
												<div class="col-md-4">
												<button type="submit" id="submit" name="Import" class="btn btn-primary button-loading" data-loading-text="Loading...">Import</button>
												</div>
											</div>
											
										</div>
										<!-- <p id="txtHint"></p>-->
										
                                    </form>
									
                                </div>
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>