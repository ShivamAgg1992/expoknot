<?php

include('session.php');

include 'header.php';

?>

        <div id="page-wrapper">
            <div class="row">
               <div class="col-lg-12">
                    <h1 class="page-header">Exihibition</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Exihibition
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form action="exibition-insert.php" method="POST" enctype="multipart/form-data" autocomplete="off">
									
                                        <!-- <div class="form-group">
                                            <label>Text Input</label>
                                            <input class="form-control">
                                            <p class="help-block">Example block-level help text here.</p>
                                        </div> -->
                                        <div class="form-group">
                                            <label>Exhibition Name</label>
                                            <input class="form-control" name="exhibition_Name" placeholder="Enter Exhibition Name" required >
                                        </div>
										<div class="form-group">
                                            <label>Exhibition Industry</label>
                                            <input class="form-control" name="exhibition_Industry" placeholder="Enter Exhibition Industry">
                                        </div>
										
										
										
										<div class="form-group">
                                            <label>Date</label>
                                            <input type="date" class="form-control" name="date" rows="3"></textarea>
                                        </div>
										
										<div class="form-group">
                                            <label>Time</label>
                                            <input type="time" class="form-control" name="time" rows="3"></textarea>
                                        </div>
										
										
										
										<div class="form-group">
                                            <label>Location</label>
                                            <input class="form-control" name="locaton" placeholder="Enter Location">
                                        </div>
										
										
										
                                        <div class="form-group">
                                            <label>Exhibition Pics</label>
                                            <input type="file" name="logoToUpload" id="logoToUpload">
                                        </div>
										
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                        <button type="reset" class="btn btn-default">Reset Button</button>
                                    
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                <div class="col-lg-6">
                                    <!-- <h1>Disabled Form States</h1> -->
									<div class="form-group">
                                            <label>Organizer Name</label>
                                            <input class="form-control" name="organizer_Name" placeholder="Enter POC Name">
                                        </div>
										<div class="form-group">
                                            <label>Visitor Profile</label>
                                            <input class="form-control" name="visitor_Profile" placeholder="Enter POC Designation">
                                        </div>
										<div class="form-group">
                                            <label>Exhibitor Profile</label>
                                            <input class="form-control" name="exhibitor_Profile" placeholder="Enter Contact No of POC">
                                        </div>
										
										<div class="form-group">
                                            <label>Venue</label>
                                            <input class="form-control" name="venue" placeholder="Enter Address">
                                        </div>
										
										<div class="form-group">
                                            <label>Description</label>
                                            <textarea class="form-control" name="description" rows="3"></textarea>
                                        </div>
                                    
										
										</form>
                                </div>
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>