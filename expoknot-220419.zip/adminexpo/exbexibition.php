<?php

include('session.php');

$login_session; 

$result = mysql_query("SELECT templateName FROM loginmaster where oprName = '$login_session'")
		or die(mysql_error());  

	while($row = mysql_fetch_array( $result )) 
	{
		//echo $val=$row['templateName'];
		$val=$row['templateName'];
	}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Exhibitor | Expoknot </title>

    <!-- Bootstrap Core CSS -->
    <link href="./vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="./vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="./dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="./vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="./vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

	<!-- <script
      src="https://code.jquery.com/jquery-2.2.4.js" integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI=" crossorigin="anonymous"></script>-->
	
	
	
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Exhibitor Dashboard</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                
				<!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        
                        <li><a href="teacherprofile.php"><i class="fa fa-user fa-fw"></i> Exhibitor Profile</a></li>
                        <!--<li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a></li>-->
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                         <li> 
                            <a href="exhibitordashboard.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                                            				
						<li>
							<a href="http://expoknot.ridhisidhiinfotech.com" target="blank"><i class="fa fa-user fa-fw"></i> View Site</a>
						</li>
						
						<li>
                            <a href="exbexibition.php"><i class="fa fa-edit fa-fw"></i> Add Exhibiton</a>
                        </li>
						
						<li>
                            <a href="exhibitorprofile.php"><i class="fa fa-edit fa-fw"></i> Exhibitor Profile</a>
                        </li>
						
						<li>
                            <a href="changepassword.php"><i class="fa fa-edit fa-fw"></i> Change Password</a>
                        </li>
						
						<li>
                            <a href="logout.php"><i class="fa fa-edit fa-fw"></i> Logout</a>
                        </li>
                      
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
               <div class="col-lg-12">
                    <h1 class="page-header">Exihibition</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Exihibition
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form action="exibition-insert.php" method="POST" enctype="multipart/form-data" autocomplete="off">
									
                                        <!-- <div class="form-group">
                                            <label>Text Input</label>
                                            <input class="form-control">
                                            <p class="help-block">Example block-level help text here.</p>
                                        </div> -->
                                        <div class="form-group">
                                            <label>Exhibition Name</label>
                                            <input class="form-control" name="exhibition_Name" placeholder="Enter Exhibition Name" required >
                                        </div>
										<div class="form-group">
                                            <label>Exhibition Industry</label>
                                            <input class="form-control" name="exhibition_Industry" placeholder="Enter Exhibition Industry">
                                        </div>
										
										
										
										<div class="form-group">
                                            <label>Date</label>
                                            <input type="date" class="form-control" name="date" rows="3"></textarea>
                                        </div>
										
										<div class="form-group">
                                            <label>Time</label>
                                            <input type="time" class="form-control" name="time" rows="3"></textarea>
                                        </div>
										
										
										
										<div class="form-group">
                                            <label>Location</label>
                                            <input class="form-control" name="locaton" placeholder="Enter Location">
                                        </div>
										
										
										
                                        <div class="form-group">
                                            <label>Exhibition Pics</label>
                                            <input type="file" name="logoToUpload" id="logoToUpload">
                                        </div>
										
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                        <button type="reset" class="btn btn-default">Reset Button</button>
                                    
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                <div class="col-lg-6">
                                    <!-- <h1>Disabled Form States</h1> -->
									<div class="form-group">
                                            <label>Organizer Name</label>
                                            <input class="form-control" name="organizer_Name" placeholder="Enter POC Name">
                                        </div>
										<div class="form-group">
                                            <label>Visitor Profile</label>
                                            <input class="form-control" name="visitor_Profile" placeholder="Enter POC Designation">
                                        </div>
										<div class="form-group">
                                            <label>Exhibitor Profile</label>
                                            <input class="form-control" name="exhibitor_Profile" placeholder="Enter Contact No of POC">
                                        </div>
										
										<div class="form-group">
                                            <label>Venue</label>
                                            <input class="form-control" name="venue" placeholder="Enter Address">
                                        </div>
										
										<div class="form-group">
                                            <label>Description</label>
                                            <textarea class="form-control" name="description" rows="3"></textarea>
                                        </div>
                                    
										
										</form>
                                </div>
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>