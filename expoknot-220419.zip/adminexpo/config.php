<?php

$servername = "localhost";
$username = "expoknot";
echo $password = "Rajeev895@";
$db = "expoknot";

   $conn = mysqli_connect($servername, $username, $password, $db);
     echo "Connected successfully"; 
   
    
?>