<?php

include('connect-db.php');
  
$get_class = $_POST['section_Name'];
$get_class_id = $_POST['class_id'];
//$get_class = 7;

$result=mysql_query("INSERT INTO `sectionmaster`(`section_Name`, `class_id`) VALUES ('$get_class','$get_class_id')") 
	or die(mysql_error()); 
//echo "Class Submitted";

//header(location: viewClass.php');
//header("Location: viewSection.php");
header("Location: sectionmaster.php");
// echo '<script>window.location.href = "dashboard.php";</script>';
	
/*if($result > 0)
{
  $res="Class Submitted:";
  echo json_encode($res);
}
else {
  $error="Not Class Submitted,Some Probelm occur.";
  echo json_encode($error);
}*/


?>
