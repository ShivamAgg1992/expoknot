<?php

include('session.php');

include 'header.php';

?>

        <div id="page-wrapper">
            <div class="row">
               <div class="col-lg-12">
                    <h1 class="page-header">Forms</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Exihibition
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form action="about-company-insert.php" method="POST" enctype="multipart/form-data" autocomplete="off">
									
                                        <!-- <div class="form-group">
                                            <label>Text Input</label>
                                            <input class="form-control">
                                            <p class="help-block">Example block-level help text here.</p>
                                        </div> -->
                                        <div class="form-group">
                                            <label>Exhibitors Name</label>
                                            <input class="form-control" name="exhibitors_Name" placeholder="Enter Exhibitors Name" required >
                                        </div>
										<div class="form-group">
                                            <label>Industry</label>
                                            <input class="form-control" name="industry" placeholder="Enter Industry">
                                        </div>
										<div class="form-group">
                                            <label>Stall No</label>
                                            <input class="form-control" name="stall_No" placeholder="Enter text">
                                        </div>
										<div class="form-group">
                                            <label>Email</label>
                                            <input type="email" class="form-control" name="email_Id" placeholder="Enter Email Id" required>
                                        </div>
										
										
										<div class="form-group">
                                            <label>Tag line</label>
											<textarea class="form-control" name="tag_Line" rows="2"></textarea>
                                            <!--<input class="form-control" placeholder="Enter text">-->
                                        </div>
										<div class="form-group">
                                            <label>Description</label>
                                            <textarea class="form-control" name="description" rows="3"></textarea>
                                        </div>
										<div class="form-group">
                                            <label>Address</label>
                                            <input class="form-control" name="address" placeholder="Enter Address">
                                        </div>
										<div class="form-group">
                                            <label>Product Name</label>
                                            <input class="form-control" name="product_Name" placeholder="Enter Product Name">
                                        </div>
										
										
										
                                        
                                        <div class="form-group">
                                            <label>Company Logo</label>
                                            <input type="file" name="logoToUpload" id="logoToUpload">
                                        </div>
										<div class="form-group">
                                            <label>Company Images</label>
                                            <input type="file" name="comToimages" id="comToimages">
                                        </div>
										<div class="form-group">
                                            <label>Brochure</label>
                                            <input type="file" name="broTopdf" id="broTopdf" >
                                        </div>
                                        
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                        <button type="reset" class="btn btn-default">Reset Button</button>
                                    
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                <div class="col-lg-6">
                                    <!-- <h1>Disabled Form States</h1> -->
									<div class="form-group">
                                            <label>POC Name</label>
                                            <input class="form-control" name="poc_Name" placeholder="Enter POC Name">
                                        </div>
										<div class="form-group">
                                            <label>POC Designation</label>
                                            <input class="form-control" name="poc_Description" placeholder="Enter POC Designation">
                                        </div>
										<div class="form-group">
                                            <label>Contact No of POC</label>
                                            <input class="form-control" name="poc_Phone" placeholder="Enter Contact No of POC">
                                        </div>
										
                                    <div class="form-group">
                                            <label>Facebok</label>
                                            <input class="form-control" name="facebook" placeholder="Enter text">
                                        </div>
										<div class="form-group">
                                            <label>Twitter</label>
                                            <input class="form-control" name="twitter" placeholder="Enter text">
                                        </div>
										<div class="form-group">
                                            <label>Linkdin</label>
                                            <input class="form-control" name="linkdin" placeholder="Enter text">
                                        </div>
										<div class="form-group">
                                            <label>Instagram</label>
                                            <input class="form-control" name="instagram" placeholder="Enter text">
                                        </div>
										<div class="form-group">
                                            <label>Youtube</label>
                                            <input class="form-control" name="youtube" placeholder="Enter text">
                                        </div>
										<div class="form-group">
                                            <label>Website</label>
                                            <input class="form-control" name="website" placeholder="Enter text">
                                        </div>
										
										</form>
									
                                </div>
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>