<?php
require_once("connect-db.php");
?>

<?php	
	
	$id_no = $_GET['id'];
	
?>

<!DOCTYPE html>
<html lang="en">
	
<!-- Mirrored from myticket_h1.kenzap.com/full-event-schedule.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 18 Jul 2018 11:16:01 GMT -->
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="">
		<meta name="author" content="">

		<title>Exibition | Expoknot</title>

		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/bootstrap-select.min.css">
		<link rel="stylesheet" href="css/bootstrap-slider.min.css">
		<link rel="stylesheet" href="css/jquery.scrolling-tabs.min.css">
		<link rel="stylesheet" href="css/bootstrap-checkbox.css">
		<link rel="stylesheet" href="css/flexslider.css">
		<link rel="stylesheet" href="css/featherlight.min.css">
		
		<link rel="stylesheet" href="css/bootstrap.offcanvas.min.css">
		<link rel="stylesheet" href="css/core-exibition.css">
	  

		<!-- Custom styles for this template -->
		<link rel="stylesheet" href="css/style.css" >
		<link rel="stylesheet" href="css/responsive.css" >
		<link href="http://fonts.googleapis.com/css?family=Raleway:400,700" rel="stylesheet" type="text/css">
    

		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="http://cdnjs.cloudflare.com/ajax/libs/selectivizr/1.0.2/selectivizr-min.js"></script>
			<script src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
<style>

.topnav {
  overflow: hidden;
  //background-color: #333;
  margin-left: 20%;
}

a:focus, a:hover {
    color: #000;
    text-decoration: underline;
}



.footer-2 > div > ul > li > {
    color: #e48325;
    
}

.topnav2 a {
  float: left;
    display: block;
    //color: #f2f2f2;
	//color: #fff;
    text-align: center;
    padding: 13px 11px;
    text-decoration: none;
    font-size: 17px;
    text-transform: uppercase;
}

.topnav3 a {
  //float: left;
    display: block;
    //color: #f2f2f2;
	//color: #fff;
    //text-align: center;
    padding: 5px 11px;
    text-decoration: none;
   // font-size: 17px;
    //text-transform: uppercase;
}

.topnav3 a:hover, .dropdown:hover .dropbtn {
  //background-color: #e48325;
  //color: white;
  color: #e48325;
}


.active {
  //background-color: #e48325;
  color: #e48325;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    //font-size: 17px;    
    border: none;
    outline: none;
    //color: white;
    padding: 11px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #e48325d4;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav2 a:hover, .dropdown:hover .dropbtn {
  //background-color: #e48325;
  //color: white;
  color: #e48325;
}

.dropdown-content a:hover {
    background-color: #6b625a;
    //background-color: black;
    color: white;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
	background-color: #e4832563;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
	background-color: #e48325b3;
  }
}



.header {
  padding: 10px 16px;
  background: #555;
  color: #f1f1f1;
}

.sticky {
  position: fixed;
  top: 0;
  background-color: #e48325;
  background-image: url("images\header-top.jpg");
  margin-left: -87px;
  //margin-left: -165px;
  //margin-right: -330px;
  width: 100%;
  padding: 10px 0;
}

.sticky + .content {
  padding-top: 102px;
}
</style>
	
	
	<!-- Start WOWSlider.com HEAD section --> <!-- add to the <head> of your page -->
	<link rel="stylesheet" type="text/css" href="engine0/style.css" />
	
	<!-- End WOWSlider.com HEAD section --></head>

	<body>
		
		
	<section class="hero-1" class="site-header" style="min-height: 640px;" >
			<div class="container">
				<div class="row">
				
		<header id="masthead" class="site-header">
			
			<div class="main-header" class="header" id="myHeader">
				<div class="">
					<div class="">
						 

						<!--<div class="col-md-12" style="float: right;">-->
						<div class="" style="float: right;">
						<!--<div class="" style="float: right; margin-right: -145px;">-->
						
						
						
							
							<div class="topnav2 a"  id="myTopnav">
							  <!--<a href="exibition.php" class="">About Event</a>-->
	        					  <a href="#ttabb" class="">About Event</a>

							  <a href="event-exhibitor.php" >Exhibitors</a>
							  <!-- <div class="dropdown">
								<button class="dropbtn">Exhibitors 
								  <i class="fa fa-caret-down"></i>
								</button>
								<div class="dropdown-content">
								  <a href="#">Product Portfolio</a>
								  <a href="#">Option Second</a>
								  
								</div>
							  </div>  -->
							  <a href="gallery.php">Gallery</a>
							  <a href="contact_us.php">Contact Us</a>
							  <a href="organizer.php">Organizer</a>
							  <a href="floor_map.php">Floor Map</a>
							  <a href="#" style="font-size:15px;" class="icon"> <i class="fa fa-user" aria-hidden="true"></i> </a>
							</div>
						
						
						
						</div>
					</div>
				</div>
			</div>
		</header>
				
				<!-- <div class="top-header ">
				<div class="container">
					<div class="row">
						<div class="top-left">
							<ul>
								<li>
									<a href="#">About Event	</a>
								</li>
								<li>
									 <a href="event-exhibitor.html" >Exhibitors</a>
								</li>
								<li>
									  <a href="contact_us.html">Contact Us</a>
								</li>
								<li>
									<a href="#about">Organizer</a>
								</li>
								<li>
									 <a href="#about">Floor Map</a>
								</li>
								
								
							 
							  
							 
							 
							  
							 
								
								
							</ul>
						</div>
						
					</div>
				</div>
			</div> -->
					<div class="hero-content" style="width:75%;">
					
					
					
						<!-- <h1 class="hero-title">Make Your Dream Come True</h1> -->
						
						<p class="hero-caption" style=""><h3 style="color:#fff;line-height: 1.3; font-size:35px">2018 Shanghai International Petrochemical Technology and Equipment Exibition (CIPPE 2018 Shanghai)</h3></p>
						
						
						
						<div class="hero-location">
							<p style="text-transform:uppercase;color: #ffa801;font-size: 25px;font-weight: bold;     margin-bottom: 0.6em; text-align: center;"><i class="fa fa-map-marker" aria-hidden="true"></i> Utter Pradesh</p>
						</div>
						
						<div class="hero-location">
							<p style="margin-bottom: 0.6em; font-size:20px; text-align: center;"> 
							<span style="color: #ffa801; ">23</span> - <span style="color: #ffa801; ">25</span> August 2018</p>
						</div>
						
						
						
						
						
						



<div class="countdown-container">
    <div class="clock row">
        <div class="clock-item clock-days countdown-time-value col-sm-6" style="margin-left:28%; width: 11%;">
            <div class="wrap">
                <div class="inner">
                    <div id="canvas-days" class="clock-canvas"></div>

                    <div class="text">
                        <p class="val" style="color:#e48325">2</p>
                        <p class="type-days type-time">DAYS</p>
                    </div><!-- /.text -->
                </div><!-- /.inner -->
            </div><!-- /.wrap -->
        </div><!-- /.clock-item -->

        <div class="clock-item clock-days countdown-time-value col-sm-6" style="width: 11%;">
            <div class="wrap">
                <div class="inner">
                    <div id="canvas-hours" class="clock-canvas"></div>

                    <div class="text">
                        <p class="val" style="color:#e48325">12</p>
                        <p class="type-hours type-time">HOURS</p>
                    </div><!-- /.text -->
                </div><!-- /.inner -->
            </div><!-- /.wrap -->
        </div><!-- /.clock-item -->

        <div class="clock-item clock-days countdown-time-value col-sm-6" style="width: 11%;">
            <div class="wrap">
                <div class="inner">
                    <div id="canvas-minutes" class="clock-canvas"></div>

                    <div class="text">
                        <p class="val" style="color:#e48325">30</p>
                        <p class="type-minutes type-time">MINUTES</p>
                    </div><!-- /.text -->
                </div><!-- /.inner -->
            </div><!-- /.wrap -->
        </div><!-- /.clock-item -->

        <div class="clock-item clock-seconds countdown-time-value col-sm-6" style="width: 11%;">
            <div class="wrap">
                <div class="inner">
                    <div id="canvas-seconds" class="clock-canvas"></div>

                    <div class="text">
                        <p class="val" style="color:#e48325">24</p>
                        <p class="type-seconds type-time">SECONDS</p>
                    </div><!-- /.text -->
                </div><!-- /.inner -->
            </div><!-- /.wrap -->
        </div><!-- /.clock-item -->
    </div><!-- /.clock -->
</div><!-- /.countdown-wrapper -->




<script type="text/javascript" src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/kinetic.js"></script>
<script type="text/javascript" src="js/jquery.final-countdown.js"></script>
<script type="text/javascript">  
    $('document').ready(function() {
        'use strict';
        
    	$('.countdown').final_countdown({
            'start': 1362139200,
            'end': 1388461320,
            'now': 1387461319        
        });
    });
</script>
						
						<div class="" style="margin-top: 80px;">
						<a href="event-exhibitor.php" style="color: #ffa801; font-size: 21px;text-transform: uppercase; border: solid 2px; padding: 14px 45px 14px 45px; border-radius: 24px;"><!-- <img src="images/register-now.png" > --><span style="color: #fff; ">Register Now</span></a>
						</div>
					</div>
					
				</div>
			</div>
		</section>
		
<?php	
	$result = mysql_query("SELECT * FROM Exhibition_details where id = '$id_no'")
		or die(mysql_error());  

	while($row = mysql_fetch_array( $result )) 
	{
		 //echo $oprId=$row['Exhibition_name'];
		 
	
?>	

	<section class="section-latest" style="background: #f2f2f3;padding: 10px;" id="ttabb">
	</section>
	<section class="section-latest" style="background: #f2f2f3;">
		<div class="container" style="border:solid 1px #d6d6d6; background-color: #fff;padding-top: 20px;padding-bottom: 20px;">
			<div class="row" >
				
				
				
	<div class="col-sm-12 col-md-6" >
						<div class="latest-tweets">
							<div class="section-header">
								<h3 style="text-transform: uppercase;margin-bottom: 20px;font-size: 19px;"><span style="font-weight: bold;"><?php echo $row['Exhibition_name'];?></span></h3>
							</div>
							
							<div class="section-content">
								
								<div class="tweet-list clearfix" >
								
									
									
									<p style="margin: 0 14px 0 0;">
									<?php echo $row['Description']; ?></p>
												
											
								</div>
							</div>
						</div>
						
						<?php
							}
						?>
						
						<div class="latest-tweets" style="margin-top: 20px;">
							<div class="section-header">
								<h3 style="//margin-bottom: 20px;font-size: 19px;"><span style="font-weight: bold;">Highlights</span></h3>
							</div>
							
							<div class="section-content">
								
								<div class="" >
									
									<ul style="list-style: disc;padding-left: 16px;padding-top: 10px; font-family: 'Open Sans', sans-serif;font-weight: 500;">
										<li style="padding-bottom: 6px;">
											Lorem Ipsum is simply dummy text of the printing and typesetting industry..
										</li>
										<li style="padding-bottom: 6px;">
											It is simply dummy text of the printing and typesetting industry.
										</li>
										<li style="padding-bottom: 6px;">
											Lorem Ipsum is simply dummy text of the printing and typesetting industry..
										</li>
										
										
									</ul>
												
											
								</div>
							</div>
						</div>
						
						
		
						
	</div>
					
	<div class="col-sm-12 col-md-6">
		<div class="latest-news" style="margin: 0 0 0 23px;">
							
			<div class="section-content">
			
				<div id="wowslider-container0">
					<div class="ws_images">
						<ul>
							<li><img src="data0/images/gallery15.jpg" alt="gallery-15" title="gallery-15" id="wows0_0"/></li>
							<li><img src="data0/images/gallery14.jpg" alt="gallery-14" title="gallery-14" id="wows0_1"/></li>
							<li><img src="data0/images/gallery13.jpg" alt="gallery-13" title="gallery-13" id="wows0_2"/></li>
							
							<li><img src="data0/images/gallery12.jpg" alt="gallery-12" title="gallery-12" id="wows0_3"/></li>
						</ul>
					</div>
					<div class="ws_bullets">
						<div>
							<a href="#" title="gallery-15"><span><img src="data0/tooltips/gallery15.jpg" alt="gallery-15"/>1</span></a>
							<a href="#" title="gallery-14"><span><img src="data0/tooltips/gallery14.jpg" alt="gallery-14"/>2</span></a>
							<a href="#" title="gallery-13"><span><img src="data0/tooltips/gallery13.jpg" alt="gallery-13"/>3</span></a>
							<a href="#" title="gallery-12"><span><img src="data0/tooltips/gallery12.jpg" alt="gallery-12"/>4</span></a>
						</div>
					</div>	
				</div>	
		
												
									
			</div>
							
							
		</div>
		
		
		
	</div>
					
					
				</div>
		<!--	</div>
		 </section>
		
		
		<section class="section-latest" style="padding: 0px 0 40px 0;"> 
		<div class="container">-->
			<div class="row">
				
				
				
	<div class="col-sm-12 col-md-6" >
						
						
						
						
						
						
		<section class="exibition-section-refine-search">
		<div class="related-artist">
		
		<div class="related-artist-img col-md-12 col-lg-2">
				<a href="#"><img src="images/related-artist-1.jpg" alt="image"></a>
		</div>
		
		<div class="related-artist-info col-md-12 col-lg-8">
			<h4 style="text-transform: uppercase; color: #e48325;font-weight: bold; margin-top: 15px;" >Exhibitor Profile</h4>
										
		</div>
		
							
		</div>
		
		<div style="clear:both;"></div>
			
			<div class="artist-event-item-price" style="margin-top: 20px;">
				<p style="font-size: 12px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
							
			</div>
			
			<div class="latest-tweets" style="margin-top: 20px;">
							<div class="section-header">
								<h3 style="//margin-bottom: 20px;font-size: 19px;"><span style="font-size: 18px; font-weight: bold; color: #e48325;">Steel Industry Stackeholders</span></h3>
							</div>
							
							<div class="section-content">
								
								<div class="" >
									
									<ul style="list-style: disc;padding-left: 16px;padding-top: 10px; font-family: 'Open Sans', sans-serif;font-weight: 500;">
										<li style="padding-bottom: 6px;">
											Lorem Ipsum is simply dummy text of the printing and typesetting industry..
										</li>
										<li style="padding-bottom: 6px;">
											It is simply dummy text of the printing and typesetting industry.
										</li>
										<li style="padding-bottom: 6px;">
											Lorem Ipsum is simply dummy text of the printing and typesetting industry..
										</li>
										
										
									</ul>
												
											
								</div>
							</div>
		</div>
		
		<div class="latest-tweets" style="margin-top: 20px;">
							<div class="section-header">
								<h3 style="//margin-bottom: 20px;font-size: 19px;"><span style="font-size: 18px; font-weight: bold; color: #e48325;">Machinery & Technology for Steel & Metal Manufacturing  </span></h3>
							</div>
							
							<div class="section-content">
								
								<div class="" >
									
									<ul style="list-style: disc;padding-left: 16px;padding-top: 10px; font-family: 'Open Sans', sans-serif;font-weight: 500;">
										<li style="padding-bottom: 6px;">
											Lorem Ipsum is simply dummy text of the printing and typesetting industry..
										</li>
										<li style="padding-bottom: 6px;">
											It is simply dummy text of the printing and typesetting industry.
										</li>
										<li style="padding-bottom: 6px;">
											Lorem Ipsum is simply dummy text of the printing and typesetting industry..
										</li>
										
										
									</ul>
												
											
								</div>
							</div>
		</div>
			
		</section>
						
	</div>
					
	<div class="col-sm-12 col-md-6">
		
		
		<section class="exibition-section-refine-search">
		<div class="related-artist">
		
		<div class="related-artist-img col-md-12 col-lg-2">
				<a href="#"><img src="images/visitor-image.jpg" alt="image"></a>
		</div>
		
		<div class="related-artist-info col-md-12 col-lg-8">
			<h4 style="text-transform: uppercase; color: #e48325;font-weight: bold; margin-top: 15px;" >Visitor Profile</h4>
										
		</div>
		
							
		</div>
		
		<div style="clear:both;"></div>
			
			<div class="latest-tweets" style="margin-top: 20px;">
							<div class="section-header">
								<h3 style="//margin-bottom: 20px;font-size: 19px;"><span style="font-size: 18px; font-weight: bold; color: #e48325;">Sample Headings </span></h3>
							</div>
							
							<div class="section-content">
								
								<div class="" >
									
									<ul style="list-style: disc;padding-left: 16px;padding-top: 10px; font-family: 'Open Sans', sans-serif;font-weight: 500;">
										<li style="padding-bottom: 6px;">
											Lorem Ipsum is simply dummy text
										</li>
										<li style="padding-bottom: 6px;">
											It is simply dummy text.
										</li>
										<li style="padding-bottom: 6px;">
											Lorem Ipsum is simply dummy.
										</li>
										
										<li style="padding-bottom: 6px;">
											Lorem Ipsum is simply dummy.
										</li>
										
										
									</ul>
												
											
								</div>
							</div>
		</div>
		
		
			
		</section>
		
	</div>
					
					
				</div>
			</div>
		</section>
		
		
		
		<section class="section-select-seat-2-featured-header">
			<div class="container">
				<div class="section-content">
					<p> <strong style="text-transform: uppercase;">Related Exibition</strong> </span></p>
				</div>
			</div>
		</section>
		
		<section class="section-upcoming-events">
			<div class="container">
				<div class="row">
					<!-- <div class="section-header">
						<h3 style="text-align: center; text-transform:uppercase;">Upcoming Events</h3>
						
					</div> -->
					<div class="section-content">
						<ul class="clearfix">
							<li style="background-color: #fff;">
								<div>
									<div class="date">
										<a href="#">
											<span class="day">22-26</span>
											<span class="month">JUNE</span>
											<!-- <span class="year">2016</span> -->
										</a>
									</div>
									<a href="#">
										<img src="images/upcoming-event-1.jpg" alt="image"> 
									</a>
									<div class="info" style="margin-top: -70px;" >
																		
											<i class="fa fa-map-marker" style="font-size: 33px;padding: 2px;color: #f60;border-radius: 15px;"></i> <span style="font-size: 19px; color: #fff;">New Delhi, India</span>
									</div>
								</div>
								
								
								
								<div style="clear:both;"></div>
								
								<div class="info" >
										<!-- <h2>BMW Open Championship <span>San Francisco</span></h2> -->
										
											<p >Barcelona Food Truck Festival 2018</p>
								</div>
								<div style="clear:both;"></div>
								<div class="info" >
											<div style="float:left; margin-right:10px;" ><a href="#" class="get-ticket">Book A Stall</a></div>
											<div style="float:left" ><a href="#" class="get-ticket">Register</a></div>
										
										</div>
							</li>
							
							<li style="background-color: #fff;">
								<div>
									<div class="date">
										<a href="#">
											<span class="day">22-26</span>
											<span class="month">JUNE</span>
											<!-- <span class="year">2016</span> -->
										</a>
									</div>
									<a href="#">
										<img src="images/upcoming-event-1.jpg" alt="image">
									</a>
									
									<div class="info" style="margin-top: -70px;" >
																		
											<i class="fa fa-map-marker" style="font-size: 33px;padding: 2px;color: #f60;border-radius: 15px;"></i> <span style="font-size: 19px; color: #fff;">New Delhi, India</span>
									</div>
								</div>
								
								<div style="clear:both;"></div>
								
								<div class="info" >
										<!-- <h2>BMW Open Championship <span>San Francisco</span></h2> -->
										
											<p >Barcelona Food Truck Festival 2018</p>
								</div>
								<div style="clear:both;"></div>
								<div class="info" >
											<div style="float:left; margin-right:10px;" ><a href="#" class="get-ticket">Book A Stall</a></div>
											<div style="float:left" ><a href="#" class="get-ticket">Register</a></div>
										
										</div>
							</li>
							
							<li style="background-color: #fff;">
								<div>
									<div class="date">
										<a href="#">
											<span class="day">22-26</span>
											<span class="month">JUNE</span>
											<!-- <span class="year">2016</span> -->
										</a>
									</div>
									<a href="#">
										<img src="images/upcoming-event-1.jpg" alt="image">
									</a>
									
									<div class="info" style="margin-top: -70px;" >
																		
											<i class="fa fa-map-marker" style="font-size: 33px;padding: 2px;color: #f60;border-radius: 15px;"></i> <span style="font-size: 19px; color: #fff;">New Delhi, India</span>
									</div>
								</div>
								
								<div style="clear:both;"></div>
								
								<div class="info" >
										<!-- <h2>BMW Open Championship <span>San Francisco</span></h2> -->
										
											<p >Barcelona Food Truck Festival 2018</p>
								</div>
								<div style="clear:both;"></div>
								<div class="info" >
											<div style="float:left; margin-right:10px;" ><a href="#" class="get-ticket">Book A Stall</a></div>
											<div style="float:left" ><a href="#" class="get-ticket">Register</a></div>
										
										</div>
							</li>
							
							
							
							
						</ul>
						
						
					</div>
					
										
				</div>
				
			</div>
		</section>
		
		<section class="section-sponsors">
			
				
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14008.711395258098!2d77.39168772165533!3d28.624431353926163!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cefe5d1408383%3A0x102ae5fa48abccf9!2sChhajarsi+Colony%2C+Noida%2C+Uttar+Pradesh+201307!5e0!3m2!1sen!2sin!4v1535621070958" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				
			
		</section>
		

		<footer id="colophon" class="site-footer">
			<div class="top-footer">
				<div class="container">
					<div class="row">
						
						<div class="col-md-4">
							<div style="float:left; width:18%">
							<i class="fa fa-map-marker" style="padding: 21px;font-size: 30px;background-color: #383838;width: 100%;color: #fff;"></i>
							</div>
							<div style="float:left;padding: 24px;background-color: #00000082;width: 80%;">Sec-77, Near Street <br> 
							<span style="color: #e48325;font-size: 16px;">Utter Pradesh, India</span></div>
						</div>
						<div class="col-md-4">
							<div style="float:left; width:18%">
							<i class="fa fa-envelope" style="padding: 21px;font-size: 30px;background-color: #383838;width: 100%;color: #fff;"></i>
							</div>
							<div style="float:left;padding: 24px;background-color: #00000082;width: 80%;">contact@expoknot.com <br> 
							<span style="color: #e48325;font-size: 16px;">info@expoknot.com</span></div>
						</div>
						<div class="col-md-4">
							<div style="float:left; width:18%">
							<i class="fa fa-phone" style="padding: 21px;font-size: 30px;background-color: #383838;width: 100%;color: #fff;"></i>
							</div>
							<div style="float:left;padding: 24px;background-color: #00000082;width: 80%;">011 - 421 - 0000 <br> 
							<span style="color: #e48325;font-size: 16px;">011 - 421 - 1111</span></div>
						</div>
					
					
					</div>
					</div>
					</div>
					</footer>
					
					
		<footer id="colophon" class="site-footer">
			<div class="top-footer" style="border-top: 1px solid #4e4e4e;">
				<div class="container">
				
					<div class="row" style="margin-top:2%; ">
						
						
						
						<div class="topnav3  col-md-4" id="top" style="border-left: none;">
							<div class="footer-dashboard">
								<!-- <p style="font-size: 23px;margin-bottom: 25px;">Useful <span style="font-weight:  bold;">Links </span></b></p> -->
								<ul>
									<li><a href="#" style="font-size: 14px; ">
										<i class="fa fa-arrow-circle-right"></i>  About Us</a>
									</li>
									<li><a href="#" style="font-size: 14px;" >
										<i class="fa fa-arrow-circle-right"></i>  Trade Shows</a>
									</li>
									
									<li><a href="#" style="font-size: 14px; ">
										<i class="fa fa-arrow-circle-right"></i>  Conferences</a>
									</li>
									<li><a href="#" style="font-size: 14px; ">
										<i class="fa fa-arrow-circle-right"></i>  Contact Us</a>
									</li>
									<!-- <li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Birthday Party</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Business Meeting</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Conferance</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Food Event</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Musical Event</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Wedding Party</a>
									</li> -->
								</ul>
							</div>
						</div>
						
						<!--<div class="footer-2 col-md-3" style="border-left: none;">
							<div class="footer-dashboard">
								<p style="font-size: 23px;margin-bottom: 25px;">Useful <span style="font-weight:  bold;">Links </span></b></p>
								<ul>
									 <li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Conferences</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Contact Us</a>
									</li> 
									
									 <li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  About Expoknot</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Disclaimer</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Contact Useful</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Events Schedule</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Sponsors</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Venues</a>
									</li> 
								</ul>
							</div>
						</div>-->
						
						<div class="col-md-4">
						
							<div>
								<p style="font-size: 14px;">
									<span style="font-size:26px;font-weight:  bold;color: #ffffff;"> Network 	</span>
								</p>
								<a href="#"><i class="fa fa-facebook" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-twitter" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-google" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i></a>
							</div>
						
						<!-- <p style="font-size: 23px; text-align:center;">Expoknot  <span style="font-weight:  bold;">Instagram </span></b></p>
						
						<div style="float:left;width: 120px;padding: 5px;"> <a href="#">
							<img src="images/footer-icon.jpg" style="max-height: 100%;"></a>
						</div>
						<div style="float:left;width: 120px;padding: 5px;"> <a href="#">
							<img src="images/footer-icon.jpg" style="max-height: 100%;"></a>
						</div>
						<div style="float:left;width: 120px;padding: 5px;"> <a href="#">
							<img src="images/footer-icon.jpg" style="max-height: 100%;"></a>
						</div>
						<div style="float:left;width: 120px;padding: 5px;"> <a href="#">
							<img src="images/footer-icon.jpg" style="max-height: 100%;"></a>
						</div>
						
						<p style="font-size: 14px; text-align:center;">Follow Our Instagram <span style="font-weight:  bold;color: #e48325;"> #Expoknot </span></b></p> -->
						</div>
						
						<div class="col-md-4">
							<a href="#"><img src="images/logo.png" alt="logo" style="width:100%; max-height: 83px;"></a>
							
							<!-- <div style="margin-top: 177px;">
								<p style="font-size: 14px;">
									<span style="font-size:26px;font-weight:  bold;color: #ffffff;"> Network 	</span>
								</p>
								<i class="fa fa-facebook" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-twitter" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-google" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i>
							</div> -->
						</div>
						
						
					</div>

					
					<!-- <div class="row" style="margin-top:2%; ">
						
						<div class="col-md-3">
							<a href="#"><img src="images/logo.png" alt="logo" style="width:100%; max-height: 61px;"></a>
														
						</div>
						
						<div class="footer-2 col-md-3" style="border-left: none;">
							<div class="footer-dashboard">
								<p style="font-size: 23px;margin-bottom: 25px;">Useful <span style="font-weight:  bold;">Links </span></b></p>
								<ul>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  About Us</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Trade Shows</a>
									</li>								
									
								</ul>
							</div>
						</div>
						
						<div class="footer-2 col-md-3" style="border-left: none;">
							<div class="footer-dashboard">
								<p style="font-size: 23px;margin-bottom: 25px; color: #1f1f1f;">Useful <span style="font-weight:  bold;">Links </span></b></p>
								<ul>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Conferences</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Contact Us</a>
									</li>
																	
								</ul>
							</div>
						</div>
						
						<div class="col-md-3">
						
							<div>
								<p style="font-size: 14px;">
									<span style="font-size:26px;font-weight:  bold;color: #ffffff;"> Network 	</span>
								</p>
								<i class="fa fa-facebook" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-twitter" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-google" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i>
							</div>
						
						
						</div>
						
						
					</div> -->
					
					<!-- <div class="row" style="margin-top:2%; ">
						
						<div class="col-md-3">
							<p style="font-size: 14px;">
								<span style="font-size:26px;font-weight:  bold;color: #ffffff;"> Network 	</span>
							</p>
							<i class="fa fa-facebook" style="font-size: 20px;padding: 5px;"></i>
							<i class="fa fa-twitter" style="font-size: 20px;padding: 5px;"></i>
							<i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i>
							<i class="fa fa-google" style="font-size: 20px;padding: 5px;"></i>
							<i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i>
							
						</div>
						
						<div class="col-md-3">
						
						<p style="font-size: 23px; text-align:center;"></b></p>
						</div>
						
						<div class="col-md-3">
						
						<p style="font-size: 23px; text-align:center;"></b></p>
						</div>
						
						<div class="col-md-3">
						
						<p style="font-size: 14px; text-align:center;">Follow Our Instagram <span style="font-weight:  bold;color: #e48325;"> #Expoknot </span></b></p>
						</div>
						
						
					</div>  -->
					
				</div>
				
				
				
				
			</div>
			
			 <div class="top-footer" style="padding: 1px 0; background: #fff;">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
												
						<p style="margin: 10px 30px 10px 0; font-size: 17px; TEXT-ALIGN: center; color: #ff7d00;  font-weight: bold;">&copy; 2018 EXPOKNOT.COM</p>
						</div>
							
					</div>
					
				</div>
			</div>
		</footer><!-- #colophon -->
		
		
		

		<script src="js/jquery-3.2.0.min.js"></script>
		<script src="js/bootstrap-slider.min.js"></script>
		<script src="js/bootstrap-select.min.js"></script>
		<script src="js/jquery.scrolling-tabs.min.js"></script>
		<script src="js/jquery.countdown.min.js"></script>
		<script src="js/jquery.flexslider-min.js"></script>
		<script src="js/jquery.imagemapster.min.js"></script>
		<script src="js/tooltip.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/featherlight.min.js"></script>
		<script src="js/featherlight.gallery.min.js"></script>
		<script src="js/bootstrap.offcanvas.min.js"></script>
		<script src="js/main.js"></script>
		
		
		<script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
</script>

	</body>
</html>