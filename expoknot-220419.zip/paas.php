<?php

$data = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
  echo  substr(str_shuffle($data), 0, 7);
	
//echo $my_passwords = randomPassword(8,3,"lower_case,upper_case,numbers,special_symbols");

?>