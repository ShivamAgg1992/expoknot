<!DOCTYPE html>
<html lang="en">
	
<!-- Mirrored from myticket_h1.kenzap.com/full-event-schedule.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 18 Jul 2018 11:16:01 GMT -->
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="">
		<meta name="author" content="">

		<title>Organizer | Expoknot</title>

		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/bootstrap-select.min.css">
		<link rel="stylesheet" href="css/bootstrap-slider.min.css">
		<link rel="stylesheet" href="css/jquery.scrolling-tabs.min.css">
		<link rel="stylesheet" href="css/bootstrap-checkbox.css">
		<link rel="stylesheet" href="css/flexslider.css">
		<link rel="stylesheet" href="css/featherlight.min.css">
		
		<link rel="stylesheet" href="css/bootstrap.offcanvas.min.css">
		<link rel="stylesheet" href="css/core.css">
	  

		<!-- Custom styles for this template -->
		<link rel="stylesheet" href="css/style.css" >
		<link rel="stylesheet" href="css/responsive.css" >
		<link href="http://fonts.googleapis.com/css?family=Raleway:400,700" rel="stylesheet" type="text/css">
    

		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="http://cdnjs.cloudflare.com/ajax/libs/selectivizr/1.0.2/selectivizr-min.js"></script>
			<script src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
<style>

.topnav {
  overflow: hidden;
  //background-color: #333;
  margin-left: 20%;
}

.topnav a {
  float: left;
  display: block;
  //color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  //font-size: 17px;
  text-transform: uppercase;
}

.active {
  //background-color: #e48325;
  //color: white;
  color: #e48325;
  border-bottom: solid #e48325;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    //font-size: 17px;    
    border: none;
    outline: none;
    //color: white;
    padding: 11px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #e48325d4;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  //background-color: #e48325;
  //color: white;
  color: #e48325;
}

.dropdown-content a:hover {
    background-color: #6b625a;
    //background-color: black;
    color: white;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
	background-color: #e4832563;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
	background-color: #e48325b3;
  }
}
</style>
	
	
	<!-- Start WOWSlider.com HEAD section --> <!-- add to the <head> of your page -->
	<link rel="stylesheet" type="text/css" href="engine0/style.css" />
	
	<!-- End WOWSlider.com HEAD section --></head>

	<body>
		
		
		<header id="masthead" class="site-header">
			<div class="top-header top-header-bg">
				<div class="container">
					<div class="row">
						<div class="top-left">
							<ul>
								<li>
									<a href="mailto:hello@myticket.com" style="color: #fff;"> 
										<i class="fa fa-envelope-o"></i>
										info@expoknot.com
									</a>
								</li>
								
								<li>
									<a href="#" style="color: #fff;">
										<i class="fa fa-phone"></i>
										+62274 889767
									</a>
								</li>
								
							</ul>
						</div>
						<div class="top-right">
							<ul>
								<li>
									<a href="#">Sign In</a>
								</li>
								<li>
									<a href="#">Sign Up</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="main-header main-header-bg">
				<div class="container">
					<div class="row">
						<div class="site-branding col-md-3">
							<h1 class="site-title">
								<a href="home.php" title="myticket" rel="home"><img src="images/logo.png" alt="logo"></a>
							</h1>
						</div>

						<div class="col-md-9">
						
						
						
							
							<div class="topnav" id="myTopnav">
							  <a href="exibition.php">About Event</a>
							  <a href="event-exhibitor.php" >Exhibitors</a>
							  <!-- <div class="dropdown">
								<button class="dropbtn">Exhibitors 
								  <i class="fa fa-caret-down"></i>
								</button>
								<div class="dropdown-content">
								  <a href="#">Product Portfolio</a>
								  <a href="#">Option Second</a>
								  
								</div>
							  </div>  -->
							  <a href="gallery.php">Gallery</a>
							  <a href="contact_us.php">Contact Us</a>
							  <a href="organizer.php" class="active">Organizer</a>
							  <a href="floor_map.php">Floor Map</a>
							  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
							</div>
						
						
						<script>
							function myFunction() {
								var x = document.getElementById("myTopnav");
								if (x.className === "topnav") {
									x.className += " responsive";
								} else {
									x.className = "topnav";
								}
							}
						</script>
						</div>
					</div>
				</div>
			</div>
		</header><!-- #masthead -->	
	
		<!-- <section class="section-page-header">
			<div class="container">
				<h1 class="entry-title"></h1>
			</div>
		</section> -->
		
		<section class="section-select-seat-2-featured-header">
			<div class="container">
				<div class="section-content">
					<div style="float:left;">
						
						<img src="images/exibition-logo.jpg" style="width: 100%; float: right;">
					</div>
					<p style="text-align: center;"> <strong style="text-transform: uppercase; font-size:35px">Organizer <span style="text-transform: uppercase;"> Company  Name</strong> </span></p>
				</div>
			</div>
		</section>
		
		<!-- <section class="section-select-seat-2-featured-header">
			<div class="container">
				<div class="section-content">
					<p> <strong>Exhibitor <span > Name</strong> </span></p>
					<div style="float:right;">
						
						<img src="images/exibition-logo.jpg" style="width: 100%; float: right;margin-top: -125px;">
					</div>
				</div>
				
				
			</div>
		</section> -->
		
		
		<!-- <section class="section-refine-search">
			<div class="container">
				<div class="row">
					<form class="row">
						<div class="keyword col-sm-6 col-md-4">
							<label>Search Keyword</label>
							<input type="text" class="form-control hasclear" placeholder="Search">
							<span class="clearer"><img src="images/clear.png" alt="clear"></span>
						</div>
						<div class="month col-sm-6 col-md-3">
							<label>Month</label>
							<select class="selectpicker dropdown">
								<option>Select Month</option>
								<option>January</option>
								<option>February</option>
								<option>March</option>
								<option>April</option>
								<option>May</option>
								<option>June</option>
								<option>July</option>
								<option>August</option>
								<option>September</option>
								<option>October</option>
								<option>November</option>
								<option>December</option>
							</select>
						</div>
						<div class="year col-sm-6 col-md-3">
							<label>Year</label>
							<select class="selectpicker dropdown">
								<option>Select Year</option>
								<option value="2017">2016</option>
								<option value="2017">2017</option>
								<option value="2018">2018</option>
								<option value="2019">2019</option>
								<option value="2020">2020</option>
								<option value="2021">2021</option>
								<option value="2022">2022</option>
								<option value="2023">2023</option>
								<option value="2024">2024</option>
								<option value="2025">2025</option>
								<option value="2026">2026</option>
							</select>
						</div>
						<div class="col-sm-6 col-md-2">
							<input type="submit" value="Search">
						</div>
					</form>
				</div>
			</div>
		</section> -->
	
	<section class="section-latest" >
		<div class="container" style="padding-top: 20px;padding-bottom: 20px;">
			<div class="row" >
				
				
				
	<div class="col-sm-12 col-md-6" >
						<div class="latest-tweets">
							<div class="section-header">
								<h3 style="text-transform: uppercase;margin-bottom: 20px;font-size: 19px;">Barcelona <span style="font-weight: bold;">Food Truck Festival 2018</span></h3>
							</div>
							
							<div class="section-content">
								
								<div class="tweet-list clearfix" >
								
									
									
									<p style="margin: 0 14px 0 0;">
									Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.</p>
									
									<p style="margin: 0 14px 0 0;">
									Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries. Lorem Ipsum is  simply dummy text of the printing and typesetting simply dummy text of the printing and typesetting simply dummy text of the printing and typesetting
									industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.</p>
												
											
								</div>
							</div>
						</div>
						
						
						<div class="latest-tweets" style="margin-top: 20px;">
							<div class="section-header">
								<h3 style="//margin-bottom: 20px;font-size: 19px;"><span style="font-weight: bold;">Highlights</span></h3>
							</div>
							
							<div class="section-content">
								
								<div class="" >
									
									<ul style="list-style: disc;padding-left: 16px;padding-top: 10px; font-family: 'Open Sans', sans-serif;font-weight: 500;">
										<li style="padding-bottom: 6px;">
											Lorem Ipsum is simply dummy text of the printing and typesetting industry..
										</li>
										<li style="padding-bottom: 6px;">
											It is simply dummy text of the printing and typesetting industry.
										</li>
										<li style="padding-bottom: 6px;">
											Lorem Ipsum is simply dummy text of the printing and typesetting industry..
										</li>
										
										
									</ul>
												
											
								</div>
							</div>
						</div>
						
						
		
						
	</div>
					
	<div class="col-sm-12 col-md-6">
		<div class="latest-news" style="margin: 0 0 0 23px;">
							
			<div class="section-content">
			
				<div id="wowslider-container0">
					<div class="ws_images">
						<ul>
							<li><img src="data0/images/gallery15.jpg" alt="gallery-15" title="gallery-15" id="wows0_0"/></li>
							<li><img src="data0/images/gallery14.jpg" alt="gallery-14" title="gallery-14" id="wows0_1"/></li>
							<li><img src="data0/images/gallery13.jpg" alt="gallery-13" title="gallery-13" id="wows0_2"/></li>
							
							<li><img src="data0/images/gallery12.jpg" alt="gallery-12" title="gallery-12" id="wows0_3"/></li>
						</ul>
					</div>
					<div class="ws_bullets">
						<div>
							<a href="#" title="gallery-15"><span><img src="data0/tooltips/gallery15.jpg" alt="gallery-15"/>1</span></a>
							<a href="#" title="gallery-14"><span><img src="data0/tooltips/gallery14.jpg" alt="gallery-14"/>2</span></a>
							<a href="#" title="gallery-13"><span><img src="data0/tooltips/gallery13.jpg" alt="gallery-13"/>3</span></a>
							<a href="#" title="gallery-12"><span><img src="data0/tooltips/gallery12.jpg" alt="gallery-12"/>4</span></a>
						</div>
					</div>	
				</div>	
		
												
									
			</div>
							
							
		</div>
		
		
		
	</div>
					
					
				</div>
		<!--	</div>
		 </section>
		
		
		<section class="section-latest" style="padding: 0px 0 40px 0;"> 
		<div class="container">-->
			
			</div>
		</section>
		
		<section class="section-latest" style="background-color: #fff7e9;">
			<div class="container">
				<div class="row">
				<!-- <div class="section-header">
					<h3 style="text-transform: uppercase;margin-bottom: 20px;font-size: 19px;">Contact Us </h3>
				</div> -->
				
				<div style="clear:both;"></div>
				
				
					
					<div class="col-sm-12 col-md-6" style="padding-right: 50px;">
						<div class="latest-news">
							<!-- <div class="section-header" >
								<h3 style="text-transform: uppercase;margin-bottom: 20px;">Latest <b> News</b></h3>
							</div> -->
							<div class="section-header">
								<h3 style="text-transform: uppercase;margin-bottom: 20px;font-size: 19px;">Keep In <span style="font-weight: bold;">Touch</span></h3>
							</div>
							
							<section class="section-refine-search">
			
								<form action="organizer_insert.php" method="POST">

								<!-- <label>Search Keyword</label> -->
								<input type="text" name="your_name" class="form-control hasclear" placeholder="Your Name" required  />
								<input type="email" name="email_address" class="form-control hasclear" placeholder="Email Address"  style="border: 2px solid #dedede; padding: 0 25px; height: 55px; line-height: 39px; height: auto; width: 100%; color: #b3b3b3; margin-bottom: 13px; background-color: #e8e8e84d;" required />
								<input type="text" name="your_address" class="form-control hasclear" placeholder="Your Address" required />
								<input type="text" name="phone_no" class="form-control hasclear" placeholder="Phone Number" required />
								
								<textarea name="message" rows="4" cols="50" class="form-control hasclear" placeholder="Your Message"></textarea>
								
								<div class="artist-event-item-price">
								<!--<a href="#" class="get-ticket" style="">
									<img src="images/send-mail.png" style="width: 43%;margin-left: 30%;margin-right: 10%;margin-top: 34px;">
								</a>-->
								
								<input type="submit" value="Send Mail" align="middle">
							</div>
							
						
								</form>
				
							</section>
						</div>
					</div>
					
					
					
					<div class="col-sm-12 col-md-6" style="border-left: solid 1px; padding-left: 55px;">
					
					<div class="latest-tweets" style="margin-top: 50px;">
							<div class="section-header">
								<h3 style="margin-bottom: 20px;font-size: 19px;">
									<span style="color: #f6921f;">Organizer Main Office 1</span>
									
								</h3>
							</div>
							
							<div class="section-content">
								
								<div class="" >
									
									<p style="font-size:17px;">Company, Plot No-7-10,<br>
									India, Raipur Khadar,<br> 
									Sector 126, Noida,<br>
									Uttar Pradesh 201301<br>
									organizer@company.com<br>
									Cell: +999 99 99999
									</p>
												
											
								</div>
							</div>
						</div>
						<hr>
						<div class="latest-tweets" style="margin-top: 50px;">
							<div class="section-header">
								<h3 style="margin-bottom: 20px;font-size: 19px;">
									<span style="color: #f6921f;">Organizer Office 2</span>
									
								</h3>
							</div>
							
							<div class="section-content">
								
								<div class="" >
									
									<p style="font-size:17px;">Company, Plot No-7-10,<br>
									Sector 126, Noida,<br>
									Raipur Khadar,<br> 
									(UP) 201301, India<br>
									organizer@company.com<br>
									Cell: +999 99 99999
									</p>
												
											
								</div>
							</div>
						</div>
					
					</div>
					
					
					
					
				</div>
			</div>
		</section>
		
		
		
		<section class="section-select-seat-2-featured-header">
			<div class="container">
				<div class="section-content">
					<p> <strong style="text-transform: uppercase; text-align:center;">More Exibitions By the Organizer</strong> </span></p>
				</div>
			</div>
		</section>
		
		<section class="section-upcoming-events">
			<div class="container">
				<div class="row">
					<!-- <div class="section-header">
						<h3 style="text-align: center; text-transform:uppercase;">Upcoming Events</h3>
						
					</div> -->
					<div class="section-content">
						<ul class="clearfix">
							<li style="background-color: #fff;">
								<div>
									<div class="date">
										<a href="#">
											<span class="day">22-26</span>
											<span class="month">JUNE</span>
											<!-- <span class="year">2016</span> -->
										</a>
									</div>
									<a href="#">
										<img src="images/upcoming-event-1.jpg" alt="image"> 
									</a>
									<div class="info" style="margin-top: -70px;" >
																		
											<i class="fa fa-map-marker" style="font-size: 33px;padding: 2px;color: #f60;border-radius: 15px;"></i> <span style="font-size: 19px; color: #fff;">New Delhi, India</span>
									</div>
								</div>
								
								
								
								<div style="clear:both;"></div>
								
								<div class="info" >
										<!-- <h2>BMW Open Championship <span>San Francisco</span></h2> -->
										
											<p >Barcelona Food Truck Festival 2018</p>
								</div>
								<div style="clear:both;"></div>
								<div class="info" >
											<div style="float:left; margin-right:10px;" ><a href="#" class="get-ticket">Book A Stall</a></div>
											<div style="float:left" ><a href="#" class="get-ticket">Register</a></div>
										
										</div>
							</li>
							
							<li style="background-color: #fff;">
								<div>
									<div class="date">
										<a href="#">
											<span class="day">22-26</span>
											<span class="month">JUNE</span>
											<!-- <span class="year">2016</span> -->
										</a>
									</div>
									<a href="#">
										<img src="images/upcoming-event-1.jpg" alt="image">
									</a>
									
									<div class="info" style="margin-top: -70px;" >
																		
											<i class="fa fa-map-marker" style="font-size: 33px;padding: 2px;color: #f60;border-radius: 15px;"></i> <span style="font-size: 19px; color: #fff;">New Delhi, India</span>
									</div>
								</div>
								
								<div style="clear:both;"></div>
								
								<div class="info" >
										<!-- <h2>BMW Open Championship <span>San Francisco</span></h2> -->
										
											<p >Barcelona Food Truck Festival 2018</p>
								</div>
								<div style="clear:both;"></div>
								<div class="info" >
											<div style="float:left; margin-right:10px;" ><a href="#" class="get-ticket">Book A Stall</a></div>
											<div style="float:left" ><a href="#" class="get-ticket">Register</a></div>
										
										</div>
							</li>
							
							<li style="background-color: #fff;">
								<div>
									<div class="date">
										<a href="#">
											<span class="day">22-26</span>
											<span class="month">JUNE</span>
											<!-- <span class="year">2016</span> -->
										</a>
									</div>
									<a href="#">
										<img src="images/upcoming-event-1.jpg" alt="image">
									</a>
									
									<div class="info" style="margin-top: -70px;" >
																		
											<i class="fa fa-map-marker" style="font-size: 33px;padding: 2px;color: #f60;border-radius: 15px;"></i> <span style="font-size: 19px; color: #fff;">New Delhi, India</span>
									</div>
								</div>
								
								<div style="clear:both;"></div>
								
								<div class="info" >
										<!-- <h2>BMW Open Championship <span>San Francisco</span></h2> -->
										
											<p >Barcelona Food Truck Festival 2018</p>
								</div>
								<div style="clear:both;"></div>
								<div class="info" >
											<div style="float:left; margin-right:10px;" ><a href="#" class="get-ticket">Book A Stall</a></div>
											<div style="float:left" ><a href="#" class="get-ticket">Register</a></div>
										
										</div>
							</li>
							
							
							
							
						</ul>
						
						
					</div>
					
										
				</div>
				
			</div>
		</section>
		
				

		<footer id="colophon" class="site-footer">
			<div class="top-footer">
				<div class="container">
					<div class="row">
						
						<div class="col-md-4">
							<div style="float:left; width:18%">
							<i class="fa fa-map-marker" style="padding: 21px;font-size: 30px;background-color: #383838;width: 100%;color: #fff;"></i>
							</div>
							<div style="float:left;padding: 24px;background-color: #00000082;width: 80%;">Sec-77, Near Street <br> 
							<span style="color: #e48325;font-size: 16px;">Utter Pradesh, India</span></div>
						</div>
						<div class="col-md-4">
							<div style="float:left; width:18%">
							<i class="fa fa-envelope" style="padding: 21px;font-size: 30px;background-color: #383838;width: 100%;color: #fff;"></i>
							</div>
							<div style="float:left;padding: 24px;background-color: #00000082;width: 80%;">contact@expoknot.com <br> 
							<span style="color: #e48325;font-size: 16px;">info@expoknot.com</span></div>
						</div>
						<div class="col-md-4">
							<div style="float:left; width:18%">
							<i class="fa fa-phone" style="padding: 21px;font-size: 30px;background-color: #383838;width: 100%;color: #fff;"></i>
							</div>
							<div style="float:left;padding: 24px;background-color: #00000082;width: 80%;">011 - 421 - 0000 <br> 
							<span style="color: #e48325;font-size: 16px;">011 - 421 - 1111</span></div>
						</div>
					
					
					</div>
					</div>
					</div>
					</footer>
					
					
		<footer id="colophon" class="site-footer">
			<div class="top-footer" style="border-top: 1px solid #4e4e4e;">
				<div class="container">
				
					<div class="row" style="margin-top:2%; ">
						
						
						
						<div class="footer-2 col-md-4" style="border-left: none;">
							<div class="footer-dashboard">
								<!-- <p style="font-size: 23px;margin-bottom: 25px;">Useful <span style="font-weight:  bold;">Links </span></b></p> -->
								<ul>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  About Us</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Trade Shows</a>
									</li>
									
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Conferences</a>
									</li>
									<li><a href="contact_us.html" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Contact Us</a>
									</li>
									
								</ul>
							</div>
						</div>
						
						
						
						<div class="col-md-4">
						
							<div>
								<p style="font-size: 14px;">
									<span style="font-size:26px;font-weight:  bold;color: #ffffff;"> Network 	</span>
								</p>
								<a href="#"><i class="fa fa-facebook" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-twitter" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-google" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i></a>
							</div>
						
						
						</div>
						
						<div class="col-md-4">
							<a href="#"><img src="images/logo.png" alt="logo" style="width:100%; max-height: 83px;"></a>
							
							
						</div>
						
						
					</div>

					
					
					
				</div>
				
				
				
				
			</div>
			
			 <div class="top-footer" style="padding: 1px 0; background: #fff;">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
												
						<p style="margin: 10px 30px 10px 0; font-size: 17px; TEXT-ALIGN: center; color: #ff7d00;  font-weight: bold;">&copy; 2018 EXPOKNOT.COM</p>
						</div>
							
					</div>
					
				</div>
			</div>
		</footer><!-- #colophon -->
		
		
		

		<script src="js/jquery-3.2.0.min.js"></script>
		<script src="js/bootstrap-slider.min.js"></script>
		<script src="js/bootstrap-select.min.js"></script>
		<script src="js/jquery.scrolling-tabs.min.js"></script>
		<script src="js/jquery.countdown.min.js"></script>
		<script src="js/jquery.flexslider-min.js"></script>
		<script src="js/jquery.imagemapster.min.js"></script>
		<script src="js/tooltip.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/featherlight.min.js"></script>
		<script src="js/featherlight.gallery.min.js"></script>
		<script src="js/bootstrap.offcanvas.min.js"></script>
		<script src="js/main.js"></script>

	</body>
</html>