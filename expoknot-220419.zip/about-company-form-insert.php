<?php
require_once("connect-db.php");

echo $your_name = $_POST['your_name'];
echo $email_address = $_POST['email_address'];
echo $your_address = $_POST['your_address'];
echo $phone_no = $_POST['phone_no'];
echo $message = $_POST['message'];



$send_to = "info@expoknot.com";
$send_subject = "About Company | ExpoKnot";

/*Be careful when editing below this line */

$f_name = cleanupentries($_POST["your_name"]);
$f_email = cleanupentries($_POST["email_address"]);
$f_your_address = cleanupentries($_POST['your_address']);
$f_phone_no = cleanupentries($_POST['phone_no']);
$f_message = cleanupentries($_POST["message"]);
$from_ip = $_SERVER['REMOTE_ADDR'];
$from_browser = $_SERVER['HTTP_USER_AGENT'];

function cleanupentries($entry) {
	$entry = trim($entry);
	$entry = stripslashes($entry);
	$entry = htmlspecialchars($entry);

	return $entry;
}

$message = "This email was submitted on " . date('m-d-Y') . 
"\n\nName: " . $f_name . 
"\n\nE-Mail: " . $f_email . 
"\n\nE-Mail: " . $f_your_address . 
"\n\nE-Mail: " . $f_phone_no . 
"\n\nMessage: \n" . $f_message . 
"\n\n\nTechnical Details:\n" . $from_ip . "\n" . $from_browser;

$send_subject .= " - {$f_name}";

$headers = "From: " . $f_email . "\r\n" .
    "Reply-To: " . $f_email . "\r\n" .
    "X-Mailer: PHP/" . phpversion();

if (!$f_email) {
	echo "no email";
	exit;
}else if (!$f_name){
	echo "no name";
	exit;
}else{
	if (filter_var($f_email, FILTER_VALIDATE_EMAIL)) {
		mail($send_to, $send_subject, $message, $headers);
		echo "true";
	}else{
		echo "invalid email";
		exit;
	}
}



/*

date_default_timezone_set("Asia/Kolkata");
echo $curDate = date("Y-m-d h:i:sa");

$sql = "INSERT INTO `contectus_details`(`yourName`, `emailAddress`, `yourAddress`, `phoneNo`, `message`, `curDate`) VALUES ('$your_name','$email_address','$your_address','$phone_no','$message', '$curDate')" ;

*/

//$sql = "INSERT INTO `Exhibition_details`(`Exhibition_name`, `Exhibition_Industry`, `Description`,  `Organizer_Name`, `Visitor_Profile`, `Exhibitor_Profile`, `Exhibition_Pics`, `Location`, `Venue`, `Date`, `Time`) VALUES ('$exhibitors_Name','$industry','$description','$stall_No','$email_Id','$tag_Line','$address','$product_Name','$logoToUpload','$comToimages','$broTopdf','$poc_Name','$poc_Description','$poc_Phone','$facebook','$twitter','$linkdin','$instagram','$youtube','$website')" ;

/*
mysql_query($sql)
 or die(mysql_error()); 
 */
 
  echo '<script>window.location.href = "enquirythanks.php";</script>';

/* $result = mysql_query("SELECT * FROM Exhibition_details")
		or die(mysql_error());  

	while($row = mysql_fetch_array( $result )) 
	{
		 echo $oprId=$row['Exhibition_name'];
		 
	} */
?>