

<!DOCTYPE html>
<html lang="en">
	
<!-- Mirrored from myticket_h1.kenzap.com/full-event-schedule.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 18 Jul 2018 11:16:01 GMT -->
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="">
		<meta name="author" content="">

		<title>Thanks | Expoknot</title>

		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/bootstrap-select.min.css">
		<link rel="stylesheet" href="css/bootstrap-slider.min.css">
		<link rel="stylesheet" href="css/jquery.scrolling-tabs.min.css">
		<link rel="stylesheet" href="css/bootstrap-checkbox.css">
		<link rel="stylesheet" href="css/flexslider.css">
		
		<!-- <link rel="stylesheet" href="css/font-awesome.min.css"> -->
		<link rel="stylesheet" href="css/bootstrap.offcanvas.min.css">
		<link rel="stylesheet" href="css/core.css">
	  

		<!-- Custom styles for this template -->
		<link rel="stylesheet" href="css/style.css" >
		<link rel="stylesheet" href="css/responsive.css" >

		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="http://cdnjs.cloudflare.com/ajax/libs/selectivizr/1.0.2/selectivizr-min.js"></script>
			<script src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
		
		
		
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
<style>

.topnav {
  overflow: hidden;
  //background-color: #333;
  margin-left: 20%;
}

.topnav a {
  float: left;
  display: block;
  //color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  //font-size: 17px;
  text-transform: uppercase;
}

.active {
  //background-color: #e48325;
  color: white;
  color: #e48325;
  border-bottom: solid #e48325;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    //font-size: 17px;    
    border: none;
    outline: none;
    //color: white;
    padding: 11px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #e48325d4;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  //background-color: #e48325;
  //color: white;
  color: #e48325;
}

.dropdown-content a:hover {
    background-color: #6b625a;
    //background-color: black;
    color: white;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
	background-color: #e4832563;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
	background-color: #e48325b3;
  }
}
</style>
	</head>

	<body>

		<header id="masthead" class="site-header">
			<div class="top-header top-header-bg">
				<div class="container">
					<div class="row">
						<div class="top-left">
							<ul>
								<li>
									<a href="mailto:hello@myticket.com" style="color: #fff;"> 
										<i class="fa fa-envelope-o"></i>
										info@expoknot.com
									</a>
								</li>
								
								<li>
									<a href="#" style="color: #fff;">
										<i class="fa fa-phone"></i>
										+62274 889767
									</a>
								</li>
								
							</ul>
						</div>
						<div class="top-right">
							<ul>
								<li>
									<a href="#">Sign In</a>
								</li>
								<li>
									<a href="#">Sign Up</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="main-header main-header-bg">
				<div class="container">
					<div class="row">
						 <div class="site-branding col-md-3">
							<h1 class="site-title">
								<a href="home.php" title="myticket" rel="home"><img src="images/logo.png" alt="logo"></a>
							</h1>
						</div>

						<div class="col-md-9">
						
						
						
							
							<div class="topnav" id="myTopnav">
							  <a href="exibition.php" class="active">About Event</a>
							  <a href="event-exhibitor.php" >Exhibitors</a>
							  <!-- <div class="dropdown">
								<button class="dropbtn">Exhibitors 
								  <i class="fa fa-caret-down"></i>
								</button>
								<div class="dropdown-content">
								  <a href="#">Product Portfolio</a>
								  <a href="#">Option Second</a>
								  
								</div>
							  </div>  -->
							  <a href="gallery.php">Gallery</a>
							  <a href="contact_us.php">Contact Us</a>
							  <a href="organizer.php">Organizer</a>
							  <a href="floor_map.php">Floor Map</a>
							  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
							</div>
						
						
						<script>
							function myFunction() {
								var x = document.getElementById("myTopnav");
								if (x.className === "topnav") {
									x.className += " responsive";
								} else {
									x.className = "topnav";
								}
							}
						</script>
						</div>
					</div>
				</div>
			</div>
		</header><!-- #masthead -->	
	
		<!-- <section class="section-page-header">
			<div class="container">
				<h1 class="entry-title"></h1>
			</div>
		</section> -->
		
		<section class="section-select-seat-2-featured-header" style="min-height: 50px;">
			<div class="container">
				<div class="section-content" style="padding: 25px 0;">
				
					<p style="text-align: center;"> <strong style="text-transform: uppercase;"> Sign <span > Up</strong> </span></p>
				</div>
				<!-- <div class="section-content">
				<span style="text-transform: uppercase;font-size: 25px;color: #fff;" > contact us now </span>
					<p> <strong style="text-transform: uppercase;">Keep <span > in tuch</strong> </span></p>
				</div> -->
			</div>
		</section>
		
		
		
	
		<section class="section-latest" style="">
			<div class="container">
				<div class="row">
				<!-- <div class="section-header">
					<h3 style="text-transform: uppercase;margin-bottom: 20px;font-size: 19px;">Contact Us </h3>
				</div> -->
				
				<div style="clear:both;"></div>
				
				
<div class="col-sm-12 col-md-3" >
</div>
					<div class="col-sm-12 col-md-6" style="padding-right: 50px;min-height:100px;">
						<div class="latest-news">
	

							<div style="background-color:#fff; font-size:13px; color:#03b311; text-align: center;">
								<h4 style="font-size:17px; color:#03b311;">Verification mail has been sent to your email id</h4>
							</div>
						</div>
							
					</div>
	<div class="col-sm-12 col-md-3" >
</div>
					</div>
					
					
					
					
					
					
					
					
				</div>
			</div>
		</section>
		
		

		<footer id="colophon" class="site-footer">
			<div class="top-footer">
				<div class="container">
					<div class="row">
						
						<div class="col-md-4">
							<div style="float:left; width:18%">
							<i class="fa fa-map-marker" style="padding: 21px;font-size: 30px;background-color: #383838;width: 100%;color: #fff;"></i>
							</div>
							<div style="float:left;padding: 24px;background-color: #00000082;width: 80%;">Sec-77, Near Street <br> 
							<span style="color: #e48325;font-size: 16px;">Utter Pradesh, India</span></div>
						</div>
						<div class="col-md-4">
							<div style="float:left; width:18%">
							<i class="fa fa-envelope" style="padding: 21px;font-size: 30px;background-color: #383838;width: 100%;color: #fff;"></i>
							</div>
							<div style="float:left;padding: 24px;background-color: #00000082;width: 80%;">contact@expoknot.com <br> 
							<span style="color: #e48325;font-size: 16px;">info@expoknot.com</span></div>
						</div>
						<div class="col-md-4">
							<div style="float:left; width:18%">
							<i class="fa fa-phone" style="padding: 21px;font-size: 30px;background-color: #383838;width: 100%;color: #fff;"></i>
							</div>
							<div style="float:left;padding: 24px;background-color: #00000082;width: 80%;">011 - 421 - 0000 <br> 
							<span style="color: #e48325;font-size: 16px;">011 - 421 - 1111</span></div>
						</div>
					
					
					</div>
					</div>
					</div>
					</footer>
					
					
		<footer id="colophon" class="site-footer">
			<div class="top-footer" style="border-top: 1px solid #4e4e4e;">
				<div class="container">
				
					<div class="row" style="margin-top:2%; ">
						
						
						
						<div class="footer-2 col-md-4" style="border-left: none;">
							<div class="footer-dashboard">
								<!-- <p style="font-size: 23px;margin-bottom: 25px;">Useful <span style="font-weight:  bold;">Links </span></b></p> -->
								<ul>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  About Us</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Trade Shows</a>
									</li>
									
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Conferences</a>
									</li>
									<li><a href="contact_us.html" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Contact Us</a>
									</li>
									
								</ul>
							</div>
						</div>
						
						
						
						<div class="col-md-4">
						
							<div>
								<p style="font-size: 14px;">
									<span style="font-size:26px;font-weight:  bold;color: #ffffff;"> Network 	</span>
								</p>
								<a href="#"><i class="fa fa-facebook" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-twitter" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-google" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i></a>
							</div>
						
						
						</div>
						
						<div class="col-md-4">
							<a href="#"><img src="images/logo.png" alt="logo" style="width:100%; max-height: 83px;"></a>
							
							
						</div>
						
						
					</div>

					
					
					
				</div>
				
				
				
				
			</div>
			
			 <div class="top-footer" style="padding: 1px 0; background: #fff;">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
												
						<p style="margin: 10px 30px 10px 0; font-size: 17px; TEXT-ALIGN: center; color: #ff7d00;  font-weight: bold;">&copy; 2018 EXPOKNOT.COM</p>
						</div>
							
					</div>
					
				</div>
			</div>
		</footer><!-- #colophon -->
		
		
		

		<script type="text/javascript" src="js/contact.js"></script>
		<script src="js/jquery-3.2.0.min.js"></script>
		<script src="js/bootstrap-slider.min.js"></script>
		<script src="js/bootstrap-select.min.js"></script>
		<script src="js/jquery.scrolling-tabs.min.js"></script>
		<script src="js/jquery.countdown.min.js"></script>
		<script src="js/jquery.flexslider-min.js"></script>
		<script src="js/jquery.imagemapster.min.js"></script>
		<script src="js/tooltip.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/featherlight.min.js"></script>
		<script src="js/featherlight.gallery.min.js"></script>
		<script src="js/bootstrap.offcanvas.min.js"></script>
		<script src="js/main.js"></script>

	</body>
</html>