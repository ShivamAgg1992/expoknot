<!DOCTYPE html>
<html>
<title>Form</title>
<body>
<form action="process.php" method="post">
   Name:<input class="input" type="text" placeholder="name" name="name" required><br><br>
   Email:<input class="input" type="email" placeholder="email" name="email" required><br><br>
   Phone:<input class="input" type="text" placeholder="phone" name="phone" required><br><br>
    <button  type="submit" name="btn-save">Submit</button>
</form>
</body>
</html>