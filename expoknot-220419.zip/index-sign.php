<!DOCTYPE html>
<html lang="en">
	
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="">
		<meta name="author" content="">

		<title>ExpoKnot</title>

		<!-- Latest compiled and minified CSS -->		
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/bootstrap-select.min.css">
		<link rel="stylesheet" href="css/bootstrap-slider.min.css">
		<link rel="stylesheet" href="css/jquery.scrolling-tabs.min.css">
		<link rel="stylesheet" href="css/bootstrap-checkbox.css">
		<link rel="stylesheet" href="css/flexslider.css">
		<link rel="stylesheet" href="css/featherlight.min.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/bootstrap.offcanvas.min.css">
		<link rel="stylesheet" href="css/core.css">
	  

		<!-- Custom styles for this template -->
		<link rel="stylesheet" href="css/style.css" >
		<link rel="stylesheet" href="css/responsive.css" >

		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="http://cdnjs.cloudflare.com/ajax/libs/selectivizr/1.0.2/selectivizr-min.js"></script>
			<script src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>

	<body>
		<header id="masthead" class="site-header fix-header header-1">
			<div class="top-header top-header-bg" style="background: #e4832500;">
				<div class="container">
					<div class="row">
						<!-- <div class="top-left">
							<ul>
								<li>
									<a href="#">
										<i class="fa fa-phone"></i>
										+62274 889767
									</a>
								</li>
								<li>
									<a href="mailto:hello@myticket.com"> 
										<i class="fa fa-envelope-o"></i>
										hello@myticket.com
									</a>
								</li>
							</ul>
						</div> -->
						<div class="top-right">
							<ul>
								<li>
									<a href="signin.php"><i class="fa fa-sign-in xs-hidden sm-hidden"></i> Sign In</a>
								</li>
								<li>
									<a href="#">Sign Up</a>
								</li>
							</ul>
						</div> 
					</div>
				</div>
			</div>
			<!-- <div class="main-header">
				<div class="container">
					<div class="row">
						<div class="site-branding col-md-3">
							<h1 class="site-title"><a href="homepage-1.html" title="myticket" rel="home"><img src="images/logo.png" alt="logo"></a></h1>
						</div>

						<div class="col-md-9">
							<nav id="site-navigation" class="navbar">
								<div class="navbar-header">
									<div class="mobile-cart" ><a href="#">0</a></div>
									<button type="button" class="navbar-toggle offcanvas-toggle pull-right" data-toggle="offcanvas" data-target="#js-bootstrap-offcanvas">
										<span class="sr-only">Toggle navigation</span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
								</div>
								<div class="navbar-offcanvas navbar-offcanvas-touch navbar-offcanvas-right" id="js-bootstrap-offcanvas">
									<button type="button" class="offcanvas-toggle closecanvas" data-toggle="offcanvas" data-target="#js-bootstrap-offcanvas">
									   <i class="fa fa-times fa-2x" aria-hidden="true"></i>
									</button>
									<ul class="nav navbar-nav navbar-right">
										<li class="active"><a href="full-event-schedule.html">Schedule</a></li>
										<li><a href="artist-page.html">Concerts</a></li>
										<li><a href="upcoming-events.html">Sports</a></li>
										<li><a href="order-ticket-without-seat.html">Parties</a></li>
										<li><a href="event-by-category.html">Theater</a></li>
										<li><a href="gallery.html">Gallery</a></li>
										<li><a href="select-seat-2.html">Ticekts</a></li>
										<li class="cart"><a href="#">0</a></li>
									</ul>
								</div>
							</nav>
						</div>
					</div>
				</div>
			</div> -->
		</header>
		
		<!-- <section class="hero-1">
			<div class="container">
				<div class="row">
					<div class="hero-content">
						<h1 class="hero-title">Make Your Dream Come True</h1>
						<p class="hero-caption">Meet your favorite artists, sport teams and parties</p>
						<div class="hero-search">
							<input type="text" placeholder="Seach Artist, Team, or Venue">
						</div>
						<div class="hero-location">
							<p><i class="fa fa-map-marker" aria-hidden="true"></i> San Francisco <a href="#">Change Location</a></p>
						</div>
					</div>
				</div>
			</div>
		</section> -->
		<section class="hero-1">
			<div class="container">
				<div class="row">
					<div class="hero-content">
						<!-- <h1 class="hero-title">Make Your Dream Come True</h1> -->
						<img src="images/logo.png">
						<p class="hero-caption"><h2 style="color:#fff;text-transform: uppercase;font-size: 28px;">Find your favorite trade shows & conferences</h2></p>
						<div class="hero-search">
							<input type="text" placeholder="Seach Artist, Team, or Venue" style="color:#000;">
							
							<button type="submit" style="background: #e48325;font-size: 16px; color: #fff; border: none; padding: 10px;   border-top-right-radius: 12px; border-bottom-right-radius: 12px;">Submit</button>
						</div>
						<!--<div class="hero-location">
							<p><i class="fa fa-map-marker" aria-hidden="true"></i> San Francisco <a href="#">Change Location</a></p>
						</div>-->
					</div>
				</div>
			</div>
		</section>
		
		<!--<section class="section-artist-content">
			<div class="container">
				<div class="row">
					<div id="primary" class="col-sm-12 col-md-6">
					<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					

					<div class="artist-event-item" style="padding: 0px 7px 0px 112px;background: #fff0;">
							<div class="row">
								
								<div class="artist-event-item-price">
									<a href="event-exhibitor.php" class="get-ticket" style="border-radius: 46px;width: 50%; background: linear-gradient(135deg,  rgba(217,30,24,.9) 0%,rgba(255,102,0,.9) 100%);">About ExpoKnot</a>
								</div>
							</div>
					</div>
					
					
					</div>
					
					<div id="primary" class="col-sm-12 col-md-6">
					<video width="100%" controls>
						<source src="https://www.w3schools.com/html/mov_bbb.mp4" type="video/mp4">
						<source src="https://www.w3schools.com/html/mov_bbb.ogg" type="video/ogg">
					
					</video>
					
											
					</div>
					
				</div>
			</div>
		</section>-->
				
		<section class="section-upcoming-events">
			<div class="container">
				<div class="row">
					<div class="section-header">
						<h3 style="text-align: center; text-transform:uppercase;">Upcoming Events</h3>
						
					</div>
					
					<?php

        if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
        } else {
            $pageno = 1;
        }
        $no_of_records_per_page = 4;
        $offset = ($pageno-1) * $no_of_records_per_page;

        $conn=mysqli_connect("localhost","expoknot","Rajeev895@","expoknot");
        // Check connection
        if (mysqli_connect_errno()){
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
            die();
        }

        $total_pages_sql = "SELECT COUNT(*) FROM Exhibition_details";
        $result = mysqli_query($conn,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);

        $sql = "SELECT * FROM Exhibition_details LIMIT $offset, $no_of_records_per_page";
        $res_data = mysqli_query($conn,$sql);
        
    ?>
					
					<div class="section-content">
						<ul class="clearfix">
						
						<?php 
						
						while($row = mysqli_fetch_array($res_data)){
							//here goes the data
							//echo $row['Exhibition_name'];
							//echo '</br>';
						
						?>
						
						
							<li style="background-color: #fff;">
								<div>
									<div class="date">
										<a href="exibition.php">
											<span class="day">22-26</span>
											<span class="month">JUNE</span>
											<!-- <span class="year">2016</span> -->
										</a>
									</div>
									<a href="exibition.php?id=<?php echo $row['id'];?>">
										<!---<img src="images/upcoming-event-1.jpg" alt="image"> -->
										<img src="images/<?php echo $row['Exhibition_Pics'];?>" alt="image"> 
									</a>
									<div class="info" style="margin-top: -70px;" >
																		
											<i class="fa fa-map-marker" style="font-size: 33px;padding: 2px;color: #f60;border-radius: 15px;"></i> <span style="font-size: 19px; color: #fff;">New Delhi, India</span>
									</div>
								</div>
								
								
								
								<div style="clear:both;"></div>
								
								<div class="info" >
										<!-- <h2>BMW Open Championship <span>San Francisco</span></h2> -->
										
											<!--<p >Barcelona Food Truck Festival 2018</p>-->
											<p ><?php echo $row['Exhibition_name'];?></p>
								</div>
								<div style="clear:both;"></div>
								<div class="info" >
											<div style="float:left; margin-right:10px;" ><a href="#" class="get-ticket">Book A Stall</a></div>
											<div style="float:left" ><a href="#" class="get-ticket">Register</a></div>
										
										</div>
							</li>
							
						<?php
							}
						mysqli_close($conn);
						
						?>
							
							
							
						</ul>
						
						
					</div>
					
										
				</div>
				
			</div>
		</section>
		
		<section class="section-artist-content" style="padding-top: 1px;">
			<div class="container">
				<div class="row">
					<div id="primary" class="col-sm-12 col-md-12">
						<div class="artist-event-footer">
							<!-- <ul class="pagination">
								<li>
									<a href="#" aria-label="Previous">
										<span aria-hidden="true"><i class="fa fa-long-arrow-left" aria-hidden="true"></i> Prev</span>
									</a>
								</li>
								<li class="active"><a href="#">1</a></li>
								<li><a href="#">2</a></li>
								<li><a href="#">3</a></li>
								<li><a href="#">4</a></li>
								<li><a href="#">5</a></li>
								<li>
									<a href="#" aria-label="Next">
										<span aria-hidden="true">Next <i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
									</a>
								</li>
							</ul> -->
							
							
							<ul class="pagination">
        <li><a href="?pageno=1">First</a></li>
        <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
            <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>">Prev</a>
        </li>
		
		<li>
			<?php
			
				for ($i=1; $i<=$total_pages; $i++) {  // print links for all pages
					echo "<a href='?pageno=".$i."'";
					if ($i==$pageno)  echo " class='curPage'";
					echo ">".$i."</a> "; 
				}; 
			?>
		</li>
		
        <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
            <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>" aria-label="Next">Next</a>
        </li>
        <li><a href="?pageno=<?php echo $total_pages; ?>">Last</a></li>
    </ul>
						</div>
					</div>
				</div>
			</div>
		</section>
		
		<!--<section class="section-event-category">
			<div class="container">
				<div class="row">
					<div class="section-header">
						<h2>Event by Categories</h2>
					</div>
					<div class="section-content">
						<ul class="row clearfix">
							<li class="category-1 col-sm-4">
								<img src="images/event-category-1.jpg" alt="image">
								<a href="#"><span>Concerts</span></a>
							</li>
							<li class="category-2 col-sm-4">
								<img src="images/event-category-2.jpg" alt="image">
								<a href="#"><span>Sports</span></a>
							</li>
							<li class="category-3 col-sm-4">
								<img src="images/event-category-3.jpg" alt="image">
								<a href="#"><span>Threaters</span></a>
							</li>
							<li class="category-4 col-sm-4">
								<img src="images/event-category-4.jpg" alt="image">
								<a href="#"><span>Parties</span></a>
							</li>
							<li class="category-5 col-sm-4">
								<img src="images/event-category-5.jpg" alt="image">
								<a href="#"><span>Communities</span></a>
							</li>
							<li class="category-6 col-sm-4">
								<img src="images/event-category-6.jpg" alt="image">
								<a href="#"><span>Classes</span></a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</section>-->
		
		<section class="section-video-parallax">
			<div class="container">
				<div class="section-content">
					
					<p style="text-align: center;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
					<p style="text-transform:uppercase; color:#ff8d00fa; text-align: center;">Lorem Ipsum </p>
					<p style="text-align: center;">Art Dealer</p>
					<!-- <a href="#"><img src="images/play-btn.png" alt="image"></a> -->
				</div>
			</div>
		</section>
		
		
		
		
		
		
		<section class="section-latest">
			<div class="container">
				<div class="row">
				<div class="section-header" style="padding-bottom:30px;">
						<h3 style="text-align: center; text-transform:uppercase;">Our Blog</h3>
						
				</div>
				
				<div class="col-sm-12 col-md-6" >
						<div class="latest-tweets">
							<div class="section-header">
								<h3 style="text-transform: uppercase;margin-bottom: 20px;">Twitter Feed <img src="images/twitter-follow.jpg" style="float:right; margin-right:20px;" alt="image"></h3>
								
								
							</div>
							<div class="section-content">
								<!-- <div class="twitter-header clearfix">
									<div class="twitter-name">
										<a href="#">
											<img src="images/twitter-avatar.png" alt="image">
											<strong>myticket.com</strong>
											<span>@myticket</span>
										</a>
									</div>
									<div class="twitter-btn">
										<a href="#">Follow</a>
									</div>
								</div> -->
								<div class="tweet-list clearfix">
									<ul class="clearfix">
										<li class="row tweet-item">
											<div class="col-sm-2">
												<img src="images/twitter-logo.png" alt="image">
											</div>
											<div class="col-sm-10">
												<p><b style="font-size: 15px; font-weight:  bold;">Twitter API </b><img src="images/twitter-feed.jpg" alt="image"> @twitterexpoknot 12 Aug</p>
												<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.</p>
												<img src="images/twitter-comment.jpg" alt="image">
											</div>
											
										</li>
										
										<li class="row tweet-item">
											<div class="col-sm-2">
												<img src="images/twitter-logo.png" alt="image">
											</div>
											<div class="col-sm-10">
												<p><b style="font-size: 15px; font-weight:  bold;">Twitter API </b><img src="images/twitter-feed.jpg" alt="image"> @twitterexpoknot 12 Aug</p>
												<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.</p>
												<img src="images/twitter-comment.jpg" alt="image">
											</div>
											
										</li>
										
										<li class="row tweet-item">
											<div class="col-sm-2">
												<img src="images/twitter-logo.png" alt="image">
											</div>
											<div class="col-sm-10">
												<p><b style="font-size: 15px; font-weight:  bold;">Twitter API </b><img src="images/twitter-feed.jpg" alt="image"> @twitterexpoknot 12 Aug</p>
												<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.</p>
												<img src="images/twitter-comment.jpg" alt="image">
											</div>
											
										</li>
										
									</ul>
								</div>
							</div>
						</div>
					</div>
					
					<div class="col-sm-12 col-md-6">
						<div class="latest-news">
							<div class="section-header" >
								<h3 style="text-transform: uppercase;margin-bottom: 20px;">Latest <b> News</b></h3>
							</div>
							<div class="section-content">
								<ul class="clearfix">
									<li class="row news-item">
										<div class="col-sm-5 news-item-img">
											<!-- <div class="date">
												<a href="#">
													<span class="day">25</span>
													<span class="month">August</span>
													<span class="year">2016</span>
												</a>
											</div> -->
											<a href="#"><img src="images/latest-news-1.jpg" alt="image" style="height: 200px;"></a>
										</div>
										<div class="col-sm-7 news-item-info">
											<h3><a href="#">Attending the Indonesian Envato Authors National Meetup</a></h3>
											<span class="meta-data">12 August 2018</a></span>
											<p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesenlup.</p>
										</div>
									</li>
									
									<li class="row news-item">
										<div class="col-sm-5 news-item-img">
											<!-- <div class="date">
												<a href="#">
													<span class="day">25</span>
													<span class="month">August</span>
													<span class="year">2016</span>
												</a>
											</div> -->
											<a href="#"><img src="images/latest-news-1.jpg" alt="image" style="height: 200px;"></a>
										</div>
										<div class="col-sm-7 news-item-info">
											<h3><a href="#">Attending the Indonesian Envato Authors National Meetup</a></h3>
											<span class="meta-data">12 August 2018</a></span>
											<p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesenlup.</p>
										</div>
									</li>
									
									
									
								</ul>
								
							</div>
						</div>
					</div>
					
					
				</div>
			</div>
		</section>
		
		
		<section class="section-sponsors">
			
				
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14008.711395258098!2d77.39168772165533!3d28.624431353926163!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cefe5d1408383%3A0x102ae5fa48abccf9!2sChhajarsi+Colony%2C+Noida%2C+Uttar+Pradesh+201307!5e0!3m2!1sen!2sin!4v1535621070958" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				
			
		</section>

		<footer id="colophon" class="site-footer">
			<div class="top-footer">
				<div class="container">
					<div class="row">
						
						<div class="col-md-4">
							<div style="float:left; width:18%">
							<i class="fa fa-map-marker" style="padding: 21px;font-size: 30px;background-color: #383838;width: 100%;color: #fff;"></i>
							</div>
							<div style="float:left;padding: 24px;background-color: #00000082;width: 80%;">Sec-77, Near Street <br> 
							<span style="color: #e48325;font-size: 16px;">Utter Pradesh, India</span></div>
						</div>
						<div class="col-md-4">
							<div style="float:left; width:18%">
							<i class="fa fa-envelope" style="padding: 21px;font-size: 30px;background-color: #383838;width: 100%;color: #fff;"></i>
							</div>
							<div style="float:left;padding: 24px;background-color: #00000082;width: 80%;">contact@expoknot.com <br> 
							<span style="color: #e48325;font-size: 16px;">info@expoknot.com</span></div>
						</div>
						<div class="col-md-4">
							<div style="float:left; width:18%">
							<i class="fa fa-phone" style="padding: 21px;font-size: 30px;background-color: #383838;width: 100%;color: #fff;"></i>
							</div>
							<div style="float:left;padding: 24px;background-color: #00000082;width: 80%;">011 - 421 - 0000 <br> 
							<span style="color: #e48325;font-size: 16px;">011 - 421 - 1111</span></div>
						</div>
					
					
					</div>
					</div>
					</div>
					</footer>
					
					
		<footer id="colophon" class="site-footer">
			<div class="top-footer" style="border-top: 1px solid #4e4e4e;">
				<div class="container">
				
					<div class="row" style="margin-top:2%; ">
						
						
						
						<div class="footer-2 col-md-4" style="border-left: none;">
							<div class="footer-dashboard">
								<!-- <p style="font-size: 23px;margin-bottom: 25px;">Useful <span style="font-weight:  bold;">Links </span></b></p> -->
								<ul>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  About Us</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Trade Shows</a>
									</li>
									
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Conferences</a>
									</li>
									<li><a href="contact_us.html" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Contact Us</a>
									</li>
									
								</ul>
							</div>
						</div>
						
						
						
						<div class="col-md-4">
						
							<div>
								<p style="font-size: 14px;">
									<span style="font-size:26px;font-weight:  bold;color: #ffffff;"> Network 	</span>
								</p>
								<a href="#"><i class="fa fa-facebook" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-twitter" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-google" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i></a>
							</div>
						
						
						</div>
						
						<div class="col-md-4">
							<a href="#"><img src="images/logo.png" alt="logo" style="width:100%; max-height: 83px;"></a>
							
							
						</div>
						
						
					</div>

					
					
					
				</div>
				
				
				
				
			</div>
			
			 <div class="top-footer" style="padding: 1px 0; background: #fff;">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
												
						<p style="margin: 10px 30px 10px 0; font-size: 17px; TEXT-ALIGN: center; color: #ff7d00;  font-weight: bold;">&copy; 2018 EXPOKNOT.COM</p>
						</div>
							
					</div>
					
				</div>
			</div>
		</footer><!-- #colophon -->
		
		<script src="js/jquery-3.2.0.min.js"></script>
		<script src="js/bootstrap-slider.min.js"></script>
		<script src="js/bootstrap-select.min.js"></script>
		<script src="js/jquery.scrolling-tabs.min.js"></script>
		<script src="js/jquery.countdown.min.js"></script>
		<script src="js/jquery.flexslider-min.js"></script>
		<script src="js/jquery.imagemapster.min.js"></script>
		<script src="js/tooltip.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/featherlight.min.js"></script>
		<script src="js/featherlight.gallery.min.js"></script>
		<script src="js/bootstrap.offcanvas.min.js"></script>
		<script src="js/main.js"></script>
	
	</body>

<!-- Mirrored from myticket_h1.kenzap.com/homepage-1.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 18 Jul 2018 11:14:25 GMT -->
</html>