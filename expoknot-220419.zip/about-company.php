<?php
//include('session.php');
session_start();
/*$login_session; 

$result = mysql_query("SELECT templateName FROM loginmaster where oprName = '$login_session'")
		or die(mysql_error());  

	while($row = mysql_fetch_array( $result )) 
	{
		//echo $val=$row['templateName'];
		 $val=$row['templateName'];
	}*/
?>

<?php
require_once("connect-db.php");
?>

<?php	
	
	$Stall_no = $_GET['Stall_no'];
	
?>

<!DOCTYPE html>
<html lang="en">
	
<!-- Mirrored from myticket_h1.kenzap.com/full-event-schedule.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 18 Jul 2018 11:16:01 GMT -->
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="">
		<meta name="author" content="">

		<title>Exhibitor Profile | Expoknot</title>

		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/bootstrap-select.min.css">
		<link rel="stylesheet" href="css/bootstrap-slider.min.css">
		<link rel="stylesheet" href="css/jquery.scrolling-tabs.min.css">
		<link rel="stylesheet" href="css/bootstrap-checkbox.css">
		<link rel="stylesheet" href="css/flexslider.css">
		<link rel="stylesheet" href="css/featherlight.min.css">
		
		<link rel="stylesheet" href="css/bootstrap.offcanvas.min.css">
		<link rel="stylesheet" href="css/core.css">
	  

		<!-- Custom styles for this template -->
		<link rel="stylesheet" href="css/style.css" >
		<link rel="stylesheet" href="css/responsive.css" >

		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="http://cdnjs.cloudflare.com/ajax/libs/selectivizr/1.0.2/selectivizr-min.js"></script>
			<script src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
<style>

.topnav {
  overflow: hidden;
  //background-color: #333;
  margin-left: 20%;
}

.topnav a {
  float: left;
  display: block;
  //color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  //font-size: 17px;
  text-transform: uppercase;
}

.active {
  //background-color: #e48325;
  color: #e48325;
}

#active {
  //background-color: #e48325;
  //color: white;
 // color: #e48325;;
      border-bottom: solid #e48325;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    //font-size: 17px;    
    border: none;
    outline: none;
    //color: white;
    padding: 11px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #e48325d4;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: white;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  //background-color: #e48325;
  //color: white;
  color: #e48325;
}

.dropdown-content a:hover {
    background-color: #6b625a;
    //background-color: black;
    color: white;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
	background-color: #e4832563;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
	background-color: #e48325b3;
  }
}
</style>

<style>


/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0, 0, 0, 0.75); /* Black w/ opacity */
  
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  //width: 80%;
      width: 49%;
    height: 350px;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}


.dropdown-menu {
    position: absolute;
    /* top: 100%; */
    left: 81%;
    z-index: 1000;
    display: none;
    float: left;
    min-width: 160px;
    padding: 5px 0;
    margin: 2px 0 0;
    /* font-size: 14px; */
    text-align: left;
    list-style: none;
    background-color: #e48325;
    -webkit-background-clip: padding-box;
    background-clip: padding-box;
    /* border: 1px solid #ccc; */
    border: 1px solid rgba(0,0,0,.15);
    border-radius: 6px;
    -webkit-box-shadow: 0 6px 12px rgba(0,0,0,.175);
    box-shadow: 0 6px 12px rgba(0,0,0,.175);
}


</style>


	
	
	<!-- Start WOWSlider.com HEAD section --> <!-- add to the <head> of your page -->
	<link rel="stylesheet" type="text/css" href="engine0/style.css" />
	<script type="text/javascript" src="engine0/jquery.js"></script>
	<!-- End WOWSlider.com HEAD section --></head>

	<body>

		<!--<header id="masthead" class="site-header">-->
		<header id="masthead" class="site-header fix-header header-1">
			<div class="top-header top-header-bg">
				<div class="container">
					<div class="row">
						<div class="top-left">
							<ul>
								<li>
									<a href="mailto:hello@myticket.com" style="color: #fff;"> 
										<i class="fa fa-envelope-o"></i>
										info@expoknot.com
									</a>
								</li>
								
								<li>
									<a href="#" style="color: #fff;">
										<i class="fa fa-phone"></i>
										+62274 889767
									</a>
								</li>
								
							</ul>
						</div>
						<div class="top-right">
							<ul>
								
								<li class="dropdown">
                    
                    <!-- /.dropdown-user -->
                
								
								<!--<a href="#" id="myBtn"><i class="fa fa-sign-in xs-hidden sm-hidden"></i> Sign In / Sign Up</a>-->
								
								<?php
										if(isset( $_SESSION['login_user'] ))
										
										{
											include('session.php');
											?>
											
											<a class="dropdown-toggle" data-toggle="dropdown" href="#">
												<i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
											</a>
											<ul class="dropdown-menu dropdown-user">
												<li style="color:#fff;"><a href="#"><i class="fa fa-user fa-fw"></i>Welcome User</a></li>
												<li class="divider"></li>
												<li><a href="#"><i class="fa fa-user fa-fw"></i> Update Profile</a></li>
												<!--<li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a></li>-->
												<li class="divider"></li>
												<li>
													<a href="changepassword.php"><i class="fa fa-sign-out fa-fw"></i> Change Password</a>
												</li>
												<li class="divider"></li>
												<li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a></li>
											</ul>
										
										<?php
										} 
										else
										{
											?>
											
											<a href="#" id="myBtn"><i class="fa fa-sign-in xs-hidden sm-hidden"></i> Sign In / Sign Up</a>
											
										<?php
										}

									?>
									
										
																		
									<!--<button id="myBtn">Sign In</button>-->
								</li>
								<!--<li>
									<a href="#">Sign Up</a>
								</li>-->
							</ul>
						</div>
					</div>
				</div>
			</div>
			
			<div id="myModal" class="modal">

				  <!-- Modal content -->
						<div class="modal-content">
							<span class="close">&times;</span>
							<h3 class="modal-title" style="text-align: center;" id="myModalLabel">Login / Sign up</h3><br>
							<!--<form name="ajax-form" id="ajax-form" action="#" method="post">-->
					
							<div class="text-center p-t-46 p-b-20">
									<div style="float:left; margin-right:5px; width:32%"><a href="javascript:void(0)" onclick="$('#TenTimes-Modal').modal('hide');socialAll('fb','signup','signup');" class="btn btn-lg btn-default fb-login-btn" style="margin-top:10px!important"><i class="fa fa-fw fa-facebook" style="color:#3b5998;"></i>Facebook</a></div>
									
									<div style="float:left; margin-right:5px;width:32%"><a href="javascript:void(0)" onclick="$('#TenTimes-Modal').modal('hide');socialAll('gplus','signup','signup');" class="btn btn-lg btn-default gplus-login-btn" style="margin-top:10px!important;"><i class="fa fa-fw fa-google-plus" style="color:#E24825;"></i>Google </a></div>
									
									<div style="float:left;width:32%"><a href="javascript:void(0)" onclick="$('#TenTimes-Modal').modal('hide');socialAll('linkedin','signup','signup');" class="btn btn-lg btn-default in-login-btn" style="margin-top:10px!important"><i class="fa fa-fw fa-linkedin" style="color:#0077b5;"></i>Linkedin</a></div>
							</div>
						
							<div class="text-center p-t-46 p-b-20" style="margin-top: 77px;">
								<form class="login100-form validate-form" action="process.php" method="POST">
									<!--<input type="email" name="email_address" id="email" placeholder="Email Address" required />-->
									
									<!--<button id="btnAdd" class="login100-form-btn">Next</button>-->
														
									<!--<button type="button" class="btn btn-lg btn-orange btn-block x-na" style="background: #f85d17;">Next</button>-->
									<!--<input type="submit" id="btnAdd" class="login100-form-btn" style="background: #f85d17;width: 100%;height: 35px;color: #fff;" value="Next" align="middle">-->
									
									<p class="w3-center"><button class="w3-btn w3-green w3-round" style="width:100%;height:40px; background-color: #f85d17;width: 100%;height: 35px;color: #fff;" name="btn-save">Next</button></p>
									
									<div class="text-center p-t-46 p-b-20">
										<!---<br><span class="txt2">-- or quick & easy login using -- </span>-->
									</div>
									
									<input type="email" id="email" name="email" class="form-control hasclear" placeholder="Enter email to proceed"  style="border: 2px solid #dedede; padding: 0 25px; height: 55px; line-height: 39px; height: auto; width: 100%; margin-bottom: 13px; background-color: #e8e8e84d; margin-top:21px;" required />
									
									<!--<label class="w3-label w3-text-black"><b>Email</b></label>
							<p><input class="w3-input w3-border w3-round" type="email" placeholder="email" name="email" required></p>-->
								
								</form>
					
							</div>

						</div>
			</div>
			
			</header><!-- #masthead -->	
			<section class="section-page-header" style="background: none;">
			<div class="main-header" style="z-index: -999;">
				<div class="container">
					<div class="row">
						<div class="site-branding col-md-3">
							<h1 class="site-title">
								<a href="home.php" title="myticket" rel="home"><img src="images/logo.png" alt="logo"></a>
							</h1>
						</div>

						<div class="col-md-9">
						
						
						
							
							<div class="topnav" id="myTopnav">
							  <a href="exibition.php" >About Event</a>
							  <a href="event-exhibitor.php" id="active">Exhibitors</a>
							  <!-- <div class="dropdown">
								<button class="dropbtn">Exhibitors 
								  <i class="fa fa-caret-down"></i>
								</button>
								<div class="dropdown-content">
								  <a href="#">Product Portfolio</a>
								  <a href="#">Option Second</a>
								  
								</div>
							  </div>  -->
							  <a href="gallery.php">Gallery</a>
							  <a href="contact_us.php">Contact Us</a>
							  <a href="organizer.php">Organizer</a>
							  <a href="floor_map.php">Floor Map</a>
							  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
							</div>
						
						
						<script>
							function myFunction() {
								var x = document.getElementById("myTopnav");
								if (x.className === "topnav") {
									x.className += " responsive";
								} else {
									x.className = "topnav";
								}
							}
						</script>
						</div>
					</div>
				</div>
			</div>
		
	
		<!-- <section class="section-page-header">
			<div class="container">
				<h1 class="entry-title"></h1>
			</div>-->
		</section> 
		
		<section class="section-select-seat-2-featured-header">
			<div class="container">
				<div class="section-content">
				
				<?php
	
		$result = mysql_query("SELECT * FROM Exhibitor_details where Stall_no = '$Stall_no'")
		or die(mysql_error());  
		while($row = mysql_fetch_array( $result )) 
		{	 //echo $oprId=$row['Exhibition_name'];
	?>
				
					<p style="text-align: center;"> <strong>Exhibitor <span > <?php echo $row['Exhibitor_Name']; ?></strong> </span></p>
					
	
					<div style="float:right;">
						
						<img src="admin/pages/upload/<?php echo $row['Logo']; ?>" style="width: 100%; float: right;margin-top: -125px;">
					</div>
				</div>
				
	<?php
	}
	?>			
			</div>
		</section>
		
		
		<!-- <section class="section-refine-search">
			<div class="container">
				<div class="row">
					<form class="row">
						<div class="keyword col-sm-6 col-md-4">
							<label>Search Keyword</label>
							<input type="text" class="form-control hasclear" placeholder="Search">
							<span class="clearer"><img src="images/clear.png" alt="clear"></span>
						</div>
						<div class="month col-sm-6 col-md-3">
							<label>Month</label>
							<select class="selectpicker dropdown">
								<option>Select Month</option>
								<option>January</option>
								<option>February</option>
								<option>March</option>
								<option>April</option>
								<option>May</option>
								<option>June</option>
								<option>July</option>
								<option>August</option>
								<option>September</option>
								<option>October</option>
								<option>November</option>
								<option>December</option>
							</select>
						</div>
						<div class="year col-sm-6 col-md-3">
							<label>Year</label>
							<select class="selectpicker dropdown">
								<option>Select Year</option>
								<option value="2017">2016</option>
								<option value="2017">2017</option>
								<option value="2018">2018</option>
								<option value="2019">2019</option>
								<option value="2020">2020</option>
								<option value="2021">2021</option>
								<option value="2022">2022</option>
								<option value="2023">2023</option>
								<option value="2024">2024</option>
								<option value="2025">2025</option>
								<option value="2026">2026</option>
							</select>
						</div>
						<div class="col-sm-6 col-md-2">
							<input type="submit" value="Search">
						</div>
					</form>
				</div>
			</div>
		</section> -->
	
		<section class="section-latest" style="">
			<div class="container">
				<div class="row">
				
				
				<!-- <div class="section-header" style="min-height: 110px;margin: auto;width: 44%;/* border: 3px solid green; *//* padding: 10px; */ margin-top: -47px; position: absolute; z-index: 20;" > -->
				
				<div class="section-header" style="/* min-height: 110px; *//* margin: auto; *//* width: 44%; *//* border: 3px solid green; *//* padding: 10px; */margin-top: -47px;position: absolute;/* z-index: 20; *//* margin-bottom: 23px; */ margin-left: 24%;">
					<div style="float:left;">
						
						<!--<a href="exhibitor-profile.html"><img src="images/about-the-event.png" ></a>-->
						<a href="about-company.php?Stall_no=<?php echo $Stall_no; ?>"><img src="images/about-the-event.png" ></a>
					</div>
					<div style="float:left; margin-left:20px;">
						
						<!--<a href="Exhibitor_ProductPortfolio.html"><img src="images/product-profile.png" ></a>-->
						<a href="product-profile.php?Stall_no=<?php echo $Stall_no; ?>"><img src="images/product-profile.png" ></a>
					</div>
				</div>
				
				<!-- <div class="section-header" style="min-height: 110px;">
					<div style="float:left;">
						
						<h2 style="color: #ffa800; font-size:40px;     text-transform: unset;">Exhibitor Name</h2>
					</div>
					<div style="float:right;">
						
						<img src="images/exibition-logo.jpg" style="width: 100%; float: right;margin-top: -31px;">
					</div>
				</div>-->
				
				<div style="clear:both;margin-top: 25px;"></div> 
				
	<?php
	
		$result = mysql_query("SELECT * FROM Exhibitor_details where Stall_no = '$Stall_no'")
		or die(mysql_error());  
		while($row = mysql_fetch_array( $result )) 
		{	 //echo $oprId=$row['Exhibition_name'];
	?>
				
				<div class="col-sm-12 col-md-2" >
						<div class="latest-tweets">
							
							
							<div class="section-header">
							
								<!--<img src="images/AboutTheCompany-logo.jpg" style="width:100%;">-->
								<img src="admin/pages/upload/<?php echo $row['Logo']; ?>" style="width:100%;">
																
								<!--<h3 style="font-size: 20px;padding-top: 14px;padding-bottom: 5px;"><span style="font-weight: bold; color: #f6921f;">Exhibitor Name</span></h3>-->
								<h3 style="font-size: 20px;padding-top: 14px;padding-bottom: 5px;"><span style="font-weight: bold; color: #f6921f;"><?php echo $row['Exhibitor_Name']; ?></span></h3>
							</div>
							
							<div class="section-content">
								
								<div class="tweet-list clearfix" >
									
									<p style="margin: 0 1px 0 0;">
										<?php echo $row['Tag_line']; ?>
									</p>
												
											
								</div>
								
								<div class="tweet-list clearfix" style="padding-top:50px;">
									
									
									<p style="margin: 0 1px 0 0; border-bottom: solid 1px; padding-bottom: 7px; padding-top: 7px;"><?php echo $row['Email_ID']; ?></p>
									
									<p style="margin: 0 1px 0 0; border-bottom: solid 1px; padding-bottom: 7px; padding-top: 7px;"><?php echo $row['Contact_number_Poc']; ?></p>
												
											
								</div>
								
								<div class="tweet-list clearfix" style="padding-top:50px;">
									
					<a href="<?php echo $row['FB_link']; ?>" target="black"><i class="fa fa-facebook" style="font-size: 20px;padding: 5px;"></i></a>
					<a href="<?php echo $row['Twitter_link']; ?>" target="black"><i class="fa fa-twitter" style="font-size: 20px;padding: 5px;"></i></a>
					<a href="<?php echo $row['Linkedin_link']; ?>" target="black"><i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i></a>
					<a href="<?php echo $row['Insta_link']; ?>" target="black"><i class="fa fa-google" style="font-size: 20px;padding: 5px;"></i></a>
					<a href="<?php echo $row['Youtube_link']; ?>" target="black"><i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i></a>
																	
											
								</div>
								
								<div class="tweet-list clearfix" style="padding-top:50px;">
									
									<a href="admin/pages/upload/<?php echo $row['Logo']; ?>" target="black"><p style="margin: 0 1px 0 0; border-bottom: solid 1px; border-left: solid 1px; padding: 12px;     font-weight: bold; color: #f6921f; font-size: 12px;">Brouchure Download</p></a>
									
									<a href="admin/pages/upload/<?php echo $row['Logo']; ?>" target="black"><p style="margin: 0 1px 0 0; border-bottom: solid 1px; border-left: solid 1px; padding: 12px;     font-weight: bold; color: #f6921f; font-size: 12px;">Schedule Meeting</p></a>
												
											
								</div>
							</div>
						</div>
												
				</div>
				
				<div class="col-sm-12 col-md-5" >
						<div class="latest-tweets">
							<!--<div class="section-header">
								<h3 style="text-transform: uppercase;margin-bottom: 20px;font-size: 19px;">Barcelona <span style="font-weight: bold;">Food Truck Festival 2018</span></h3>
							</div>-->
							
							<div class="section-content">
								
								<div class="tweet-list clearfix" >
									
									<p style="margin: 0 14px 0 0;"><?php echo $row['Company_Description']; ?></p>
												
											
								</div>
							</div>
						</div>
						
						
						<div class="latest-tweets" style="margin-top: 20px;">
							<div class="section-header">
								<h3 style="//margin-bottom: 20px;font-size: 19px;"><span style="font-weight: bold;">Highlights</span></h3>
							</div>
							
							<div class="section-content">
								
								<div class="" >
									
									<ul style="list-style: disc;padding-left: 16px;padding-top: 10px; font-family: 'Open Sans', sans-serif;font-weight: 500;">
										<li style="padding-bottom: 6px;">
											Lorem Ipsum is simply dummy text of the printing and typesetting industry..
										</li>
										<li style="padding-bottom: 6px;">
											It is simply dummy text of the printing and typesetting industry.
										</li>
										<li style="padding-bottom: 6px;">
											Lorem Ipsum is simply dummy text of the printing and typesetting industry..
										</li>
										
										
									</ul>
												
											
								</div>
							</div>
						</div>
						
						<div class="latest-tweets" style="margin-top: 50px;">
							<div class="section-header">
								<h3 style="margin-bottom: 20px;font-size: 19px;">
									<span style="color: #f6921f;">Surender Malik</span>
									<span style="">(Director)</span>
								</h3>
							</div>
							
							<div class="section-content">
								
								<div class="" >
									
									<p style="font-size:17px;">Event Company Name<br>
									Main Road, Street no-7, Noida-235235<br>
									info@expoknot.com<br>
									Cell: +999 99 99999
									</p>
												
											
								</div>
							</div>
						</div>
						
												
						<!-- <section class="section-refine-search">
			
							<div class="artist-event-item-price">
								<a href="#" class="get-ticket" style="">
									<img src="images/brochure-download-here.png" style="width: 64%;margin-left: 16%; margin-right: 10%;">
								</a>
							</div>
						
						</section> -->
						
						<section class="section-refine-search" style="margin-top: 44%;">
			
							
							
							<div class="artist-event-item-price">
							<div style="/*float:left;*/">
							
							<?php
										if(isset( $_SESSION['login_user'] ))
										
										{
											include('session.php');
											?>
											
											<a href="thanks.php">
												<span style="color: #4CAF50;border: 2px solid #4CAF50;padding: 12px;border-radius: 10px;"><i class="fa fa-check"></i>Let's Connect</span>
											</a>
											 
											<!--<input type="submit" value="Let's Connect" align="middle" style="color: #4CAF50; border: 2px solid #4CAF50;">-->
											
											
											<?php
										} 
										else
										{
											?>
																					
											<a href="#" id="myBtn">
												<span style="color: #ff6600;border: 2px solid #ff6600;padding: 12px;border-radius: 10px;">Let's Connect</span>
											</a>
											
										<?php
										}

									?>
							
							
							
								<!---<a href="#" class="get-ticket" style="">
									<img src="images/lets-connect.png" style="width: 75%;">
								</a>-->
							</div>
							<!-- <div style="float:left;">
								<a href="#" class="get-ticket" style="">
									<img src="images/schedule-meeting.png" style="width: 100%;">
								</a>
							</div> -->
							</div>
						
						</section>
						
						
				</div>
					
					<div class="col-sm-12 col-md-5">
						<div class="latest-news">
							<!-- <div class="section-header" >
								<h3 style="text-transform: uppercase;margin-bottom: 20px;">Latest <b> News</b></h3>
							</div> -->
							<div class="section-content">
								
								
	<!-- Start WOWSlider.com BODY section --> <!-- add to the <body> of your page -->
	<div id="wowslider-container0">
	<div class="ws_images"><ul>
		<li><img src="admin/pages/upload/<?php echo $row['Company_Images']; ?>" alt="gallery-15" title="gallery-15" id="wows0_0"/></li><li><img src="admin/pages/upload/<?php echo $row['Company_Images']; ?>" alt="gallery-15" title="gallery-15" id="wows0_0"/></li><li><img src="admin/pages/upload/<?php echo $row['Company_Images']; ?>" alt="gallery-15" title="gallery-15" id="wows0_0"/></li>
		
	</ul></div>
	<!--<div class="ws_images"><ul>
		<li><img src="data0/images/gallery15.jpg" alt="gallery-15" title="gallery-15" id="wows0_0"/></li>
		<li><img src="data0/images/gallery14.jpg" alt="gallery-14" title="gallery-14" id="wows0_1"/></li>
		<li><img src="data0/images/gallery13.jpg" alt="gallery-13" title="gallery-13" id="wows0_2"/></li>
		<li><img src="data0/images/gallery12.jpg" alt="gallery-12" title="gallery-12" id="wows0_3"/></li>
	</ul></div>
	<div class="ws_bullets"><div>
		<a href="#" title="gallery-15"><span><img src="data0/tooltips/gallery15.jpg" alt="gallery-15"/>1</span></a>
		<a href="#" title="gallery-14"><span><img src="data0/tooltips/gallery14.jpg" alt="gallery-14"/>2</span></a>
		<a href="#" title="gallery-13"><span><img src="data0/tooltips/gallery13.jpg" alt="gallery-13"/>3</span></a>
		<a href="#" title="gallery-12"><span><img src="data0/tooltips/gallery12.jpg" alt="gallery-12"/>4</span></a>
	</div></div>-->
	
	<div class="ws_bullets"><div>
		<a href="#" title="gallery-15"><span><img src="admin/pages/upload/<?php echo $row['Company_Images']; ?>" width="50px" alt="gallery-15"/>1</span></a>
		<a href="#" title="gallery-15"><span><img src="admin/pages/upload/<?php echo $row['Company_Images']; ?>" width="50px" alt="gallery-15"/>1</span></a>
		<a href="#" title="gallery-15"><span><img src="admin/pages/upload/<?php echo $row['Company_Images']; ?>" width="50px" alt="gallery-15"/>1</span></a>
		
	</div></div>
	<!-- 
	<div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.com">slider</a> by WOWSlider.com v8.7</div> 
	-->
	<!-- <div class="ws_shadowghhg"></div> -->
	</div>	
	<!-- <script type="text/javascript" src="engine0/wowslider.js"></script> -->
	<!-- <script type="text/javascript" src="engine0/script.js"></script> -->
	<!-- End WOWSlider.com BODY section --><!-- <img src="images/event-category-3.jpg" alt="image" style="width: 560px;"> -->
											
								
							</div>
							
							<section class="section-refine-search" style="margin-top: 20%;">
			
								<form name="ajax-form" id="ajax-form" action="about-company-form-insert.php" method="post">

								<!-- <label>Search Keyword</label> -->
								<input type="text" name="your_name" class="form-control hasclear" placeholder="Your Name" required  />
								<input type="email" name="email_address" class="form-control hasclear" placeholder="Email Address"  style="border: 2px solid #dedede; padding: 0 25px; height: 55px; line-height: 39px; height: auto; width: 100%; color: #b3b3b3; margin-bottom: 13px; background-color: #e8e8e84d;" required />
								<input type="text" name="your_address" class="form-control hasclear" placeholder="Your Address" required />
								<input type="text" name="phone_no" class="form-control hasclear" placeholder="Phone Number" required />
								<textarea name="message" rows="4" cols="50" class="form-control hasclear" placeholder="Your Message">
								</textarea>
								
							
								<!--<div class="artist-event-item-price">
								<a href="#" class="get-ticket" style="">
									<img src="images/send-mail.png" style="width: 43%;margin-left: 30%;margin-right: 10%;margin-top: 34px;">
								</a>
							</div>-->
							<input type="submit" value="Send Mail" align="middle">
							<!--<input type="submit" value="Search" align="middle">-->
							
						
								</form>
				
							</section>
						</div>
					</div>
		<?php
	}
	?>				
					
				</div>
			</div>
		</section>
		

		<footer id="colophon" class="site-footer">
			<div class="top-footer">
				<div class="container">
					<div class="row">
						
						<div class="col-md-4">
							<div style="float:left; width:18%">
							<i class="fa fa-map-marker" style="padding: 21px;font-size: 30px;background-color: #383838;width: 100%;color: #fff;"></i>
							</div>
							<div style="float:left;padding: 24px;background-color: #00000082;width: 80%;">Sec-77, Near Street <br> 
							<span style="color: #e48325;font-size: 16px;">Utter Pradesh, India</span></div>
						</div>
						<div class="col-md-4">
							<div style="float:left; width:18%">
							<i class="fa fa-envelope" style="padding: 21px;font-size: 30px;background-color: #383838;width: 100%;color: #fff;"></i>
							</div>
							<div style="float:left;padding: 24px;background-color: #00000082;width: 80%;">contact@expoknot.com <br> 
							<span style="color: #e48325;font-size: 16px;">info@expoknot.com</span></div>
						</div>
						<div class="col-md-4">
							<div style="float:left; width:18%">
							<i class="fa fa-phone" style="padding: 21px;font-size: 30px;background-color: #383838;width: 100%;color: #fff;"></i>
							</div>
							<div style="float:left;padding: 24px;background-color: #00000082;width: 80%;">011 - 421 - 0000 <br> 
							<span style="color: #e48325;font-size: 16px;">011 - 421 - 1111</span></div>
						</div>
					
					
					</div>
					</div>
					</div>
					</footer>
					
					
		<footer id="colophon" class="site-footer">
			<div class="top-footer" style="border-top: 1px solid #4e4e4e;">
				<div class="container">
				
					<div class="row" style="margin-top:2%; ">
						
						
						
						<div class="footer-2 col-md-4" style="border-left: none;">
							<div class="footer-dashboard">
								<!-- <p style="font-size: 23px;margin-bottom: 25px;">Useful <span style="font-weight:  bold;">Links </span></b></p> -->
								<ul>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  About Us</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Trade Shows</a>
									</li>
									
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Conferences</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Contact Us</a>
									</li>
									<!-- <li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Birthday Party</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Business Meeting</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Conferance</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Food Event</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Musical Event</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Wedding Party</a>
									</li> -->
								</ul>
							</div>
						</div>
						
						<!--<div class="footer-2 col-md-3" style="border-left: none;">
							<div class="footer-dashboard">
								<p style="font-size: 23px;margin-bottom: 25px;">Useful <span style="font-weight:  bold;">Links </span></b></p>
								<ul>
									 <li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Conferences</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Contact Us</a>
									</li> 
									
									 <li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  About Expoknot</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Disclaimer</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Contact Useful</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Events Schedule</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Sponsors</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Venues</a>
									</li> 
								</ul>
							</div>
						</div>-->
						
						<div class="col-md-4">
						
							<div>
								<p style="font-size: 14px;">
									<span style="font-size:26px;font-weight:  bold;color: #ffffff;"> Network 	</span>
								</p>
								<a href="#"><i class="fa fa-facebook" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-twitter" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-google" style="font-size: 20px;padding: 5px;"></i></a>
								<a href="#"><i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i></a>
							</div>
						
						<!-- <p style="font-size: 23px; text-align:center;">Expoknot  <span style="font-weight:  bold;">Instagram </span></b></p>
						
						<div style="float:left;width: 120px;padding: 5px;"> <a href="#">
							<img src="images/footer-icon.jpg" style="max-height: 100%;"></a>
						</div>
						<div style="float:left;width: 120px;padding: 5px;"> <a href="#">
							<img src="images/footer-icon.jpg" style="max-height: 100%;"></a>
						</div>
						<div style="float:left;width: 120px;padding: 5px;"> <a href="#">
							<img src="images/footer-icon.jpg" style="max-height: 100%;"></a>
						</div>
						<div style="float:left;width: 120px;padding: 5px;"> <a href="#">
							<img src="images/footer-icon.jpg" style="max-height: 100%;"></a>
						</div>
						
						<p style="font-size: 14px; text-align:center;">Follow Our Instagram <span style="font-weight:  bold;color: #e48325;"> #Expoknot </span></b></p> -->
						</div>
						
						<div class="col-md-4">
							<a href="#"><img src="images/logo.png" alt="logo" style="width:100%; max-height: 83px;"></a>
							
							<!-- <div style="margin-top: 177px;">
								<p style="font-size: 14px;">
									<span style="font-size:26px;font-weight:  bold;color: #ffffff;"> Network 	</span>
								</p>
								<i class="fa fa-facebook" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-twitter" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-google" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i>
							</div> -->
						</div>
						
						
					</div>

					
					<!-- <div class="row" style="margin-top:2%; ">
						
						<div class="col-md-3">
							<a href="#"><img src="images/logo.png" alt="logo" style="width:100%; max-height: 61px;"></a>
														
						</div>
						
						<div class="footer-2 col-md-3" style="border-left: none;">
							<div class="footer-dashboard">
								<p style="font-size: 23px;margin-bottom: 25px;">Useful <span style="font-weight:  bold;">Links </span></b></p>
								<ul>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  About Us</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Trade Shows</a>
									</li>								
									
								</ul>
							</div>
						</div>
						
						<div class="footer-2 col-md-3" style="border-left: none;">
							<div class="footer-dashboard">
								<p style="font-size: 23px;margin-bottom: 25px; color: #1f1f1f;">Useful <span style="font-weight:  bold;">Links </span></b></p>
								<ul>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Conferences</a>
									</li>
									<li><a href="#" style="font-size: 14px; color: #9b9b9b;">
										<i class="fa fa-arrow-circle-right"></i>  Contact Us</a>
									</li>
																	
								</ul>
							</div>
						</div>
						
						<div class="col-md-3">
						
							<div>
								<p style="font-size: 14px;">
									<span style="font-size:26px;font-weight:  bold;color: #ffffff;"> Network 	</span>
								</p>
								<i class="fa fa-facebook" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-twitter" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-google" style="font-size: 20px;padding: 5px;"></i>
								<i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i>
							</div>
						
						
						</div>
						
						
					</div> -->
					
					<!-- <div class="row" style="margin-top:2%; ">
						
						<div class="col-md-3">
							<p style="font-size: 14px;">
								<span style="font-size:26px;font-weight:  bold;color: #ffffff;"> Network 	</span>
							</p>
							<i class="fa fa-facebook" style="font-size: 20px;padding: 5px;"></i>
							<i class="fa fa-twitter" style="font-size: 20px;padding: 5px;"></i>
							<i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i>
							<i class="fa fa-google" style="font-size: 20px;padding: 5px;"></i>
							<i class="fa fa-instagram" style="font-size: 20px;padding: 5px;"></i>
							
						</div>
						
						<div class="col-md-3">
						
						<p style="font-size: 23px; text-align:center;"></b></p>
						</div>
						
						<div class="col-md-3">
						
						<p style="font-size: 23px; text-align:center;"></b></p>
						</div>
						
						<div class="col-md-3">
						
						<p style="font-size: 14px; text-align:center;">Follow Our Instagram <span style="font-weight:  bold;color: #e48325;"> #Expoknot </span></b></p>
						</div>
						
						
					</div>  -->
					
				</div>
				
				
				
				
			</div>
			
			 <div class="top-footer" style="padding: 1px 0; background: #fff;">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
												
						<p style="margin: 10px 30px 10px 0; font-size: 17px; TEXT-ALIGN: center; color: #ff7d00;  font-weight: bold;">&copy; 2018 EXPOKNOT.COM</p>
						</div>
							
					</div>
					
				</div>
			</div>
		</footer><!-- #colophon -->
		
	
		<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
		

		<script src="js/jquery-3.2.0.min.js"></script>
		<script src="js/bootstrap-slider.min.js"></script>
		<script src="js/bootstrap-select.min.js"></script>
		<script src="js/jquery.scrolling-tabs.min.js"></script>
		<script src="js/jquery.countdown.min.js"></script>
		<script src="js/jquery.flexslider-min.js"></script>
		<script src="js/jquery.imagemapster.min.js"></script>
		<script src="js/tooltip.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/featherlight.min.js"></script>
		<script src="js/featherlight.gallery.min.js"></script>
		<script src="js/bootstrap.offcanvas.min.js"></script>
		<script src="js/main.js"></script>

	</body>
</html>