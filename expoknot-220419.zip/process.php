<?php
require_once("connect-db.php");

echo $email = $_POST['email'];

$g=0;

echo $sql="SELECT * FROM `Visitor_details` where `Email_ID` ='$email'";
//echo $result = $connection->query($sql);
echo $result = mysql_query($sql);
	while($row = mysql_fetch_array($result))
	{
		$id = $row['Visitor_Unique_ID'];
		echo $g++;
	}

	if ($g > 0) 
	{
		echo "hello";
		header( "Location: registered.php?id=$id" );
	}
	else
	
	{

		session_start();
		$rndno=rand(100000, 999999);//OTP generate
		//$message = urlencode("One time Password".$rndno);
		$to=$_POST['email'];
		//$url="http://www.expoknot.com/changepassword.php?email=".$to."";
		$subject = "Mail Verification";
		//$txt = "Click here to change password ".$url."";
		$txt = "One time Password: ".$rndno."";
		$headers = "From: info@expoknot.com" . "\r\n" .
		"CC: kumar.rajeev895@gmail.com";
		//"CC: divyasundarsahu@gmail.com";
		mail($to,$subject,$txt,$headers);
		if(isset($_POST['btn-save']))
		{
		$_SESSION['name']=$_POST['name'];
		$_SESSION['email']=$_POST['email'];
		$_SESSION['phone']=$_POST['phone'];
		$_SESSION['otp']=$rndno;


		$email = $_POST['email'];
		$phone = $_POST['phone'];

		//$sql = "INSERT INTO `Visitor_details`(`Visitor_Mobile_Number`, `Email_ID`,`otp`) VALUES ('$email','$phone','$rndno')";
		$sql = "INSERT INTO `Visitor_details`(`Visitor_Name`, `Visitor_Mobile_Number`, `Email_ID`, `Designation`, `Company_Name`, `Industry_interested`, `otp`) VALUES ('0','$phone','$email','0','0','0','$rndno')";

		mysql_query($sql) or die(mysql_error());

		header( "Location: otp.php" ); 
		} 
	}
?>