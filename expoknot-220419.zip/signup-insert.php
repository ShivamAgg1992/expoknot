<?php
require_once("connect-db.php");

echo $email = $_POST['email'];
echo $password = $_POST['password'];
echo $confirm_password = $_POST['confirm_password'];


	/* $result = mysql_query("SELECT * FROM `Visitor_details` where `Email_ID` ='$email'")
		or die(mysql_error());  

	while($row = mysql_fetch_array( $result )) 
	{
		echo $row['Stall_no'];
	} */
	
		
		
$sql = "INSERT INTO `loginmaster`(`oprName`, `password`, `templateName`, `status`) VALUES ('$email','$password','CMD','1')";
	
		mysql_query($sql)
		or die(mysql_error());

/*
$send_to = "info@expoknot.com";
$send_subject = "Contact | ExpoKnot";

$password = cleanupentries($_POST["password"]);
$confirm_password = cleanupentries($_POST["confirm_password"]);

$from_ip = $_SERVER['REMOTE_ADDR'];
$from_browser = $_SERVER['HTTP_USER_AGENT'];

function cleanupentries($entry) {
	$entry = trim($entry);
	$entry = stripslashes($entry);
	$entry = htmlspecialchars($entry);

	return $entry;
}

$message = "This email was submitted on " . date('m-d-Y') . 
"\n\nName: " . $password . 
"\n\nE-Mail: " . $confirm_password . 
"\n\n\nTechnical Details:\n" . $from_ip . "\n" . $from_browser;

$send_subject .= " - {$password}";

$headers = "From: " . $confirm_password . "\r\n" .
    "Reply-To: " . $confirm_password . "\r\n" .
    "X-Mailer: PHP/" . phpversion();

if (!$confirm_password) {
	echo "no email";
	exit;
}else if (!$password){
	echo "no name";
	exit;
}else{
	if (filter_var($confirm_password, FILTER_VALIDATE_EMAIL)) {
		mail($send_to, $send_subject, $message, $headers);
		echo "true";
	}else{
		echo "invalid email";
		exit;
	}
}*/
 
  echo '<script>window.location.href = "thanks.php";</script>';


?>