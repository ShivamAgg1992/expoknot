<?php
    require_once("connect-db.php");
	
	$email = $_POST['postEmail'];
    	
	 
//echo $send_to = "kumar.rajeev895@gmail.com";
$send_to = cleanupentries($_POST['postEmail']);
echo $send_subject = "OTP | ExpoKnot";

$otp = rand(100000,999999);


$f_email =  "info@expoknot.com";
//$f_your_address = cleanupentries($_POST['your_address']);
//$f_phone_no = cleanupentries($_POST['phone_no']);
echo $f_message = cleanupentries(date('shs'));
$from_ip = $_SERVER['REMOTE_ADDR'];
$from_browser = $_SERVER['HTTP_USER_AGENT'];

function cleanupentries($entry) {
	$entry = trim($entry);
	$entry = stripslashes($entry);
	$entry = htmlspecialchars($entry);

	return $entry;
}

$message = "This email was submitted on " . date('m-d-Y') . 
"\n\nOTP: \n" . $otp . 
"\n\n\nTechnical Details:\n" . $from_ip . "\n" . $from_browser;

$headers = "From: " . $f_email . "\r\n" .
    "Reply-To: " . $f_email . "\r\n" .
    "X-Mailer: PHP/" . phpversion();

if (!$f_email) {
	echo "no email";
	exit;
}else{
	if (filter_var($f_email, FILTER_VALIDATE_EMAIL)) {
		mail($send_to, $send_subject, $message, $headers);
		
		$sql = "INSERT INTO `Visitor_details`(`Visitor_Name`, `Visitor_Mobile_Number`, `Email_ID`, `Designation`, `Company_Name`, `Industry_interested`, `otp`) VALUES ('','','$email','','','','$otp')";
	
		mysql_query($sql)
		or die(mysql_error());
		
		echo "true";
	}else{
		echo "invalid email";
		exit;
	}
}
?>